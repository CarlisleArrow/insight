---
name: carbon-design
description: Use this skill to generate well-branded interfaces and assets for IBM Carbon Design System, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.

If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Where things are
- `readme.md` — the full design guide: content voice, visual foundations, iconography, and a file index. **Read this first.**
- `styles.css` — single global stylesheet; link it (or its `tokens/*.css`) to inherit every token. Tokens are CSS custom properties prefixed `--cds-` (e.g. `--cds-blue-60`, `--cds-text-primary`, `--cds-spacing-05`).
- `tokens/` — colors, typography (`.cds-type-*` classes), spacing, motion, elevation, fonts.
- `components/` — React UI primitives (Button, Icon, TextInput, Checkbox, Toggle, Dropdown, Search, Tag, Tile, Tabs, InlineNotification, Loading). Each has a `.prompt.md` with a usage example.
- `assets/icons/` — 111 Carbon SVG glyphs, monochrome `currentColor`. Use the `Icon` component or a CSS `mask`.
- `ui_kits/cloud-console/` — a full IBM Cloud–style console showing the components composed into a real product view.

## Key rules (see readme.md for the full set)
- Signature color is **Blue 60 `#0f62fe`** for everything interactive. Neutrals + Gray 100 `#161616` text carry the rest.
- **IBM Plex** type (Sans / Mono / Serif). **Sentence case**, no terminal periods on labels/buttons, no emoji.
- **Square corners** (radius 0); pills only for tags, circles for avatars/spinners.
- Depth from **layers + 1px borders**; shadows only for floating overlays. Flat backgrounds — no gradients.
- Align to the **2px spacing scale** and the **16-column grid**.

## Using the components in a static HTML artifact
Link `styles.css`, set `window.CDS_ICON_BASE` to the relative path of `assets/icons`, load React + Babel + `_ds_bundle.js`, then read components off `window.CarbonDesignSystem_280d33`. The card HTML files under `components/` and `ui_kits/cloud-console/index.html` are complete working examples to copy.
