import * as React from 'react';

export type ButtonKind = 'primary' | 'secondary' | 'tertiary' | 'ghost' | 'danger';
export type ButtonSize = 'sm' | 'md' | 'lg' | 'xl';

/**
 * Carbon button — the primary action element. Rectangular, label left,
 * optional icon pinned right. Use one primary button per view.
 *
 * @startingPoint section="Core" subtitle="Action buttons in every kind & size" viewport="700x200"
 */
export interface ButtonProps {
  children?: React.ReactNode;
  /** Visual emphasis. @default "primary" */
  kind?: ButtonKind;
  /** Control height: sm 32, md 40, lg 48, xl 64. @default "lg" */
  size?: ButtonSize;
  /** Icon name (from the Carbon icon set) rendered at the trailing edge. */
  icon?: string;
  /** Render only the icon (square button). */
  iconOnly?: boolean;
  disabled?: boolean;
  /** Render as an anchor instead of a button. */
  href?: string;
  type?: 'button' | 'submit' | 'reset';
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
  style?: React.CSSProperties;
}

export function Button(props: ButtonProps): JSX.Element;
