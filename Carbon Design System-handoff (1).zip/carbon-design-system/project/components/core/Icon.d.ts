import * as React from 'react';

export interface IconProps {
  /** Icon file name without extension, e.g. "search", "chevron--down", "user--avatar". */
  name: string;
  /** Pixel size (square). Carbon icon sizes are 16 or 20. @default 16 */
  size?: number | string;
  /** Override the base path to the icon folder. Defaults to window.CDS_ICON_BASE or "assets/icons". */
  base?: string;
  /** Accessible label; falls back to the icon name. */
  title?: string;
  className?: string;
  style?: React.CSSProperties;
}

/**
 * Carbon SVG glyph tinted with the current text color (CSS mask, currentColor).
 */
export function Icon(props: IconProps): JSX.Element;
