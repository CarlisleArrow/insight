Carbon's primary action element — rectangular, label-left, optional trailing icon; use one primary button per view.

```jsx
<Button kind="primary" size="lg" icon="arrow--right" onClick={save}>
  Continue
</Button>
```

Variants:
- `kind`: `primary` (one per view), `secondary`, `tertiary` (outlined, inverts on hover), `ghost` (text-only), `danger`.
- `size`: `sm` (32px), `md` (40px), `lg` (48px, default), `xl` (64px).
- `icon`: any Carbon icon name (e.g. `add`, `arrow--right`, `download`). Set `iconOnly` for a square icon button.
- `href` renders an anchor; `disabled` dims and blocks interaction.
