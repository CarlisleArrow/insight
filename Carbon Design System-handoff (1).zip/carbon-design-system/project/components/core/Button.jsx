import React from 'react';
import { Icon } from './Icon';

const STYLE_ID = 'cds-button-styles';
const CSS = `
.cds--btn {
  display: inline-flex;
  align-items: center;
  box-sizing: border-box;
  position: relative;
  margin: 0;
  font-family: var(--cds-font-sans);
  font-size: .875rem;
  font-weight: 400;
  letter-spacing: .16px;
  line-height: 1.28572;
  text-align: left;
  text-decoration: none;
  vertical-align: top;
  cursor: pointer;
  border: 1px solid transparent;
  border-radius: 0;
  outline: none;
  min-height: 48px;
  padding: 14px 63px 14px 15px;
  transition: background var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              box-shadow var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              border-color var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              color var(--cds-duration-fast-01) var(--cds-ease-standard-productive);
}
.cds--btn--sm { min-height: 32px; padding-top: 6px; padding-bottom: 6px; }
.cds--btn--md { min-height: 40px; padding-top: 10px; padding-bottom: 10px; }
.cds--btn--lg { min-height: 48px; }
.cds--btn--xl { min-height: 64px; padding-top: 14px; padding-bottom: 14px; align-items: flex-start; }
.cds--btn--has-icon { padding-right: 15px; }
.cds--btn__icon { margin-left: 32px; }
.cds--btn--icon-only { padding: 0; justify-content: center; width: 48px; }
.cds--btn--icon-only.cds--btn--sm { width: 32px; }
.cds--btn--icon-only.cds--btn--md { width: 40px; }
.cds--btn--icon-only .cds--btn__icon { margin-left: 0; }
.cds--btn:focus-visible { box-shadow: inset 0 0 0 1px var(--cds-focus), inset 0 0 0 2px var(--cds-focus-inset); }

/* Primary */
.cds--btn--primary { background: var(--cds-button-primary); color: var(--cds-text-on-color); }
.cds--btn--primary:hover { background: var(--cds-button-primary-hover); }
.cds--btn--primary:active { background: var(--cds-button-primary-active); }

/* Secondary */
.cds--btn--secondary { background: var(--cds-button-secondary); color: var(--cds-text-on-color); }
.cds--btn--secondary:hover { background: var(--cds-button-secondary-hover); }
.cds--btn--secondary:active { background: var(--cds-button-secondary-active); }

/* Tertiary */
.cds--btn--tertiary { background: transparent; color: var(--cds-button-tertiary); border-color: var(--cds-button-tertiary); }
.cds--btn--tertiary:hover { background: var(--cds-button-primary-hover); color: var(--cds-text-on-color); border-color: var(--cds-button-primary-hover); }
.cds--btn--tertiary:active { background: var(--cds-button-primary-active); border-color: var(--cds-button-primary-active); }

/* Ghost */
.cds--btn--ghost { background: transparent; color: var(--cds-link-primary); padding-right: 15px; }
.cds--btn--ghost:hover { background: var(--cds-background-hover); color: var(--cds-link-primary-hover); }
.cds--btn--ghost:active { background: var(--cds-background-active); }

/* Danger */
.cds--btn--danger { background: var(--cds-button-danger); color: var(--cds-text-on-color); }
.cds--btn--danger:hover { background: var(--cds-button-danger-hover); }
.cds--btn--danger:active { background: var(--cds-button-danger-active); }

/* Disabled */
.cds--btn:disabled, .cds--btn--disabled {
  background: var(--cds-button-disabled);
  color: var(--cds-text-on-color-disabled);
  border-color: transparent;
  cursor: not-allowed;
}
.cds--btn--ghost:disabled, .cds--btn--tertiary:disabled {
  background: transparent;
  color: var(--cds-text-disabled);
  border-color: var(--cds-border-disabled);
}
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/**
 * Button — Carbon's primary action element. Rectangular (zero radius),
 * label left-aligned, optional icon pinned to the right.
 */
export function Button({
  children,
  kind = 'primary',
  size = 'lg',
  icon,
  iconOnly = false,
  disabled = false,
  href,
  onClick,
  type = 'button',
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const hasIcon = !!icon && !iconOnly;
  const classes = [
    'cds--btn',
    `cds--btn--${kind}`,
    `cds--btn--${size}`,
    hasIcon ? 'cds--btn--has-icon' : '',
    iconOnly ? 'cds--btn--icon-only' : '',
    disabled ? 'cds--btn--disabled' : '',
    className,
  ]
    .filter(Boolean)
    .join(' ');

  const content = (
    <>
      {!iconOnly && <span>{children}</span>}
      {icon && <Icon name={icon} size={iconOnly ? 16 : 16} className="cds--btn__icon" />}
    </>
  );

  if (href && !disabled) {
    return (
      <a className={classes} href={href} style={style} onClick={onClick} {...rest}>
        {content}
      </a>
    );
  }
  return (
    <button className={classes} type={type} disabled={disabled} onClick={onClick} style={style} {...rest}>
      {content}
    </button>
  );
}
