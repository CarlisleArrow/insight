import React from 'react';

/**
 * Resolve the base path to the icon SVGs. Each consuming page can set
 * window.CDS_ICON_BASE to the correct relative path (e.g. "../../assets/icons").
 */
const DEFAULT_BASE =
  (typeof window !== 'undefined' && window.CDS_ICON_BASE) || 'assets/icons';

// Module-level cache of fetched SVG markup, keyed by full url.
const _cache = (typeof window !== 'undefined' && (window.__cdsIconCache = window.__cdsIconCache || {})) || {};

/**
 * Icon — renders a Carbon SVG glyph inline so it inherits `currentColor`
 * and scales cleanly. The SVG markup is fetched once per name and cached.
 */
export function Icon({ name, size = 16, base, title, className = '', style = {} }) {
  const b = base || (typeof window !== 'undefined' && window.CDS_ICON_BASE) || DEFAULT_BASE;
  const url = `${b}/${name}.svg`;
  const [markup, setMarkup] = React.useState(_cache[url] || null);

  React.useEffect(() => {
    let alive = true;
    if (_cache[url]) {
      if (markup !== _cache[url]) setMarkup(_cache[url]);
      return;
    }
    fetch(url)
      .then((r) => (r.ok ? r.text() : Promise.reject(r.status)))
      .then((txt) => {
        // Normalize: ensure it scales to the span and inherits color.
        let svg = txt
          .replace(/<\?xml[^>]*\?>/g, '')
          .replace(/\s(width|height)="[^"]*"/g, '')
          .replace(/<svg /, '<svg width="100%" height="100%" fill="currentColor" ');
        _cache[url] = svg;
        if (alive) setMarkup(svg);
      })
      .catch(() => {});
    return () => { alive = false; };
  }, [url]);

  const px = typeof size === 'number' ? `${size}px` : size;
  return (
    <span
      role="img"
      aria-label={title || name}
      className={className}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        width: px,
        height: px,
        flex: '0 0 auto',
        lineHeight: 0,
        ...style,
      }}
      dangerouslySetInnerHTML={markup ? { __html: markup } : undefined}
    />
  );
}
