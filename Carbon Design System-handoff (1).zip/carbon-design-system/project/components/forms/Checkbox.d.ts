import * as React from 'react';

export interface CheckboxProps {
  /** Label rendered to the right of the box. */
  label?: string;
  /** Controlled checked state. */
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean, e: React.ChangeEvent<HTMLInputElement>) => void;
  disabled?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

/** Square checkbox with label. Controlled or uncontrolled. */
export function Checkbox(props: CheckboxProps): JSX.Element;
