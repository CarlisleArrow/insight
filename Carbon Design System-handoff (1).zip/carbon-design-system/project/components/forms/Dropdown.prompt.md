Single-select listbox styled as a Carbon field.

```jsx
<Dropdown label="Region" items={["US South","EU (Frankfurt)"]} value={r} onChange={setR} />
```

- `items` accepts strings or {label, value}. Closes on outside-click.