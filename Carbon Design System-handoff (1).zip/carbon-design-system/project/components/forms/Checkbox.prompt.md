Square checkbox with label; controlled or uncontrolled.

```jsx
<Checkbox label="Enable autoscaling" defaultChecked onChange={(v) => set(v)} />
```

- Pass `checked` for controlled use, `defaultChecked` for uncontrolled. `disabled` dims it.