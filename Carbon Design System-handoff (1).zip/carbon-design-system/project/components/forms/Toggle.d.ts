import * as React from 'react';

export interface ToggleProps {
  /** Label above the switch. */
  label?: string;
  /** Controlled on/off state. */
  checked?: boolean;
  defaultChecked?: boolean;
  onChange?: (checked: boolean) => void;
  /** "md" (48×24) or "sm" (32×16, no state label). @default "md" */
  size?: 'sm' | 'md';
  /** Text shown when on. @default "On" */
  labelOn?: string;
  /** Text shown when off. @default "Off" */
  labelOff?: string;
  hideStateLabel?: boolean;
  disabled?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

/** On/off switch (turns green when on) with optional state label. */
export function Toggle(props: ToggleProps): JSX.Element;
