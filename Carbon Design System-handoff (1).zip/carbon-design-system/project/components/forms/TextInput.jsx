import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-textinput-styles';
const CSS = `
.cds--form-item { display: flex; flex-direction: column; font-family: var(--cds-font-sans); }
.cds--label { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 6px; }
.cds--label--disabled { color: var(--cds-text-disabled); }
.cds--text-input__wrap { position: relative; display: flex; align-items: center; }
.cds--text-input {
  width: 100%;
  height: 40px;
  box-sizing: border-box;
  padding: 0 16px;
  font-family: var(--cds-font-sans);
  font-size: .875rem;
  letter-spacing: .16px;
  color: var(--cds-text-primary);
  background: var(--cds-field-01);
  border: none;
  border-bottom: 1px solid var(--cds-border-strong-01);
  border-radius: 0;
  outline: 2px solid transparent;
  outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--text-input--sm { height: 32px; }
.cds--text-input--lg { height: 48px; }
.cds--text-input::placeholder { color: var(--cds-text-placeholder); }
.cds--text-input:focus { outline: 2px solid var(--cds-focus); }
.cds--text-input:disabled { color: var(--cds-text-disabled); background: var(--cds-field-01); border-bottom-color: transparent; cursor: not-allowed; }
.cds--text-input--invalid { outline: 2px solid var(--cds-support-error); border-bottom-color: transparent; }
.cds--text-input__icon { position: absolute; right: 16px; pointer-events: none; }
.cds--text-input__icon--error { color: var(--cds-support-error); }
.cds--form__helper { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-helper); margin-top: 6px; }
.cds--form__error { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-error); margin-top: 6px; }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/**
 * TextInput — single-line field with label, helper and error states.
 */
export function TextInput({
  label,
  placeholder,
  value,
  defaultValue,
  onChange,
  type = 'text',
  size = 'md',
  helperText,
  invalid = false,
  invalidText,
  disabled = false,
  id,
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const inputId = id || `cds-input-${Math.random().toString(36).slice(2, 8)}`;
  return (
    <div className={`cds--form-item ${className}`} style={style}>
      {label && (
        <label className={`cds--label ${disabled ? 'cds--label--disabled' : ''}`} htmlFor={inputId}>
          {label}
        </label>
      )}
      <div className="cds--text-input__wrap">
        <input
          id={inputId}
          type={type}
          className={[
            'cds--text-input',
            `cds--text-input--${size}`,
            invalid ? 'cds--text-input--invalid' : '',
          ].filter(Boolean).join(' ')}
          placeholder={placeholder}
          value={value}
          defaultValue={defaultValue}
          onChange={onChange}
          disabled={disabled}
          {...rest}
        />
        {invalid && <Icon name="warning--filled" className="cds--text-input__icon cds--text-input__icon--error" />}
      </div>
      {invalid && invalidText ? (
        <div className="cds--form__error">{invalidText}</div>
      ) : helperText ? (
        <div className="cds--form__helper">{helperText}</div>
      ) : null}
    </div>
  );
}
