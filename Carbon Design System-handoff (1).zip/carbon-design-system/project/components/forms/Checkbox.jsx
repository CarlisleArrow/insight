import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-checkbox-styles';
const CSS = `
.cds--checkbox { display: inline-flex; align-items: center; gap: 8px; font-family: var(--cds-font-sans); cursor: pointer; user-select: none; }
.cds--checkbox--disabled { cursor: not-allowed; }
.cds--checkbox__box {
  position: relative;
  width: 16px; height: 16px;
  box-sizing: border-box;
  flex: 0 0 auto;
  border: 1px solid var(--cds-icon-primary);
  border-radius: 0;
  background: transparent;
  display: inline-flex; align-items: center; justify-content: center;
  transition: background var(--cds-duration-fast-01), border-color var(--cds-duration-fast-01);
}
.cds--checkbox--checked .cds--checkbox__box { background: var(--cds-icon-primary); border-color: var(--cds-icon-primary); }
.cds--checkbox__check { color: var(--cds-icon-inverse); width: 12px; height: 12px; }
.cds--checkbox__label { font-size: .875rem; line-height: 1.28572; letter-spacing: .16px; color: var(--cds-text-primary); }
.cds--checkbox--disabled .cds--checkbox__box { border-color: var(--cds-text-disabled); }
.cds--checkbox--disabled.cds--checkbox--checked .cds--checkbox__box { background: var(--cds-text-disabled); }
.cds--checkbox--disabled .cds--checkbox__label { color: var(--cds-text-disabled); }
.cds--checkbox:focus-within .cds--checkbox__box { outline: 2px solid var(--cds-focus); outline-offset: 1px; }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Checkbox — square selection control with a label. */
export function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isChecked = isControlled ? checked : internal;

  function handle(e) {
    if (disabled) return;
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e.target.checked, e);
  }

  return (
    <label
      className={[
        'cds--checkbox',
        isChecked ? 'cds--checkbox--checked' : '',
        disabled ? 'cds--checkbox--disabled' : '',
        className,
      ].filter(Boolean).join(' ')}
      style={style}
    >
      <input
        type="checkbox"
        checked={isChecked}
        onChange={handle}
        disabled={disabled}
        style={{ position: 'absolute', opacity: 0, width: 0, height: 0 }}
        {...rest}
      />
      <span className="cds--checkbox__box">
        {isChecked && <Icon name="checkmark" className="cds--checkbox__check" size={12} />}
      </span>
      {label && <span className="cds--checkbox__label">{label}</span>}
    </label>
  );
}
