Search field with a leading magnifier and a clear button that appears when filled.

```jsx
<Search placeholder="Search resources" value={q} onChange={setQ} />
```

- `size`: sm/md/lg. `onClear` fires when the clear button is pressed.