import React from 'react';

const STYLE_ID = 'cds-toggle-styles';
const CSS = `
.cds--toggle { display: inline-flex; flex-direction: column; font-family: var(--cds-font-sans); }
.cds--toggle__label-text { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 8px; }
.cds--toggle__row { display: inline-flex; align-items: center; gap: 12px; cursor: pointer; }
.cds--toggle--disabled .cds--toggle__row { cursor: not-allowed; }
.cds--toggle__track {
  position: relative;
  width: 48px; height: 24px;
  flex: 0 0 auto;
  background: var(--cds-toggle-off);
  border-radius: 999px;
  transition: background var(--cds-duration-fast-02) var(--cds-ease-standard-productive);
}
.cds--toggle__track--sm { width: 32px; height: 16px; }
.cds--toggle__knob {
  position: absolute; top: 3px; left: 3px;
  width: 18px; height: 18px;
  background: var(--cds-white);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  transition: transform var(--cds-duration-fast-02) var(--cds-ease-standard-productive);
}
.cds--toggle__track--sm .cds--toggle__knob { width: 10px; height: 10px; top: 3px; left: 3px; }
.cds--toggle--checked .cds--toggle__track { background: var(--cds-support-success); }
.cds--toggle--checked .cds--toggle__knob { transform: translateX(24px); }
.cds--toggle--checked .cds--toggle__track--sm .cds--toggle__knob { transform: translateX(16px); }
.cds--toggle__knob::after {
  content: ""; display: none;
  width: 8px; height: 4px;
  border-left: 1.5px solid var(--cds-support-success);
  border-bottom: 1.5px solid var(--cds-support-success);
  transform: rotate(-45deg) translateY(-1px);
}
.cds--toggle--checked .cds--toggle__track:not(.cds--toggle__track--sm) .cds--toggle__knob::after { display: block; }
.cds--toggle--disabled .cds--toggle__track { background: var(--cds-border-disabled); }
.cds--toggle__state { font-size: .875rem; color: var(--cds-text-primary); }
.cds--toggle__row:focus-within .cds--toggle__track { outline: 2px solid var(--cds-focus); outline-offset: 1px; }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Toggle — on/off switch that turns green when on, with optional state label. */
export function Toggle({
  label,
  checked,
  defaultChecked,
  onChange,
  size = 'md',
  labelOn = 'On',
  labelOff = 'Off',
  hideStateLabel = false,
  disabled = false,
  className = '',
  style = {},
}) {
  useStyles();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isChecked = isControlled ? checked : internal;

  function toggle() {
    if (disabled) return;
    const next = !isChecked;
    if (!isControlled) setInternal(next);
    onChange && onChange(next);
  }

  return (
    <div
      className={[
        'cds--toggle',
        isChecked ? 'cds--toggle--checked' : '',
        disabled ? 'cds--toggle--disabled' : '',
        className,
      ].filter(Boolean).join(' ')}
      style={style}
    >
      {label && <span className="cds--toggle__label-text">{label}</span>}
      <div
        className="cds--toggle__row"
        role="switch"
        aria-checked={isChecked}
        tabIndex={disabled ? -1 : 0}
        onClick={toggle}
        onKeyDown={(e) => { if (e.key === ' ' || e.key === 'Enter') { e.preventDefault(); toggle(); } }}
      >
        <span className={`cds--toggle__track ${size === 'sm' ? 'cds--toggle__track--sm' : ''}`}>
          <span className="cds--toggle__knob" />
        </span>
        {!hideStateLabel && size !== 'sm' && (
          <span className="cds--toggle__state">{isChecked ? labelOn : labelOff}</span>
        )}
      </div>
    </div>
  );
}
