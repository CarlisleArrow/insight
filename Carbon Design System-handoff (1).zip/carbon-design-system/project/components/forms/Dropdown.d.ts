import * as React from 'react';

export interface DropdownItem {
  label: string;
  value: string;
}

export interface DropdownProps {
  /** Label above the field. */
  label?: string;
  /** Options — strings or {label, value} objects. */
  items: (string | DropdownItem)[];
  /** Controlled selected value. */
  value?: string;
  placeholder?: string;
  onChange?: (value: string) => void;
  className?: string;
  style?: React.CSSProperties;
}

/** Single-select listbox styled as a Carbon field. */
export function Dropdown(props: DropdownProps): JSX.Element;
