import * as React from 'react';

export interface SearchProps {
  placeholder?: string;
  /** Controlled value. */
  value?: string;
  defaultValue?: string;
  onChange?: (value: string, e?: React.ChangeEvent<HTMLInputElement>) => void;
  onClear?: () => void;
  /** Control height. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  style?: React.CSSProperties;
}

/** Search field with leading magnifier icon and a clear button. */
export function Search(props: SearchProps): JSX.Element;
