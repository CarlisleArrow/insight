import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-dropdown-styles';
const CSS = `
.cds--dropdown { display: flex; flex-direction: column; font-family: var(--cds-font-sans); position: relative; }
.cds--dropdown__label { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 6px; }
.cds--dropdown__trigger {
  display: flex; align-items: center; justify-content: space-between;
  width: 100%; height: 40px; box-sizing: border-box;
  padding: 0 16px;
  background: var(--cds-field-01);
  border: none; border-bottom: 1px solid var(--cds-border-strong-01);
  border-radius: 0; cursor: pointer; text-align: left;
  font-size: .875rem; letter-spacing: .16px; color: var(--cds-text-primary);
  outline: 2px solid transparent; outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01);
}
.cds--dropdown__trigger:focus-visible { outline: 2px solid var(--cds-focus); }
.cds--dropdown__trigger--placeholder { color: var(--cds-text-placeholder); }
.cds--dropdown__chevron { transition: transform var(--cds-duration-fast-02) var(--cds-ease-standard-productive); color: var(--cds-icon-primary); }
.cds--dropdown--open .cds--dropdown__chevron { transform: rotate(180deg); }
.cds--dropdown__menu {
  position: absolute; top: 100%; left: 0; right: 0; z-index: 20;
  background: var(--cds-layer-02);
  box-shadow: var(--cds-shadow-menu);
  max-height: 240px; overflow-y: auto; list-style: none; margin: 0; padding: 0;
}
.cds--dropdown__item {
  display: flex; align-items: center; height: 40px; padding: 0 16px;
  font-size: .875rem; color: var(--cds-text-secondary); cursor: pointer;
  border-bottom: 1px solid var(--cds-border-subtle-01);
}
.cds--dropdown__item:hover { background: var(--cds-layer-hover-01); color: var(--cds-text-primary); }
.cds--dropdown__item--selected { color: var(--cds-text-primary); font-weight: 600; }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Dropdown — single-select listbox styled as a Carbon field. */
export function Dropdown({
  label,
  items = [],
  value,
  placeholder = 'Choose an option',
  onChange,
  className = '',
  style = {},
}) {
  useStyles();
  const [open, setOpen] = React.useState(false);
  const [internal, setInternal] = React.useState(value);
  const ref = React.useRef(null);
  const selected = value !== undefined ? value : internal;

  React.useEffect(() => {
    function onDoc(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const normalized = items.map((it) => (typeof it === 'string' ? { label: it, value: it } : it));
  const current = normalized.find((it) => it.value === selected);

  function pick(it) {
    if (value === undefined) setInternal(it.value);
    onChange && onChange(it.value);
    setOpen(false);
  }

  return (
    <div ref={ref} className={`cds--dropdown ${open ? 'cds--dropdown--open' : ''} ${className}`} style={style}>
      {label && <span className="cds--dropdown__label">{label}</span>}
      <button
        type="button"
        className={`cds--dropdown__trigger ${current ? '' : 'cds--dropdown__trigger--placeholder'}`}
        onClick={() => setOpen((o) => !o)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span>{current ? current.label : placeholder}</span>
        <Icon name="chevron--down" className="cds--dropdown__chevron" />
      </button>
      {open && (
        <ul className="cds--dropdown__menu" role="listbox">
          {normalized.map((it) => (
            <li
              key={it.value}
              role="option"
              aria-selected={it.value === selected}
              className={`cds--dropdown__item ${it.value === selected ? 'cds--dropdown__item--selected' : ''}`}
              onClick={() => pick(it)}
            >
              {it.label}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
