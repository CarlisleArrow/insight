On/off switch that turns green when on, with an optional state label.

```jsx
<Toggle label="High availability" defaultChecked />
<Toggle size="sm" hideStateLabel />
```

- `size`: md (48×24, shows On/Off) or sm (32×16). Customize text with `labelOn`/`labelOff`.