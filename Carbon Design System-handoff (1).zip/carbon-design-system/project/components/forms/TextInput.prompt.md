Single-line text field with label, helper text and error states.

```jsx
<TextInput label="Email" placeholder="name@example.com" helperText="We never share it." />
<TextInput label="Token" invalid invalidText="Required field." />
```

- `size`: sm/md/lg. `invalid` + `invalidText` show the red error treatment with a warning icon.