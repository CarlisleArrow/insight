import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-search-styles';
const CSS = `
.cds--search { position: relative; display: flex; align-items: center; width: 100%; font-family: var(--cds-font-sans); }
.cds--search__magnifier { position: absolute; left: 12px; color: var(--cds-icon-secondary); pointer-events: none; }
.cds--search__input {
  width: 100%; height: 40px; box-sizing: border-box;
  padding: 0 40px 0 40px;
  background: var(--cds-field-01);
  border: none; border-bottom: 1px solid transparent;
  border-radius: 0;
  font-size: .875rem; letter-spacing: .16px; color: var(--cds-text-primary);
  outline: 2px solid transparent; outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--search__input::placeholder { color: var(--cds-text-placeholder); }
.cds--search__input:focus { outline: 2px solid var(--cds-focus); }
.cds--search--sm .cds--search__input { height: 32px; }
.cds--search--lg .cds--search__input { height: 48px; }
.cds--search__clear {
  position: absolute; right: 0; height: 100%; width: 40px;
  display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; cursor: pointer; color: var(--cds-icon-primary);
  opacity: 0; pointer-events: none; transition: opacity var(--cds-duration-fast-01);
}
.cds--search__clear--visible { opacity: 1; pointer-events: auto; }
.cds--search__clear:hover { background: var(--cds-background-hover); }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Search — input with a leading magnifier and a clear button. */
export function Search({
  placeholder = 'Search',
  value,
  defaultValue = '',
  onChange,
  onClear,
  size = 'md',
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue);
  const val = isControlled ? value : internal;

  function handle(e) {
    if (!isControlled) setInternal(e.target.value);
    onChange && onChange(e.target.value, e);
  }
  function clear() {
    if (!isControlled) setInternal('');
    onChange && onChange('');
    onClear && onClear();
  }

  return (
    <div className={`cds--search cds--search--${size} ${className}`} style={style}>
      <Icon name="search" className="cds--search__magnifier" />
      <input
        type="text"
        className="cds--search__input"
        placeholder={placeholder}
        value={val}
        onChange={handle}
        {...rest}
      />
      <button
        type="button"
        className={`cds--search__clear ${val ? 'cds--search__clear--visible' : ''}`}
        onClick={clear}
        aria-label="Clear search"
        tabIndex={val ? 0 : -1}
      >
        <Icon name="close" />
      </button>
    </div>
  );
}
