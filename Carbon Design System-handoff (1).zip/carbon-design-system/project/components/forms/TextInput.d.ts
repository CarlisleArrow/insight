import * as React from 'react';

export interface TextInputProps {
  /** Field label (Carbon label-01, sits above the field). */
  label?: string;
  placeholder?: string;
  value?: string;
  defaultValue?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  type?: string;
  /** Control height. @default "md" */
  size?: 'sm' | 'md' | 'lg';
  /** Muted helper text below the field. */
  helperText?: string;
  /** Error state: red outline + warning icon. */
  invalid?: boolean;
  /** Error message (shown when invalid). */
  invalidText?: string;
  disabled?: boolean;
  id?: string;
  className?: string;
  style?: React.CSSProperties;
}

/** Single-line text field with label, helper and error states. */
export function TextInput(props: TextInputProps): JSX.Element;
