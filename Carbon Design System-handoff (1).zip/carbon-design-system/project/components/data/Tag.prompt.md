Pill-shaped categorization label; supports a leading icon and a dismiss button.

```jsx
<Tag type="green" icon="checkmark">Running</Tag>
<Tag type="blue" filter onClose={remove}>Region: US South</Tag>
```

- `type`: gray, cool-gray, blue, green, red, magenta, purple, cyan, teal, high-contrast, outline. `filter` adds the close button.