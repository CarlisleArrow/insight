Line-style tab navigation; renders the active tab's content panel if provided.

```jsx
<Tabs tabs={[{label:'Overview', content:<Overview/>}, {label:'Billing', content:<Billing/>}]} />
```

- Pass `selectedIndex`/`onChange` for controlled use. Items can set `disabled`.