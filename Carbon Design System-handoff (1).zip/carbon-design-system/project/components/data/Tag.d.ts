import * as React from 'react';

export type TagType =
  | 'gray' | 'cool-gray' | 'blue' | 'green' | 'red' | 'magenta'
  | 'purple' | 'cyan' | 'teal' | 'high-contrast' | 'outline';

export interface TagProps {
  children?: React.ReactNode;
  /** Color variant. @default "gray" */
  type?: TagType;
  /** "md" (24px) or "sm" (18px). @default "md" */
  size?: 'sm' | 'md';
  /** Leading icon name. */
  icon?: string;
  /** Render a dismissible filter tag with a close button. */
  filter?: boolean;
  onClose?: (e: React.MouseEvent) => void;
  className?: string;
  style?: React.CSSProperties;
}

/** Pill-shaped categorization label; supports a leading icon and dismiss button. */
export function Tag(props: TagProps): JSX.Element;
