import * as React from 'react';

export interface TabItem {
  label: string;
  content?: React.ReactNode;
  disabled?: boolean;
}

export interface TabsProps {
  /** Tabs — strings or {label, content, disabled} objects. */
  tabs: (string | TabItem)[];
  /** Controlled active index. */
  selectedIndex?: number;
  defaultIndex?: number;
  onChange?: (index: number) => void;
  className?: string;
  style?: React.CSSProperties;
}

/** Line-style tab navigation; renders the active tab's content panel if provided. */
export function Tabs(props: TabsProps): JSX.Element;
