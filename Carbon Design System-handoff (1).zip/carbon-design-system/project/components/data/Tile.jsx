import React from 'react';

const STYLE_ID = 'cds-tile-styles';
const CSS = `
.cds--tile {
  position: relative;
  box-sizing: border-box;
  background: var(--cds-layer-01);
  padding: 16px;
  border: 1px solid transparent;
  border-radius: 0;
  font-family: var(--cds-font-sans);
  color: var(--cds-text-primary);
}
.cds--tile--clickable { cursor: pointer; transition: background var(--cds-duration-fast-01); display: block; text-decoration: none; }
.cds--tile--clickable:hover { background: var(--cds-layer-hover-01); }
.cds--tile--selectable { cursor: pointer; transition: background var(--cds-duration-fast-01); }
.cds--tile--selectable:hover { background: var(--cds-layer-hover-01); }
.cds--tile--selected { border-color: var(--cds-border-interactive); }
.cds--tile__check {
  position: absolute; top: 16px; right: 16px;
  width: 16px; height: 16px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  border: 1px solid var(--cds-icon-primary);
}
.cds--tile--selected .cds--tile__check { background: var(--cds-border-interactive); border-color: var(--cds-border-interactive); }
.cds--tile--selected .cds--tile__check::after {
  content: ""; width: 7px; height: 4px;
  border-left: 1.5px solid var(--cds-white); border-bottom: 1.5px solid var(--cds-white);
  transform: rotate(-45deg) translateY(-1px);
}
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tile — Carbon's container/card. Variants: base, clickable, selectable. */
export function Tile({
  children,
  variant = 'base',
  selected = false,
  href,
  onClick,
  className = '',
  style = {},
}) {
  useStyles();
  const classes = [
    'cds--tile',
    variant === 'clickable' ? 'cds--tile--clickable' : '',
    variant === 'selectable' ? 'cds--tile--selectable' : '',
    selected ? 'cds--tile--selected' : '',
    className,
  ].filter(Boolean).join(' ');

  if (variant === 'clickable' && href) {
    return (
      <a className={classes} href={href} onClick={onClick} style={style}>
        {children}
      </a>
    );
  }
  return (
    <div className={classes} onClick={onClick} style={style}>
      {variant === 'selectable' && <span className="cds--tile__check" />}
      {children}
    </div>
  );
}
