import React from 'react';

const STYLE_ID = 'cds-tabs-styles';
const CSS = `
.cds--tabs { font-family: var(--cds-font-sans); }
.cds--tabs__list { display: flex; list-style: none; margin: 0; padding: 0; box-shadow: inset 0 -1px 0 var(--cds-border-subtle-01); }
.cds--tab {
  appearance: none; background: transparent; border: none; cursor: pointer;
  padding: 0 16px; height: 48px;
  font-size: .875rem; line-height: 1.28572; letter-spacing: .16px;
  color: var(--cds-text-secondary);
  box-shadow: inset 0 -1px 0 var(--cds-border-subtle-01);
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  transition: color var(--cds-duration-fast-01), border-color var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--tab:hover { color: var(--cds-text-primary); box-shadow: inset 0 -1px 0 var(--cds-border-strong-01); }
.cds--tab--selected { color: var(--cds-text-primary); font-weight: 600; border-bottom: 2px solid var(--cds-border-interactive); box-shadow: none; }
.cds--tab:disabled { color: var(--cds-text-disabled); cursor: not-allowed; }
.cds--tab:focus-visible { outline: 2px solid var(--cds-focus); outline-offset: -2px; }
.cds--tabs__panel { padding: 16px 0; font-size: .875rem; color: var(--cds-text-primary); }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tabs — line-style tab navigation with optional panel content. */
export function Tabs({
  tabs = [],
  selectedIndex,
  defaultIndex = 0,
  onChange,
  className = '',
  style = {},
}) {
  useStyles();
  const isControlled = selectedIndex !== undefined;
  const [internal, setInternal] = React.useState(defaultIndex);
  const active = isControlled ? selectedIndex : internal;

  function select(i, disabled) {
    if (disabled) return;
    if (!isControlled) setInternal(i);
    onChange && onChange(i);
  }

  const normalized = tabs.map((t) => (typeof t === 'string' ? { label: t } : t));

  return (
    <div className={`cds--tabs ${className}`} style={style}>
      <ul className="cds--tabs__list" role="tablist">
        {normalized.map((t, i) => (
          <li key={i} role="presentation">
            <button
              role="tab"
              aria-selected={i === active}
              disabled={t.disabled}
              className={`cds--tab ${i === active ? 'cds--tab--selected' : ''}`}
              onClick={() => select(i, t.disabled)}
            >
              {t.label}
            </button>
          </li>
        ))}
      </ul>
      {normalized[active] && normalized[active].content !== undefined && (
        <div className="cds--tabs__panel" role="tabpanel">
          {normalized[active].content}
        </div>
      )}
    </div>
  );
}
