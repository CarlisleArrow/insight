Carbon's container/card. Base, clickable (links + hover), or selectable (shows a check).

```jsx
<Tile><h4>Title</h4><p>Body</p></Tile>
<Tile variant="clickable" href="/x">…</Tile>
<Tile variant="selectable" selected>…</Tile>
```

- Square corners, layer background, 1px interactive border when selected.