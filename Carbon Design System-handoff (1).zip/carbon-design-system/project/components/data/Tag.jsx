import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-tag-styles';
const CSS = `
.cds--tag {
  display: inline-flex; align-items: center; gap: 6px;
  box-sizing: border-box;
  height: 24px; padding: 0 8px;
  font-family: var(--cds-font-sans);
  font-size: .75rem; line-height: 1; letter-spacing: .32px;
  border-radius: 999px;
  border: none; white-space: nowrap; max-width: 100%;
}
.cds--tag--sm { height: 18px; }
.cds--tag__label { overflow: hidden; text-overflow: ellipsis; }
.cds--tag__close {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; margin-right: -4px;
  background: transparent; border: none; cursor: pointer; color: inherit;
  border-radius: 50%;
}
.cds--tag__close:hover { background: rgba(0,0,0,.16); }

.cds--tag--gray      { background: var(--cds-gray-20);    color: var(--cds-gray-100); }
.cds--tag--cool-gray { background: var(--cds-cool-gray-30);color: var(--cds-cool-gray-90); }
.cds--tag--blue      { background: var(--cds-blue-20);    color: var(--cds-blue-70); }
.cds--tag--green     { background: var(--cds-green-20);   color: var(--cds-green-70); }
.cds--tag--red       { background: var(--cds-red-20);     color: var(--cds-red-70); }
.cds--tag--magenta   { background: var(--cds-magenta-20); color: var(--cds-magenta-70); }
.cds--tag--purple    { background: var(--cds-purple-20);  color: var(--cds-purple-70); }
.cds--tag--cyan      { background: var(--cds-cyan-20);    color: var(--cds-cyan-70); }
.cds--tag--teal      { background: var(--cds-teal-10);    color: var(--cds-teal-70); }
.cds--tag--high-contrast { background: var(--cds-background-inverse); color: var(--cds-text-inverse); }
.cds--tag--outline   { background: transparent; color: var(--cds-text-primary); box-shadow: inset 0 0 0 1px var(--cds-border-strong-01); }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tag — pill-shaped label for categorization, optionally with an icon or a dismiss button. */
export function Tag({
  children,
  type = 'gray',
  size = 'md',
  icon,
  filter = false,
  onClose,
  className = '',
  style = {},
}) {
  useStyles();
  return (
    <span
      className={['cds--tag', `cds--tag--${type}`, `cds--tag--${size}`, className].filter(Boolean).join(' ')}
      style={style}
    >
      {icon && <Icon name={icon} size={size === 'sm' ? 12 : 16} />}
      <span className="cds--tag__label">{children}</span>
      {filter && (
        <button type="button" className="cds--tag__close" onClick={onClose} aria-label="Dismiss">
          <Icon name="close" size={12} />
        </button>
      )}
    </span>
  );
}
