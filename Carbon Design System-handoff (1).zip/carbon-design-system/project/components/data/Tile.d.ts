import * as React from 'react';

export interface TileProps {
  children?: React.ReactNode;
  /** "base" (static), "clickable" (hover + link), "selectable" (shows a check). @default "base" */
  variant?: 'base' | 'clickable' | 'selectable';
  /** Selected state (selectable tiles). */
  selected?: boolean;
  /** href for clickable tiles. */
  href?: string;
  onClick?: (e: React.MouseEvent) => void;
  className?: string;
  style?: React.CSSProperties;
}

/** Carbon container/card. Base, clickable, or selectable. */
export function Tile(props: TileProps): JSX.Element;
