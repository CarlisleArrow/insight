Inline status message with a colored left accent and status icon.

```jsx
<InlineNotification kind="error" title="Failed." subtitle="Check the logs." onClose={dismiss} />
```

- `kind`: error, success, warning, info. `hideCloseButton` removes the dismiss control.