import * as React from 'react';

export interface InlineNotificationProps {
  /** Status. @default "info" */
  kind?: 'error' | 'success' | 'warning' | 'info';
  /** Bold lead text. */
  title?: string;
  /** Detail text following the title. */
  subtitle?: string;
  onClose?: (e: React.MouseEvent) => void;
  hideCloseButton?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

/** Inline status message with colored left accent + status icon. */
export function InlineNotification(props: InlineNotificationProps): JSX.Element;
