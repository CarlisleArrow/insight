Circular activity spinner in Carbon interactive blue.

```jsx
<Loading size="md" />
```

- `size`: sm (16px), md (44px), lg (88px, default).