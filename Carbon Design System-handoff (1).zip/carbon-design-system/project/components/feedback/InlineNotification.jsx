import React from 'react';
import { Icon } from '../core/Icon';

const STYLE_ID = 'cds-notification-styles';
const CSS = `
.cds--notif {
  display: flex; align-items: flex-start; gap: 12px;
  box-sizing: border-box; min-height: 48px;
  padding: 14px 16px;
  font-family: var(--cds-font-sans);
  border-left: 3px solid transparent;
  background: var(--cds-layer-01);
  color: var(--cds-text-primary);
  box-shadow: inset 0 0 0 1px rgba(0,0,0,0.04);
}
.cds--notif__icon { flex: 0 0 auto; margin-top: 1px; }
.cds--notif__body { flex: 1; font-size: .875rem; line-height: 1.42857; letter-spacing: .16px; }
.cds--notif__title { font-weight: 600; margin-right: 4px; }
.cds--notif__close {
  flex: 0 0 auto; width: 20px; height: 20px; margin: -2px -4px 0 0;
  background: transparent; border: none; cursor: pointer; color: var(--cds-icon-primary);
  display: flex; align-items: center; justify-content: center;
}
.cds--notif__close:hover { background: var(--cds-background-hover); }

.cds--notif--error   { border-left-color: var(--cds-support-error); }
.cds--notif--error   .cds--notif__icon { color: var(--cds-support-error); }
.cds--notif--success { border-left-color: var(--cds-support-success); }
.cds--notif--success .cds--notif__icon { color: var(--cds-support-success); }
.cds--notif--warning { border-left-color: var(--cds-support-warning); }
.cds--notif--warning .cds--notif__icon { color: var(--cds-support-warning); }
.cds--notif--info    { border-left-color: var(--cds-support-info); }
.cds--notif--info    .cds--notif__icon { color: var(--cds-support-info); }
`;

const ICONS = {
  error: 'error--filled',
  success: 'checkmark--filled',
  warning: 'warning--filled',
  info: 'information--filled',
};

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** InlineNotification — status message with a colored left accent and status icon. */
export function InlineNotification({
  kind = 'info',
  title,
  subtitle,
  onClose,
  hideCloseButton = false,
  className = '',
  style = {},
}) {
  useStyles();
  return (
    <div role="status" className={`cds--notif cds--notif--${kind} ${className}`} style={style}>
      <Icon name={ICONS[kind]} className="cds--notif__icon" />
      <div className="cds--notif__body">
        {title && <span className="cds--notif__title">{title}</span>}
        {subtitle && <span>{subtitle}</span>}
      </div>
      {!hideCloseButton && (
        <button type="button" className="cds--notif__close" onClick={onClose} aria-label="Close notification">
          <Icon name="close" />
        </button>
      )}
    </div>
  );
}
