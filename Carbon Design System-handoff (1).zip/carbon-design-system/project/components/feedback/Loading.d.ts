import * as React from 'react';

export interface LoadingProps {
  /** "sm" (16px), "md" (44px), "lg" (88px). @default "lg" */
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  style?: React.CSSProperties;
}

/** Circular activity spinner. */
export function Loading(props: LoadingProps): JSX.Element;
