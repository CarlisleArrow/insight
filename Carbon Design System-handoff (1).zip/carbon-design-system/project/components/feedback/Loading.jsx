import React from 'react';

const STYLE_ID = 'cds-loading-styles';
const CSS = `
@keyframes cds-spin { to { transform: rotate(360deg); } }
.cds--loading {
  display: inline-block;
  width: 88px; height: 88px;
  border-radius: 50%;
  border: 10px solid var(--cds-border-subtle-01);
  border-top-color: var(--cds-interactive);
  animation: cds-spin 690ms linear infinite;
}
.cds--loading--sm { width: 16px; height: 16px; border-width: 2px; }
.cds--loading--md { width: 44px; height: 44px; border-width: 5px; }
`;

function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Loading — circular activity spinner. */
export function Loading({ size = 'lg', className = '', style = {} }) {
  useStyles();
  const sz = size === 'sm' ? 'cds--loading--sm' : size === 'md' ? 'cds--loading--md' : '';
  return <div role="status" aria-label="Loading" className={`cds--loading ${sz} ${className}`} style={style} />;
}
