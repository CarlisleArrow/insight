/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, SidePanel, Placeholder, StatusDot, ToolBtn, tr, trList */
const { Icon, Tag, Button, Search, TextInput, Dropdown, Checkbox, Tabs } = window.CarbonDesignSystem_280d33;

const GOV_CSS = `
.gv-catalog { display:grid; grid-template-columns:240px 1fr; gap:16px; align-items:start; }
.gv-facets { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.gv-facets__grp { padding:12px 16px; border-bottom:1px solid var(--wire-border); }
.gv-facets__grp:last-child { border-bottom:none; }
.gv-facets__grp h4 { font-size:.75rem; font-weight:600; margin:0 0 10px; color:var(--cds-text-primary); display:flex; align-items:center; }
.gv-facets__grp h4 .c { margin-left:auto; font-weight:400; color:var(--cds-text-secondary); }
.gv-facets__opt { display:flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-secondary); padding:4px 0; }
.gv-score { display:inline-flex; align-items:center; gap:6px; font-size:.8125rem; }
.gv-score .track { width:48px; height:6px; background:var(--cds-layer-01); position:relative; }
.gv-score .track i { position:absolute; left:0; top:0; bottom:0; }
.gv-layerchip { font-family:var(--cds-font-mono); font-size:.6875rem; }

/* asset detail */
.gv-detail__top { display:flex; align-items:flex-start; gap:24px; margin-bottom:24px; }
.gv-detail__stats { display:flex; gap:32px; margin-left:auto; }
.gv-detail__stats .s .v { font-size:1.5rem; font-weight:300; color:var(--cds-text-primary); }
.gv-detail__stats .s .k { font-size:.75rem; color:var(--cds-text-secondary); }

/* lineage */
.gv-lin { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.gv-lincanvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.gv-linnode { position:absolute; width:150px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); cursor:pointer; }
.gv-linnode.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.gv-linnode__h { display:flex; align-items:center; gap:6px; padding:8px 10px; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); border-bottom:1px solid var(--wire-border); }
.gv-linnode__f { padding:4px 10px; font-size:.6875rem; font-family:var(--cds-font-mono); color:var(--cds-text-secondary); border-bottom:1px solid var(--wire-border); display:flex; align-items:center; gap:6px; }
.gv-linnode__f:last-child { border-bottom:none; }
.gv-linnode__f .exp { margin-left:auto; color:var(--cds-link-primary); cursor:pointer; }

/* access matrix */
.gv-matrix { width:100%; border-collapse:collapse; font-family:var(--cds-font-sans); border:1px solid var(--wire-border); }
.gv-matrix th, .gv-matrix td { border:1px solid var(--wire-border); padding:8px 12px; font-size:.8125rem; text-align:center; }
.gv-matrix th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.gv-matrix td:first-child, .gv-matrix th:first-child { text-align:left; }
.gv-matrix td.col { color:var(--cds-text-primary); font-weight:500; }
.gv-iam { display:inline-flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-secondary); background:var(--cds-layer-01); border:1px solid var(--wire-border); padding:6px 12px; }
`;
(function(){ if (!document.getElementById('ipas-gov-styles')) { const e=document.createElement('style'); e.id='ipas-gov-styles'; e.textContent=GOV_CSS; document.head.appendChild(e);} })();

const ASSETS = [
  { id: 1, name: 'fact_production', layer: 'Gold', desc: 'Production events by line, shift, and product', owner: 'L. Marsh', score: 96, sens: 'Internal' },
  { id: 2, name: 'orders', layer: 'Silver', desc: 'Cleaned customer orders from ERP', owner: 'A. Okafor', score: 88, sens: 'Confidential' },
  { id: 3, name: 'customers', layer: 'Silver', desc: 'Customer master with contact details', owner: 'A. Okafor', score: 74, sens: 'PII' },
  { id: 4, name: 'raw_mes_events', layer: 'RAW', desc: 'Unprocessed MES machine telemetry', owner: 'M. Díaz', score: 61, sens: 'Internal' },
  { id: 5, name: 'dim_product', layer: 'Gold', desc: 'Conformed product dimension', owner: 'L. Marsh', score: 93, sens: 'Public' },
  { id: 6, name: 'agg_yield_daily', layer: 'Gold', desc: 'Daily yield aggregates for dashboards', owner: 'R. Vance', score: 90, sens: 'Internal' },
];
const LAYER_TAG = { RAW: 'cool-gray', Bronze: 'cool-gray', Silver: 'cyan', Gold: 'teal' };
const SENS_TAG = { PII: 'red', Confidential: 'purple', Internal: 'blue', Public: 'green' };

function ScoreBar({ v }) {
  const color = v >= 90 ? 'var(--cds-support-success)' : v >= 75 ? 'var(--cds-support-warning)' : 'var(--cds-support-error)';
  return <span className="gv-score"><span className="track"><i style={{ width: v + '%', background: color }} /></span>{v}</span>;
}

function Facet({ title, count, opts }) {
  return (
    <div className="gv-facets__grp">
      <h4>{title}<span className="c">{count}</span></h4>
      {opts.map((o) => <label key={o.l} className="gv-facets__opt"><Checkbox defaultChecked={o.on} label="" />{o.l}<span style={{ marginLeft: 'auto', color: 'var(--cds-text-placeholder)', fontSize: '.6875rem' }}>{o.n}</span></label>)}
    </div>
  );
}

function Catalog({ onOpen }) {
  const cols = [
    { key: 'name', label: 'Asset', cellClass: 'name' },
    { key: 'layer', label: 'Layer' },
    { key: 'desc', label: 'Description' },
    { key: 'owner', label: 'Owner' },
    { key: 'score', label: 'Quality' },
    { key: 'sens', label: 'Sensitivity' },
  ];
  return (
    <div className="gv-catalog">
      <aside className="gv-facets">
        <Facet title="Domain" count="" opts={[{ l: 'Manufacturing', n: 42, on: true }, { l: 'Finance', n: 18 }, { l: 'Logistics', n: 23 }, { l: 'Customer', n: 11 }]} />
        <Facet title="Source layer" count="" opts={[{ l: 'RAW', n: 64 }, { l: 'Bronze', n: 52 }, { l: 'Silver', n: 38, on: true }, { l: 'Gold', n: 26, on: true }]} />
        <Facet title="Sensitivity" count="" opts={[{ l: 'Public', n: 12 }, { l: 'Internal', n: 88 }, { l: 'Confidential', n: 21 }, { l: 'PII', n: 9 }]} />
        <Facet title="Owner" count="" opts={[{ l: 'L. Marsh', n: 14 }, { l: 'A. Okafor', n: 9 }, { l: 'R. Vance', n: 7 }]} />
      </aside>
      <div>
        <div style={{ marginBottom: 16 }}><Search size="lg" placeholder="Search the catalog — tables, fields, descriptions" /></div>
        <div style={{ display: 'flex', gap: 8, marginBottom: 12, alignItems: 'center' }}>
          <Tag type="blue" size="sm" filter onClose={() => {}}>layer: Silver</Tag>
          <Tag type="blue" size="sm" filter onClose={() => {}}>layer: Gold</Tag>
          <Tag type="blue" size="sm" filter onClose={() => {}}>domain: Manufacturing</Tag>
          <span style={{ marginLeft: 'auto', fontSize: '.75rem', color: 'var(--cds-text-secondary)' }}>186 assets</span>
        </div>
        <WireTable columns={cols} rows={ASSETS} total={186} onRowClick={onOpen}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => { e.preventDefault(); }}>{r.name}</a>;
            if (k === 'layer') return <Tag type={LAYER_TAG[r.layer]} size="sm"><span className="gv-layerchip">{r.layer}</span></Tag>;
            if (k === 'desc') return <span style={{ display: 'block', maxWidth: 260, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.desc}</span>;
            if (k === 'score') return <ScoreBar v={r.score} />;
            if (k === 'sens') return <Tag type={SENS_TAG[r.sens]} size="sm">{r.sens}</Tag>;
            return r[k];
          }} />
      </div>
    </div>
  );
}

function AssetDetail({ asset, onBack }) {
  const schemaCols = [
    { key: 'col', label: 'Column', cellClass: 'mono' }, { key: 'type', label: 'Type' }, { key: 'desc', label: 'Description' }, { key: 'sens', label: 'Sensitivity', sortable: false },
  ];
  const schema = [
    { col: 'line_id', type: 'varchar', desc: 'Production line identifier', sens: 'Internal' },
    { col: 'shift', type: 'varchar', desc: 'Shift name (Day/Night)', sens: 'Internal' },
    { col: 'units_produced', type: 'bigint', desc: 'Units produced in window', sens: 'Internal' },
    { col: 'defect_count', type: 'bigint', desc: 'Defective units', sens: 'Internal' },
    { col: 'yield_pct', type: 'double', desc: 'First-pass yield', sens: 'Internal' },
  ];
  const sampleCols = schema.slice(0, 4).map((s) => ({ key: s.col, label: s.col, sortable: false }));
  const sample = [
    { line_id: 'LINE-04', shift: 'Day', units_produced: '12,480', defect_count: '142' },
    { line_id: 'LINE-02', shift: 'Night', units_produced: '9,310', defect_count: '88' },
    { line_id: 'LINE-05', shift: 'Day', units_produced: '11,002', defect_count: '203' },
  ];
  return (
    <div>
      <Button kind="ghost" size="sm" icon="arrow--left" onClick={onBack} style={{ marginBottom: 12 }}>Back to catalog</Button>
      <div className="gv-detail__top">
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <h1 style={{ fontSize: '1.75rem', fontWeight: 400, margin: 0, fontFamily: 'var(--cds-font-mono)' }}>{asset.name}</h1>
            <Tag type={LAYER_TAG[asset.layer]} size="md">{asset.layer}</Tag>
            <Tag type={SENS_TAG[asset.sens]} size="md">{asset.sens}</Tag>
          </div>
          <p style={{ color: 'var(--cds-text-secondary)', fontSize: '.875rem', margin: '8px 0 0' }}>{asset.desc} · Owner {asset.owner}</p>
        </div>
        <div className="gv-detail__stats">
          <div className="s"><div className="v">{asset.score}</div><div className="k">Quality score</div></div>
          <div className="s"><div className="v">38</div><div className="k">Downstream</div></div>
          <div className="s"><div className="v">1.2k</div><div className="k">Queries / wk</div></div>
        </div>
      </div>
      <Tabs tabs={[
        { label: 'Schema', content: <div style={{ marginTop: 8 }}><WireTable columns={schemaCols} rows={schema} footer={false} renderCell={(r, k) => k === 'sens' ? <Tag type="blue" size="sm">{r.sens}</Tag> : r[k]} /></div> },
        { label: 'Sample data', content: <div style={{ marginTop: 8 }}><WireTable columns={sampleCols} rows={sample} footer={false} renderCell={(r, k) => <span style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem' }}>{r[k]}</span>} /></div> },
        { label: 'Lineage', content: <div style={{ marginTop: 8 }}><Placeholder label="upstream / downstream lineage graph" icon="data--base" height={280} /></div> },
        { label: 'Usage', content: <div style={{ marginTop: 8 }}><Placeholder label="queries over time · top consumers" icon="analytics" height={280} /></div> },
      ]} />
    </div>
  );
}

/* ---- Lineage graph ---- */
const LIN_LAYERS = ['RAW', 'Bronze', 'Silver', 'Gold', 'ClickHouse'];
const LIN_NODES = [
  { id: 'l1', layer: 0, y: 120, label: 'raw_mes_events', fields: ['event_ts', 'machine_id', 'payload'] },
  { id: 'l2', layer: 1, y: 120, label: 'mes_clean', fields: ['ts', 'line_id', 'metric'] },
  { id: 'l3', layer: 2, y: 60, label: 'orders', fields: ['order_id', 'customer_id'] },
  { id: 'l4', layer: 2, y: 240, label: 'production', fields: ['line_id', 'units', 'defects'] },
  { id: 'l5', layer: 3, y: 150, label: 'fact_production', fields: ['line_id', 'yield_pct', 'units_produced'] },
  { id: 'l6', layer: 4, y: 150, label: 'ch.agg_yield', fields: ['line_id', 'avg_yield'] },
];
const LIN_EDGES = [['l1', 'l2'], ['l2', 'l4'], ['l3', 'l5'], ['l4', 'l5'], ['l5', 'l6']];
const LINW = 150, LINCOLW = 200, LINX = (l) => l * LINCOLW + 24;

function LineageGraph() {
  const [sel, setSel] = React.useState('l5');
  const pos = {}; LIN_NODES.forEach((n) => { pos[n.id] = { x: LINX(n.layer), y: n.y, cx: LINX(n.layer) + LINW, cyc: n.y + 20 }; });
  const sn = LIN_NODES.find((n) => n.id === sel);
  const [drawer, setDrawer] = React.useState(false);
  return (
    <div className="gv-lin">
      <div className="w-etoolbar">
        <ToolBtn icon="search" label="Find asset" />
        <span className="gap" />
        <ToolBtn icon="add" label="Expand all fields" />
        <span className="spacer" />
        <ToolBtn icon="zoom--out" label="" title="Zoom out" />
        <ToolBtn icon="zoom--in" label="" title="Zoom in" />
        <ToolBtn icon="maximize" label="" title="Fit" />
      </div>
      <div className="gv-lincanvas">
        <div className="dv-layer-labels">{LIN_LAYERS.map((l) => <div key={l} className="ll" style={{ width: LINCOLW }}>{l}</div>)}</div>
        <svg style={{ position: 'absolute', inset: 0, width: '100%', height: 460, pointerEvents: 'none' }}>
          <defs><marker id="larr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="var(--cds-blue-60)" /></marker></defs>
          {LIN_EDGES.map(([a, b], i) => {
            const p = pos[a], q = pos[b]; const mx = (p.cx + q.x) / 2;
            return <path key={i} d={`M ${p.cx} ${p.cyc} C ${mx} ${p.cyc}, ${mx} ${q.cyc}, ${q.x} ${q.cyc}`} stroke="var(--cds-blue-60)" strokeWidth="1.5" fill="none" markerEnd="url(#larr)" />;
          })}
        </svg>
        {LIN_NODES.map((n) => (
          <div key={n.id} className={`gv-linnode ${sel === n.id ? 'sel' : ''}`} style={{ left: pos[n.id].x, top: n.y }} onClick={() => { setSel(n.id); setDrawer(true); }}>
            <div className="gv-linnode__h"><Icon name="data--base" size={16} />{n.label}</div>
            {n.fields.map((f) => <div key={f} className="gv-linnode__f">{f}<span className="exp"><Icon name="chevron--right" size={16} /></span></div>)}
          </div>
        ))}
      </div>
      {drawer && (
        <SidePanel sup="Lineage" title={sn.label} width={360} onClose={() => setDrawer(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setDrawer(false)}>Close</Button><Button kind="primary" icon="launch">Open asset</Button></React.Fragment>}>
          <StatusDot kind="success">Fresh · updated 14m ago</StatusDot>
          <div className="w-fld"><label>Fields ({sn.fields.length})</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>{sn.fields.map((f) => <div key={f} style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.75rem', color: 'var(--cds-text-primary)', display: 'flex', alignItems: 'center', gap: 8 }}><Icon name="chevron--right" size={16} style={{ color: 'var(--cds-icon-secondary)' }} />{f}</div>)}</div>
          </div>
          <div className="w-fld"><label>Upstream</label><div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}><Tag type="cool-gray" size="sm">orders</Tag><Tag type="cool-gray" size="sm">production</Tag></div></div>
          <div className="w-fld"><label>Downstream</label><div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}><Tag type="cool-gray" size="sm">ch.agg_yield</Tag><Tag type="cool-gray" size="sm">3 dashboards</Tag></div></div>
        </SidePanel>
      )}
    </div>
  );
}

/* ---- Access Control (RBAC + ABAC) ---- */
const MASK_PREVIEW = { deny: 'NULL', full: '••••••••', partial: 'WF••••1234', hash: 'a3f9c2e1b7' };
const MASK_DESC = {
  deny: 'Column-level — value returned as NULL',
  full: 'Field-level — fully masked',
  partial: 'Field-level — show first/last N characters',
  hash: 'Field-level — deterministic hash',
};

function RoleModal({ onClose, notify }) {
  const modules = ['Analytics', 'Modeling', 'Pipelines', 'Catalog', 'Governance', 'Monitoring', 'Admin'];
  const actions = ['View', 'Create', 'Edit', 'Delete', 'Admin'];
  return (
    <Modal sup="RBAC" title="Create role" size="lg" onClose={onClose}
      footer={<React.Fragment><Button kind="secondary" onClick={onClose}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { onClose(); notify && notify({ kind: 'success', title: 'Role created.' }); }}>Create role</Button></React.Fragment>}>
      <div className="w-row">
        <TextInput label="Role name" placeholder="Factory Analyst" />
        <Dropdown label="Mapped Keycloak group" items={['/ipas/analysts', '/ipas/engineers', '/ipas/stewards', '/ipas/viewers']} value="/ipas/analysts" onChange={() => {}} />
      </div>
      <div className="w-fld"><label>Feature-permission matrix</label>
        <table className="w-permgrid">
          <thead><tr><th>Module</th>{actions.map((a) => <th key={a}>{a}</th>)}</tr></thead>
          <tbody>
            {modules.map((m, mi) => (
              <tr key={m}><td>{m}</td>{actions.map((a, ai) => <td key={a}><input type="checkbox" defaultChecked={ai === 0 || (ai === 1 && mi < 4)} /></td>)}</tr>
            ))}
          </tbody>
        </table>
      </div>
      <TextInput label="Description" placeholder="What this role is for" />
    </Modal>
  );
}

function RowPolicyModal({ onClose, notify }) {
  return (
    <Modal sup="ABAC · Row-level" title="Create row policy" size="lg" onClose={onClose}
      footer={<React.Fragment><Button kind="secondary" onClick={onClose}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { onClose(); notify && notify({ kind: 'success', title: 'Row policy saved & enabled.' }); }}>Save policy</Button></React.Fragment>}>
      <div className="w-row">
        <Dropdown label="Subject (role / group)" items={['Factory Analyst', 'Analyst', 'Viewer', 'Steward']} value="Factory Analyst" onChange={() => {}} />
        <Dropdown label="Catalog" items={['gold', 'silver', 'bronze']} value="gold" onChange={() => {}} />
      </div>
      <div className="w-row">
        <Dropdown label="Schema" items={['manufacturing', 'sales', 'logistics']} value="manufacturing" onChange={() => {}} />
        <Dropdown label="Table" items={['spc_xbar_r_chart', 'fact_production', 'agg_yield']} value="spc_xbar_r_chart" onChange={() => {}} />
      </div>
      <div className="w-fld"><label>Row filter — condition builder</label>
        <ConditionBuilder fields={['process_id', 'plant', 'shift', 'region']} />
      </div>
    </Modal>
  );
}

function MaskModal({ onClose, notify }) {
  const [mask, setMask] = React.useState('partial');
  return (
    <Modal sup="ABAC · Masking" title="Create masking policy" size="lg" onClose={onClose}
      footer={<React.Fragment><Button kind="secondary" onClick={onClose}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { onClose(); notify && notify({ kind: 'success', title: 'Masking policy saved.' }); }}>Save policy</Button></React.Fragment>}>
      <div className="w-row">
        <Dropdown label="Subject (role / group)" items={['Viewer', 'Analyst', 'Factory Analyst']} value="Viewer" onChange={() => {}} />
        <Dropdown label="Table" items={['silver.customers', 'silver.orders', 'gold.fact_production']} value="silver.customers" onChange={() => {}} />
      </div>
      <div className="w-row">
        <Dropdown label="Column" items={['wafer_id', 'email', 'ssn', 'phone']} value="wafer_id" onChange={() => {}} />
        <Dropdown label="Mask type" items={['deny', 'full', 'partial', 'hash']} value={mask} onChange={setMask} />
      </div>
      <div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)' }}>{MASK_DESC[mask]}</div>
      {mask === 'partial' && <TextInput label="Show expression template" defaultValue="WF****1234" helperText="Use * for masked positions." />}
      <div className="w-fld"><label>Live preview</label>
        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '.6875rem', color: 'var(--cds-text-secondary)', marginBottom: 4 }}>Original</div>
            <div style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', background: 'var(--cds-layer-01)', border: '1px solid var(--wire-border)', padding: '8px 12px' }}>WF00481234</div>
          </div>
          <Icon name="arrow--right" size={16} style={{ color: 'var(--cds-icon-secondary)' }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '.6875rem', color: 'var(--cds-text-secondary)', marginBottom: 4 }}>Masked as seen by subject</div>
            <div style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', background: 'var(--cds-gray-100)', color: '#f4f4f4', padding: '8px 12px' }}>{MASK_PREVIEW[mask]}</div>
          </div>
        </div>
      </div>
    </Modal>
  );
}

function PreviewAsUser({ onClose }) {
  const [ran, setRan] = React.useState(false);
  const cols = [
    { key: 'process_id', label: 'process_id' }, { key: 'wafer_id', label: 'wafer_id' }, { key: 'yield', label: 'yield_pct' }, { key: 'region', label: 'region' },
  ];
  const original = [
    { process_id: 'P1', wafer_id: 'WF00481234', yield: '0.962', region: 'APAC' },
    { process_id: 'P2', wafer_id: 'WF00485511', yield: '0.948', region: 'APAC' },
    { process_id: 'P3', wafer_id: 'WF00490027', yield: '0.911', region: 'EMEA' },
    { process_id: 'P5', wafer_id: 'WF00492210', yield: '0.933', region: 'AMER' },
  ];
  // effective for "Factory Analyst": row filter process_id IN (P1,P2) + wafer_id partial mask
  const effective = original.filter((r) => ['P1', 'P2'].includes(r.process_id)).map((r) => ({ ...r, wafer_id: 'WF****' + r.wafer_id.slice(-4) }));
  return (
    <Modal sup="Policy simulation" title="Preview as user" size="lg" onClose={onClose}
      footer={<Button kind="secondary" onClick={onClose}>Close</Button>}>
      <div className="w-row">
        <Dropdown label="Preview as" items={['Factory Analyst (role)', 'Ade Okafor (Analyst)', 'Mara Díaz (Viewer)']} value="Factory Analyst (role)" onChange={() => {}} />
        <Dropdown label="Table" items={['gold.spc_xbar_r_chart', 'silver.customers']} value="gold.spc_xbar_r_chart" onChange={() => {}} />
      </div>
      <Button kind="primary" size="md" icon="play" onClick={() => setRan(true)}>Run sample query</Button>
      {ran && (
        <React.Fragment>
          <div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)' }}>Applied: row filter <code style={{ fontFamily: 'var(--cds-font-mono)' }}>process_id IN ('P1','P2')</code> · partial mask on <code style={{ fontFamily: 'var(--cds-font-mono)' }}>wafer_id</code></div>
          <div className="w-fld"><label>Original result ({original.length} rows)</label>
            <WireTable columns={cols} rows={original} footer={false} renderCell={(r, k) => <span style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem' }}>{r[k]}</span>} />
          </div>
          <div className="w-fld"><label>Effective result for subject ({effective.length} rows)</label>
            <WireTable columns={cols} rows={effective} footer={false} renderCell={(r, k) => <span style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', color: k === 'wafer_id' ? 'var(--cds-text-placeholder)' : 'inherit' }}>{r[k]}</span>} />
          </div>
        </React.Fragment>
      )}
    </Modal>
  );
}

function AccessControl({ notify }) {
  const [modal, setModal] = React.useState(null); // role | rowpolicy | mask | preview
  const roleCols = [
    { key: 'role', label: 'Role', cellClass: 'name' }, { key: 'group', label: 'Keycloak group', cellClass: 'mono' }, { key: 'members', label: 'Members' }, { key: 'perms', label: 'Page permissions' }, { key: 'model', label: 'Model' }, { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  const roles = [
    { role: 'Data Engineer', group: '/ipas/engineers', members: '12', perms: 'All modules · write Bronze→Gold', model: 'RBAC' },
    { role: 'Factory Analyst', group: '/ipas/analysts', members: '34', perms: 'Analytics, Catalog · read Gold', model: 'ABAC' },
    { role: 'Steward', group: '/ipas/stewards', members: '6', perms: 'Catalog, Governance · policies', model: 'ABAC' },
    { role: 'Viewer', group: '/ipas/viewers', members: '88', perms: 'Dashboards · read only', model: 'RBAC' },
  ];
  const rowPolicies = [
    { subject: 'Factory Analyst', table: 'gold.spc_xbar_r_chart', filter: "process_id IN ('P1','P2')", enabled: true },
    { subject: 'Analyst', table: 'silver.orders', filter: 'region = user.region', enabled: true },
    { subject: 'Viewer', table: 'gold.fact_production', filter: 'aggregated rows only', enabled: false },
  ];
  const masks = [
    { subject: 'Viewer', table: 'silver.customers', col: 'wafer_id', type: 'partial', status: 'Active' },
    { subject: 'Analyst', table: 'silver.customers', col: 'ssn', type: 'full', status: 'Active' },
    { subject: 'Analyst', table: 'silver.orders', col: 'customer_id', type: 'hash', status: 'Active' },
    { subject: 'Viewer', table: 'silver.orders', col: 'amount', type: 'deny', status: 'Active' },
  ];
  const requests = [
    { id: 1, who: 'Ade Okafor', what: 'Analyst role', on: 'gold.fact_production', when: '2 min ago' },
    { id: 2, who: 'Mara Díaz', what: 'Read access', on: 'silver.shipments', when: '1 hour ago' },
  ];
  const [reqs, setReqs] = React.useState(requests);
  const act = (id, decision) => { setReqs((rs) => rs.filter((r) => r.id !== id)); notify && notify({ kind: decision === 'approve' ? 'success' : 'info', title: decision === 'approve' ? 'Request approved' : 'Request denied' }); };

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
        <span className="gv-iam"><Icon name="locked" size={16} />Identity from Keycloak (Unified SSO via AD/LDAP) · Authorization managed here</span>
        <Button kind="primary" size="md" icon="play--outline" style={{ marginLeft: 'auto' }} onClick={() => setModal('preview')}>Preview as user</Button>
      </div>
      <Tabs tabs={[
        { label: 'Roles', content: (
          <div style={{ marginTop: 8 }} className="w-tblwrap">
            <TableToolbar placeholder="Search roles" search="" onSearch={() => {}} actions={<Button kind="primary" size="lg" icon="add" onClick={() => setModal('role')}>Create role</Button>} />
            <WireTable columns={roleCols} rows={roles} footer={false} renderCell={(r, k) => {
              if (k === 'model') return <Tag type={r.model === 'ABAC' ? 'purple' : 'blue'} size="sm">{r.model}</Tag>;
              if (k === 'ofw') return <Overflow />;
              return r[k];
            }} />
          </div>
        ) },
        { label: 'Row-level policies', content: (
          <div style={{ marginTop: 8 }} className="w-tblwrap">
            <TableToolbar placeholder="Search policies" search="" onSearch={() => {}} actions={<Button kind="primary" size="lg" icon="add" onClick={() => setModal('rowpolicy')}>Create row policy</Button>} />
            <WireTable footer={false}
              columns={[{ key: 'subject', label: 'Subject', cellClass: 'name' }, { key: 'table', label: 'Table', cellClass: 'mono' }, { key: 'filter', label: 'Filter expression', cellClass: 'mono' }, { key: 'enabled', label: 'Enabled' }, { key: 'ofw', label: '', sortable: false, width: 48 }]}
              rows={rowPolicies} renderCell={(r, k) => {
                if (k === 'enabled') return <Toggle size="sm" defaultToggled={r.enabled} hideLabel label="" />;
                if (k === 'ofw') return <Overflow />;
                return r[k];
              }} />
          </div>
        ) },
        { label: 'Column & field masking', content: (
          <div style={{ marginTop: 8 }} className="w-tblwrap">
            <TableToolbar placeholder="Search masking policies" search="" onSearch={() => {}} actions={<Button kind="primary" size="lg" icon="add" onClick={() => setModal('mask')}>Create masking policy</Button>} />
            <WireTable footer={false}
              columns={[{ key: 'subject', label: 'Subject', cellClass: 'name' }, { key: 'table', label: 'Table', cellClass: 'mono' }, { key: 'col', label: 'Column', cellClass: 'mono' }, { key: 'type', label: 'Mask type' }, { key: 'status', label: 'Status' }, { key: 'ofw', label: '', sortable: false, width: 48 }]}
              rows={masks} renderCell={(r, k) => {
                if (k === 'type') return <Tag type={r.type === 'deny' ? 'red' : r.type === 'full' ? 'purple' : r.type === 'partial' ? 'blue' : 'cool-gray'} size="sm">{r.type}</Tag>;
                if (k === 'status') return <StatusDot kind="active">{r.status}</StatusDot>;
                if (k === 'ofw') return <Overflow />;
                return r[k];
              }} />
          </div>
        ) },
        { label: `Access requests (${reqs.length})`, content: (
          <div style={{ marginTop: 8 }}>
            {reqs.length === 0 ? <div className="w-empty"><div className="ic"><Icon name="checkmark--outline" size={32} /></div><h3>No pending requests</h3><p>Access requests will appear here for approval.</p></div> : (
              <div className="w-tblwrap">
                {reqs.map((r) => (
                  <div key={r.id} className="ov-req" style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
                    <div style={{ flex: 1 }}>
                      <div className="t"><b>{r.who}</b> requested <b>{r.what}</b></div>
                      <div className="s" style={{ marginBottom: 0 }}>{r.on} · {r.when}</div>
                    </div>
                    <Button kind="ghost" size="sm" icon="chat">Comment</Button>
                    <Button kind="primary" size="sm" onClick={() => act(r.id, 'approve')}>Approve</Button>
                    <Button kind="tertiary" size="sm" onClick={() => act(r.id, 'deny')}>Deny</Button>
                  </div>
                ))}
              </div>
            )}
            <h3 style={{ fontSize: '.875rem', color: 'var(--cds-text-primary)', margin: '24px 0 8px' }}>Request history</h3>
            <div className="w-tblwrap">
              <WireTable footer={false}
                columns={[{ key: 'who', label: 'Requester' }, { key: 'what', label: 'Requested' }, { key: 'on', label: 'Resource', cellClass: 'mono' }, { key: 'res', label: 'Decision' }, { key: 'by', label: 'By' }]}
                rows={[
                  { who: 'J. Singh', what: 'Editor role', on: 'gold.fact_sales', res: 'Approved', by: 'L. Marsh' },
                  { who: 'R. Vance', what: 'Write access', on: 'silver.shipments', res: 'Denied', by: 'L. Marsh' },
                ]}
                renderCell={(r, k) => k === 'res' ? <StatusDot kind={r.res === 'Approved' ? 'success' : 'failed'}>{r.res}</StatusDot> : r[k]} />
            </div>
          </div>
        ) },
      ]} />

      {modal === 'role' && <RoleModal onClose={() => setModal(null)} notify={notify} />}
      {modal === 'rowpolicy' && <RowPolicyModal onClose={() => setModal(null)} notify={notify} />}
      {modal === 'mask' && <MaskModal onClose={() => setModal(null)} notify={notify} />}
      {modal === 'preview' && <PreviewAsUser onClose={() => setModal(null)} />}
    </div>
  );
}

/* ---- Data Classification ---- */
function Classification({ notify }) {
  const levels = [
    { lvl: 'Public', desc: 'No restriction', tag: 'green', n: 12 },
    { lvl: 'Internal', desc: 'Employees only', tag: 'blue', n: 88 },
    { lvl: 'Confidential', desc: 'Need-to-know', tag: 'purple', n: 21 },
    { lvl: 'Restricted', desc: 'PII / regulated', tag: 'red', n: 9 },
  ];
  const cols = [
    { key: 'asset', label: 'Asset', cellClass: 'name' }, { key: 'level', label: 'Sensitivity' }, { key: 'tags', label: 'Compliance tags', sortable: false }, { key: 'by', label: 'Classified by' }, { key: 'auto', label: 'Source' }, { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  const rows = [
    { asset: 'silver.customers', level: 'Restricted', tags: ['PII', 'GDPR'], by: 'auto-rule', auto: 'Auto' },
    { asset: 'silver.orders', level: 'Confidential', tags: ['SOX'], by: 'R. Vance', auto: 'Manual' },
    { asset: 'gold.fact_production', level: 'Internal', tags: [], by: 'L. Marsh', auto: 'Manual' },
    { asset: 'gold.dim_product', level: 'Public', tags: [], by: 'auto-rule', auto: 'Auto' },
  ];
  const LVL_TAG = { Public: 'green', Internal: 'blue', Confidential: 'purple', Restricted: 'red' };
  return (
    <div>
      <div className="w-stats" style={{ marginBottom: 24 }}>
        {levels.map((l) => (
          <div key={l.lvl} className="s"><div className="k"><span style={{ width: 10, height: 10, background: `var(--cds-${l.tag === 'green' ? 'support-success' : l.tag === 'red' ? 'support-error' : l.tag === 'purple' ? 'purple-60,#8a3ffc' : 'blue-60'})` }} />{l.lvl}</div><div className="v">{l.n}</div><div className="d">{l.desc}</div></div>
        ))}
      </div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search classified assets" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="tag" iconOnly title="Bulk tag" /><Button kind="primary" size="lg" icon="add" onClick={() => notify && notify({ kind: 'info', title: 'Auto-classification rule builder' })}>New rule</Button></React.Fragment>} />
        <WireTable columns={cols} rows={rows} footer={false}
          renderCell={(r, k) => {
            if (k === 'level') return <Tag type={LVL_TAG[r.level]} size="sm">{r.level}</Tag>;
            if (k === 'tags') return <span style={{ display: 'flex', gap: 4, flexWrap: 'wrap' }}>{r.tags.length ? r.tags.map((t) => <Tag key={t} type="cool-gray" size="sm">{t}</Tag>) : <span style={{ color: 'var(--cds-text-placeholder)' }}>—</span>}</span>;
            if (k === 'auto') return <Tag type={r.auto === 'Auto' ? 'teal' : 'cool-gray'} size="sm">{r.auto}</Tag>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
    </div>
  );
}

const GOV_SUBS = [
  { id: 'catalog', label: 'Data catalog' },
  { id: 'lineage', label: 'Lineage graph' },
  { id: 'access', label: 'Access control' },
  { id: 'classification', label: 'Data classification' },
];

function Governance({ notify, lang }) {
  const [sub, setSub] = React.useState('catalog');
  const [asset, setAsset] = React.useState(null);

  if (sub === 'catalog' && asset) {
    return (
      <div className="w-page">
        <div className="w-crumb"><a href="#" onClick={(e) => e.preventDefault()}>Data Assets &amp; Governance</a><span className="sep">/</span><a href="#" onClick={(e) => e.preventDefault()}>Data catalog</a><span className="sep">/</span><span>{asset.name}</span></div>
        <AssetDetail asset={asset} onBack={() => setAsset(null)} />
      </div>
    );
  }
  const TITLES = {
    catalog: ['Data catalog', 'Search and explore every table and field across the platform.'],
    lineage: ['Lineage graph', 'Trace data flow RAW → Bronze → Silver → Gold → ClickHouse, down to field level.'],
    access: ['Access control', 'Manage users, roles, and row/column-level policies (RBAC / ABAC).'],
    classification: ['Data classification', 'Sensitivity levels, compliance tags, and auto-classification rules.'],
  };
  const [t, s] = TITLES[sub];
  return (
    <div className="w-page">
      <PageHead crumb={['Data Assets & Governance', t].map((c) => tr(lang, c))} title={tr(lang, t)} sub={tr(lang, s)} />
      <SubSwitch items={trList(lang, GOV_SUBS)} value={sub} onChange={(v) => { setSub(v); setAsset(null); }} />
      {sub === 'catalog' && <Catalog onOpen={setAsset} />}
      {sub === 'lineage' && <LineageGraph />}
      {sub === 'access' && <AccessControl notify={notify} />}
      {sub === 'classification' && <Classification notify={notify} />}
    </div>
  );
}

Object.assign(window, { Governance });
