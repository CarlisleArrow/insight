/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, BarChart, StatusDot, ToolBtn, tr, trList */
const { Icon, Tag, Button, Search, TextInput, Dropdown } = window.CarbonDesignSystem_280d33;

const MON_CSS = `
.mn-cards { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.mn-card { background:var(--cds-layer-02); padding:20px; }
.mn-card .k { font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.mn-card .v { font-size:2.5rem; font-weight:300; line-height:1; margin-top:12px; color:var(--cds-text-primary); }
.mn-card .v.run { color:var(--cds-blue-60); } .mn-card .v.ok { color:var(--cds-support-success); } .mn-card .v.fail { color:var(--cds-support-error); } .mn-card .v.retry { color:var(--cds-support-warning); }
.mn-grafana { display:grid; grid-template-columns:repeat(2,1fr); gap:16px; margin-bottom:24px; }
.mn-panel { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.mn-panel__h { display:flex; align-items:center; gap:8px; padding:10px 16px; border-bottom:1px solid var(--wire-border); font-size:.8125rem; font-weight:600; color:var(--cds-text-primary); }
.mn-panel__h .badge { margin-left:auto; font-size:.6875rem; font-weight:400; color:var(--cds-text-secondary); display:flex; align-items:center; gap:6px; }
.mn-panel__b { padding:16px; }
.mn-sla { width:100%; border-collapse:collapse; }
.mn-sla th { text-align:left; font-size:.75rem; font-weight:600; padding:10px 16px; background:var(--cds-layer-01); border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.mn-sla td { font-size:.8125rem; padding:0 16px; height:48px; border-bottom:1px solid var(--wire-border); color:var(--cds-text-secondary); }
.mn-sla .pipe { color:var(--cds-text-primary); font-weight:500; font-family:var(--cds-font-mono); font-size:.8125rem; }
.mn-rag { display:inline-flex; align-items:center; gap:6px; }
.mn-rag .sq { width:12px; height:12px; }
.mn-log { font-family:var(--cds-font-mono); font-size:.75rem; border:1px solid var(--wire-border); background:var(--cds-gray-100); color:#f4f4f4; max-height:520px; overflow:auto; }
.mn-log__bar { display:flex; align-items:center; gap:8px; padding:8px; background:var(--cds-layer-02); border-bottom:1px solid var(--wire-border); }
.mn-log__row { display:flex; gap:12px; padding:5px 12px; border-bottom:1px solid rgba(255,255,255,.05); white-space:nowrap; }
.mn-log__row:hover { background:rgba(255,255,255,.04); }
.mn-log__ts { color:#8d8d8d; flex:0 0 auto; }
.mn-log__lvl { flex:0 0 56px; font-weight:600; }
.mn-log__lvl.info { color:#78a9ff; } .mn-log__lvl.warn { color:#f1c21b; } .mn-log__lvl.error { color:#ff8389; }
.mn-log__src { color:#3ddbd9; flex:0 0 130px; }
.mn-log__msg { color:#e0e0e0; white-space:pre; }
`;
(function(){ if (!document.getElementById('ipas-mon-styles')) { const e=document.createElement('style'); e.id='ipas-mon-styles'; e.textContent=MON_CSS; document.head.appendChild(e);} })();

const RUNS = [
  { id: 1, dag: 'erp_to_gold', task: 'fact_production', start: '14:32', dur: '4m 12s', status: 'Success' },
  { id: 2, dag: 'mes_stream', task: 'clean_mes', start: '14:30', dur: 'running', status: 'Running' },
  { id: 3, dag: 'crm_sync', task: 'load_customers', start: '14:18', dur: '1m 02s', status: 'Failed' },
  { id: 4, dag: 'erp_to_gold', task: 'agg_yield', start: '14:10', dur: '2m 48s', status: 'Retrying' },
  { id: 5, dag: 'finance_daily', task: 'gross_margin', start: '13:55', dur: '3m 30s', status: 'Success' },
  { id: 6, dag: 'logistics_etl', task: 'on_time_delivery', start: '13:40', dur: '5m 01s', status: 'Success' },
];

function TaskMonitoring() {
  const cols = [
    { key: 'dag', label: 'DAG', cellClass: 'mono' },
    { key: 'task', label: 'Task', cellClass: 'mono' },
    { key: 'start', label: 'Started' },
    { key: 'dur', label: 'Duration' },
    { key: 'status', label: 'Status' },
    { key: 'logs', label: 'Logs', sortable: false },
    { key: 'act', label: '', sortable: false, width: 96 },
  ];
  return (
    <div>
      <div className="mn-cards">
        <div className="mn-card"><div className="k"><Icon name="renew" size={16} />Running</div><div className="v run">3</div></div>
        <div className="mn-card"><div className="k"><Icon name="checkmark--filled" size={16} />Success (24h)</div><div className="v ok">412</div></div>
        <div className="mn-card"><div className="k"><Icon name="error--filled" size={16} />Failed (24h)</div><div className="v fail">7</div></div>
        <div className="mn-card"><div className="k"><Icon name="warning--filled" size={16} />Retrying</div><div className="v retry">2</div></div>
      </div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search runs by DAG or task" search="" onSearch={() => {}}
          actions={<React.Fragment><Dropdown items={['All status', 'Running', 'Failed', 'Retrying']} value="All status" onChange={() => {}} /><Button kind="ghost" size="lg" icon="renew" iconOnly /></React.Fragment>} />
        <WireTable columns={cols} rows={RUNS} total={421}
          renderCell={(r, k) => {
            if (k === 'status') return <StatusDot kind={r.status}>{r.status}</StatusDot>;
            if (k === 'logs') return <a href="#" onClick={(e) => e.preventDefault()} style={{ color: 'var(--cds-link-primary)', textDecoration: 'none', display: 'inline-flex', alignItems: 'center', gap: 4 }}><Icon name="document" size={16} />ELK</a>;
            if (k === 'act') return (r.status === 'Failed' || r.status === 'Retrying') ? <Button kind="ghost" size="sm" icon="renew">Retry</Button> : <Overflow />;
            return r[k];
          }} />
      </div>
    </div>
  );
}

const SLA = [
  { pipe: 'erp_to_gold', fresh: 'g', freshT: '14m ago', time: 'g', timeT: 'on time', lat: 'g', latT: '4m avg' },
  { pipe: 'mes_stream', fresh: 'a', freshT: '32m ago', time: 'a', timeT: '+8m', lat: 'g', latT: '1.4s' },
  { pipe: 'crm_sync', fresh: 'r', freshT: '3h ago', time: 'r', timeT: 'breached', lat: 'r', latT: 'failed' },
  { pipe: 'finance_daily', fresh: 'g', freshT: '6h ago', time: 'g', timeT: 'on time', lat: 'g', latT: '3m avg' },
  { pipe: 'logistics_etl', fresh: 'g', freshT: '20m ago', time: 'g', timeT: 'on time', lat: 'a', latT: '6m avg' },
];
const RAG = { g: 'var(--cds-support-success)', a: 'var(--cds-support-warning)', r: 'var(--cds-support-error)' };
function Rag({ s, t }) { return <span className="mn-rag"><span className="sq" style={{ background: RAG[s] }} />{t}</span>; }

function ResourceSla() {
  return (
    <div>
      <div className="mn-grafana">
        <div className="mn-panel">
          <div className="mn-panel__h"><Icon name="dashboard" size={16} />Cluster health<span className="badge"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--cds-support-success)' }} />Grafana</span></div>
          <div className="mn-panel__b"><BarChart data={[55, 62, 48, 70, 65, 72, 60, 58, 66]} height={120} /><div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', marginTop: 8 }}>CPU 58% · Mem 64% · 12 nodes healthy</div></div>
        </div>
        <div className="mn-panel">
          <div className="mn-panel__h"><Icon name="watson" size={16} />Spark executors<span className="badge"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--cds-support-success)' }} />Grafana</span></div>
          <div className="mn-panel__b"><Placeholder label="executor cores / shuffle read" icon="chart--line" height={120} /><div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', marginTop: 8 }}>48 cores · 0 failed stages</div></div>
        </div>
        <div className="mn-panel">
          <div className="mn-panel__h"><Icon name="data--base" size={16} />ClickHouse latency<span className="badge"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--cds-support-warning)' }} />Grafana</span></div>
          <div className="mn-panel__b"><Placeholder label="p95 query latency (ms)" icon="chart--line" height={120} /><div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', marginTop: 8 }}>p95 312ms · QPS 1.2k</div></div>
        </div>
        <div className="mn-panel">
          <div className="mn-panel__h"><Icon name="chart--bar" size={16} />Ingestion throughput<span className="badge"><span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--cds-support-success)' }} />Grafana</span></div>
          <div className="mn-panel__b"><BarChart data={[40, 55, 60, 72, 68, 80, 76]} height={120} /><div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', marginTop: 8 }}>1.8M events/min</div></div>
        </div>
      </div>
      <div className="mn-panel">
        <div className="mn-panel__h"><Icon name="time" size={16} />Data SLA board</div>
        <table className="mn-sla">
          <thead><tr><th>Pipeline</th><th>Freshness</th><th>Timeliness</th><th>Latency</th><th>SLA</th></tr></thead>
          <tbody>
            {SLA.map((r) => (
              <tr key={r.pipe}>
                <td className="pipe">{r.pipe}</td>
                <td><Rag s={r.fresh} t={r.freshT} /></td>
                <td><Rag s={r.time} t={r.timeT} /></td>
                <td><Rag s={r.lat} t={r.latT} /></td>
                <td>{(r.fresh === 'r' || r.time === 'r' || r.lat === 'r') ? <Tag type="red" size="sm">Breached</Tag> : (r.fresh === 'a' || r.time === 'a' || r.lat === 'a') ? <Tag type="purple" size="sm">At risk</Tag> : <Tag type="green" size="sm">Met</Tag>}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const ALERTS = [
  { id: 1, name: 'CRM sync freshness', cond: 'freshness > 30m', sev: 'Critical', status: 'Firing', at: '18m ago', target: '#data-sla' },
  { id: 2, name: 'ClickHouse p95 latency', cond: 'p95 > 500ms for 5m', sev: 'Warning', status: 'Firing', at: '42m ago', target: 'pager:data-oncall' },
  { id: 3, name: 'Kafka consumer lag', cond: 'lag > 100k', sev: 'Warning', status: 'Resolved', at: '2h ago', target: '#data-eng' },
  { id: 4, name: 'Pipeline failure rate', cond: 'failures > 5 / 1h', sev: 'Critical', status: 'Resolved', at: '5h ago', target: 'pager:data-oncall' },
  { id: 5, name: 'Disk usage — lakehouse', cond: 'usage > 85%', sev: 'Info', status: 'Resolved', at: 'Yesterday', target: '#infra' },
];
function Alerts({ notify }) {
  const [open, setOpen] = React.useState(false);
  const cols = [
    { key: 'name', label: 'Alert', cellClass: 'name' },
    { key: 'cond', label: 'Condition', cellClass: 'mono' },
    { key: 'sev', label: 'Severity' },
    { key: 'status', label: 'Status' },
    { key: 'at', label: 'Triggered' },
    { key: 'target', label: 'Route to', cellClass: 'mono' },
    { key: 'act', label: '', sortable: false, width: 96 },
  ];
  return (
    <div>
      <div className="mn-cards">
        <div className="mn-card"><div className="k"><Icon name="warning--filled" size={16} />Firing</div><div className="v fail">2</div></div>
        <div className="mn-card"><div className="k"><Icon name="warning--alt--filled" size={16} />Warning</div><div className="v retry">1</div></div>
        <div className="mn-card"><div className="k"><Icon name="checkmark--filled" size={16} />Resolved (24h)</div><div className="v ok">14</div></div>
        <div className="mn-card"><div className="k"><Icon name="notification--off" size={16} />Silenced</div><div className="v">1</div></div>
      </div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search alert rules" search="" onSearch={() => {}}
          actions={<React.Fragment><Dropdown items={['All severity', 'Critical', 'Warning', 'Info']} value="All severity" onChange={() => {}} /><Button kind="primary" size="lg" icon="add" onClick={() => setOpen(true)}>New alert rule</Button></React.Fragment>} />
        <WireTable columns={cols} rows={ALERTS}
          renderCell={(r, k) => {
            if (k === 'sev') return <Tag type={r.sev === 'Critical' ? 'red' : r.sev === 'Warning' ? 'purple' : 'cool-gray'} size="sm">{r.sev}</Tag>;
            if (k === 'status') return <StatusDot kind={r.status === 'Firing' ? 'failed' : 'success'}>{r.status}</StatusDot>;
            if (k === 'act') return r.status === 'Firing'
              ? <React.Fragment><Button kind="ghost" size="sm" onClick={() => notify && notify({ kind: 'info', title: 'Alert acknowledged' })}>Ack</Button><Button kind="ghost" size="sm" icon="notification--off" iconOnly title="Silence" /></React.Fragment>
              : <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Alerts" title="New alert rule" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Alert rule created.' }); }}>Create rule</Button></React.Fragment>}>
          <TextInput label="Rule name" placeholder="ClickHouse p95 latency" />
          <div className="w-row">
            <Dropdown label="Metric" items={['p95 latency', 'freshness', 'consumer lag', 'failure rate', 'disk usage']} value="p95 latency" onChange={() => {}} />
            <Dropdown label="Severity" items={['Critical', 'Warning', 'Info']} value="Warning" onChange={() => {}} />
          </div>
          <div className="w-row">
            <Dropdown label="Operator" items={['>', '<', '>=', '<=']} value=">" onChange={() => {}} />
            <TextInput label="Threshold" defaultValue="500ms" />
          </div>
          <Dropdown label="Notification channel" items={['#data-sla', '#data-eng', 'pager:data-oncall', '#infra']} value="#data-sla" onChange={() => {}} />
        </Modal>
      )}
    </div>
  );
}

const LOG_ROWS = [
  { ts: '14:32:08.421', lvl: 'info', src: 'airflow', msg: 'DAG erp_to_gold run 4821 succeeded in 11m04s' },
  { ts: '14:31:55.882', lvl: 'info', src: 'spark', msg: 'Stage 7 (conform_dims) completed — 48 tasks' },
  { ts: '14:30:12.004', lvl: 'warn', src: 'clickhouse', msg: 'Query 0x9f3a exceeded p95 latency target (612ms)' },
  { ts: '14:28:41.317', lvl: 'error', src: 'debezium', msg: 'crm-cdc connector RESTART_FAILED: cannot reach crm-sqlserver:1433' },
  { ts: '14:27:03.559', lvl: 'info', src: 'iceberg', msg: 'Committed snapshot 7741200933 to gold.fact_production' },
  { ts: '14:25:48.230', lvl: 'warn', src: 'dq-engine', msg: 'Rule silver.orders.customer_id NOT NULL — 142 failing rows' },
  { ts: '14:24:19.901', lvl: 'info', src: 'trino', msg: 'Federated query routed to ClickHouse (cost-based)' },
  { ts: '14:22:55.118', lvl: 'error', src: 'airflow', msg: 'Task crm_sync.load_customers failed (attempt 3/3) — see Sentry IPAS-2291' },
  { ts: '14:21:30.447', lvl: 'info', src: 'keycloak', msg: 'Token issued for lmarsh@ipas (group /ipas/engineers)' },
];
function Logs() {
  const [lvl, setLvl] = React.useState('All levels');
  const rows = LOG_ROWS.filter((r) => lvl === 'All levels' || r.lvl === lvl.toLowerCase());
  return (
    <div className="mn-log">
      <div className="mn-log__bar">
        <div style={{ flex: 1, minWidth: 0 }}><Search size="md" placeholder="Filter logs — query, source, trace id…" /></div>
        <Dropdown items={['All levels', 'Info', 'Warn', 'Error']} value={lvl} onChange={setLvl} />
        <Dropdown items={['All sources', 'airflow', 'spark', 'clickhouse', 'debezium', 'trino']} value="All sources" onChange={() => {}} />
        <Dropdown items={['Last 15m', 'Last 1h', 'Last 24h']} value="Last 1h" onChange={() => {}} />
        <Button kind="ghost" size="sm" icon="renew" iconOnly title="Refresh" />
      </div>
      {rows.map((r, i) => (
        <div key={i} className="mn-log__row">
          <span className="mn-log__ts">{r.ts}</span>
          <span className={`mn-log__lvl ${r.lvl}`}>{r.lvl.toUpperCase()}</span>
          <span className="mn-log__src">{r.src}</span>
          <span className="mn-log__msg">{r.msg}{r.lvl === 'error' && <a href="#" onClick={(e) => e.preventDefault()} style={{ color: '#ff8389', marginLeft: 8 }}>→ Sentry</a>}</span>
        </div>
      ))}
    </div>
  );
}

const MON_SUBS = [
  { id: 'tasks', label: 'Task monitoring' },
  { id: 'sla', label: 'Resource & SLA' },
  { id: 'alerts', label: 'Alerts' },
  { id: 'logs', label: 'Logs' },
];
function Monitoring({ notify, lang }) {
  const [sub, setSub] = React.useState('tasks');
  const TITLES = {
    tasks: ['Task monitoring', 'Live ETL run status with logs and failure recovery.'],
    sla: ['Resource & SLA monitoring', 'Cluster, Spark, and ClickHouse health plus per-pipeline data SLAs.'],
    alerts: ['Alerts', 'Threshold and condition-based alert rules with severity and routing.'],
    logs: ['Log explorer', 'Search platform logs across services, levels, and time ranges.'],
  };
  const [t, s] = TITLES[sub];
  return (
    <div className="w-page">
      <PageHead crumb={['Monitoring & Ops', t].map((c) => tr(lang, c))} title={tr(lang, t)} sub={tr(lang, s)} />
      <SubSwitch items={trList(lang, MON_SUBS)} value={sub} onChange={setSub} />
      {sub === 'tasks' && <TaskMonitoring />}
      {sub === 'sla' && <ResourceSla />}
      {sub === 'alerts' && <Alerts notify={notify} />}
      {sub === 'logs' && <Logs />}
    </div>
  );
}

Object.assign(window, { Monitoring });
