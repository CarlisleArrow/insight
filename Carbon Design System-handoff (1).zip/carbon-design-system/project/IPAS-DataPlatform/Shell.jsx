/* global React, tr, Menu, MenuItem */
const { Icon, Search, Tag } = window.CarbonDesignSystem_280d33;

const IPAS_SHELL_CSS = `
.ip-shell { min-height:100vh; background:var(--cds-background); font-family:var(--cds-font-sans); display:flex; }

/* ---- custom borderless sidebar (no divider with content) ---- */
.ip-sidenav { width:272px; flex:0 0 272px; box-sizing:border-box; background:var(--cds-background);
  display:flex; flex-direction:column; padding:28px 16px; position:sticky; top:0; align-self:flex-start; height:100vh;
  transition:width .11s, flex-basis .11s; }
.ip-sidenav.collapsed { width:72px; flex-basis:72px; padding:28px 12px; align-items:stretch; }

/* brand: SiPTORY InSight (InSight = filled Carbon-blue box, white semibold) */
.ip-brand { display:flex; align-items:center; gap:8px; padding:0 8px; min-height:32px; }
.ip-brand .word { font-size:1.0625rem; font-weight:600; color:var(--cds-text-primary); letter-spacing:.1px; }
.ip-brand .badge { font-size:1.0625rem; font-weight:600; color:#fff; background:var(--cds-blue-60); padding:2px 9px; letter-spacing:.1px; }
.ip-brand .mark { display:none; width:32px; height:32px; background:var(--cds-blue-60); color:#fff; font-weight:600; font-size:.875rem; align-items:center; justify-content:center; }
.ip-sidenav.collapsed .ip-brand { justify-content:center; padding:0; }
.ip-sidenav.collapsed .ip-brand .word, .ip-sidenav.collapsed .ip-brand .badge { display:none; }
.ip-sidenav.collapsed .ip-brand .mark { display:flex; }

/* sidebar global search */
.ip-search { margin-top:20px; padding:0 4px; }
.ip-sidenav.collapsed .ip-search { display:none; }

/* nav block — vertically centered in the remaining space */
.ip-nav { flex:1; display:flex; flex-direction:column; justify-content:center; gap:2px; }
.ip-navitem { display:flex; align-items:center; gap:14px; height:44px; padding:0 12px; font-size:.9375rem; color:var(--cds-text-secondary);
  cursor:pointer; border:none; background:transparent; width:100%; text-align:left; box-sizing:border-box; border-left:3px solid transparent; white-space:nowrap; }
.ip-navitem:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.ip-navitem.active { background:var(--cds-layer-selected-01); color:var(--cds-text-primary); font-weight:600; border-left-color:var(--cds-border-interactive); }
.ip-navitem .ic { flex:0 0 18px; display:flex; }
.ip-sidenav.collapsed .ip-navitem { justify-content:center; gap:0; padding:0; }
.ip-sidenav.collapsed .ip-navitem .t { display:none; }

/* footer operations (collapsed from the old header) */
.ip-foot { display:flex; flex-direction:column; gap:14px; }
.ip-utility { display:flex; align-items:center; gap:2px; padding:0 4px; }
.ip-sidenav.collapsed .ip-utility { flex-direction:column; }
.ip-ubtn { width:40px; height:40px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent;
  color:var(--cds-icon-secondary); cursor:pointer; position:relative; }
.ip-ubtn:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.ip-ubtn .ndot { position:absolute; top:9px; right:9px; width:7px; height:7px; border-radius:50%; background:var(--cds-blue-60); border:1px solid var(--cds-background); }
.ip-ubtn .ncount { position:absolute; top:4px; right:2px; min-width:16px; height:16px; padding:0 4px; box-sizing:border-box; border-radius:8px; background:var(--cds-support-error); color:#fff; font-size:.625rem; font-weight:600; display:flex; align-items:center; justify-content:center; border:1px solid var(--cds-background); }
.ip-ubtn.on { background:var(--cds-layer-selected-01); color:var(--cds-text-primary); }
.ip-lang { min-width:40px; height:40px; padding:0 8px; font-size:.8125rem; font-weight:600; letter-spacing:.16px; }
.ip-collapse { margin-left:auto; }
.ip-sidenav.collapsed .ip-collapse { margin-left:0; }
.ip-user { display:flex; align-items:center; gap:10px; padding:6px 6px; }
.ip-user .av { width:32px; height:32px; border-radius:50%; background:var(--cds-blue-60); color:#fff; display:flex; align-items:center; justify-content:center; font-size:.75rem; font-weight:600; flex:0 0 32px; }
.ip-user .nm { font-size:.8125rem; color:var(--cds-text-primary); font-weight:500; line-height:1.2; }
.ip-user .rl { font-size:.6875rem; color:var(--cds-text-secondary); line-height:1.3; }
.ip-sidenav.collapsed .ip-user { justify-content:center; padding:0; }
.ip-sidenav.collapsed .ip-user .meta { display:none; }

.ip-main { flex:1; min-width:0; background:var(--cds-background); }
`;

function injectIpShell() {
  if (typeof document === 'undefined' || document.getElementById('ipas-shell-styles')) return;
  const el = document.createElement('style'); el.id = 'ipas-shell-styles'; el.textContent = IPAS_SHELL_CSS;
  document.head.appendChild(el);
}

const IPAS_NAV = [
  { id: 'overview', label: 'Home / Overview', icon: 'home' },
  { id: 'analytics', label: 'Self-Service Analytics', icon: 'dashboard' },
  { id: 'modeling', label: 'Data Modeling & Semantics', icon: 'data--base' },
  { id: 'devconfig', label: 'Data Development / Config', icon: 'code' },
  { id: 'governance', label: 'Data Assets & Governance', icon: 'folder' },
  { id: 'monitoring', label: 'Monitoring & Ops', icon: 'chart--line' },
  { id: 'admin', label: 'Platform Admin', icon: 'settings' },
];

function IpSideNav({ current, onSelect, collapsed, onToggle, onHome, lang, onLang, unread, onNotifications, onProfile, onAppearance }) {
  injectIpShell();
  const [menu, setMenu] = React.useState(null); // 'user' | 'help'
  const [rect, setRect] = React.useState(null);
  const openMenu = (which, e) => { setRect(e.currentTarget.getBoundingClientRect()); setMenu(which); };
  const go = (fn) => { setMenu(null); fn && fn(); };
  return (
    <nav className={`ip-sidenav ${collapsed ? 'collapsed' : ''}`} aria-label="Product navigation">
      <a className="ip-brand" href="#" onClick={(e) => { e.preventDefault(); onHome && onHome(); }} aria-label="SiPTORY InSight — home">
        <span className="word">SiPTORY</span><span className="badge">InSight</span>
        <span className="mark">iS</span>
      </a>

      <div className="ip-search"><Search size="md" placeholder={tr(lang, 'Search platform')} /></div>

      <div className="ip-nav">
        {IPAS_NAV.map((n) => (
          <button key={n.id} className={`ip-navitem ${current === n.id ? 'active' : ''}`} onClick={() => onSelect(n.id)} title={tr(lang, n.label)}>
            <span className="ic"><Icon name={n.icon} size={18} /></span><span className="t">{tr(lang, n.label)}</span>
          </button>
        ))}
      </div>

      <div className="ip-foot">
        <div className="ip-utility">
          <button className="ip-ubtn ip-lang" aria-label="Switch language" title="中文 / English" onClick={() => onLang(lang === 'zh' ? 'en' : 'zh')}>{lang === 'zh' ? 'EN' : '中'}</button>
          <button className="ip-ubtn" aria-label={tr(lang, 'Notifications')} title={tr(lang, 'Notifications')} onClick={onNotifications}><Icon name="notification" size={20} />{unread > 0 && <span className="ncount">{unread}</span>}</button>
          <button className={`ip-ubtn ${menu === 'help' ? 'on' : ''}`} aria-label={tr(lang, 'Help')} title={tr(lang, 'Help')} onClick={(e) => openMenu('help', e)}><Icon name="help" size={20} /></button>
          <button className="ip-ubtn ip-collapse" aria-label="Collapse navigation" onClick={onToggle}><Icon name={collapsed ? 'chevron--right' : 'chevron--left'} size={20} /></button>
        </div>
        <button className={`ip-user ${menu === 'user' ? 'on' : ''}`} style={{ border: 'none', background: menu === 'user' ? 'var(--cds-layer-selected-01)' : 'transparent', width: '100%', cursor: 'pointer', textAlign: 'left' }} onClick={(e) => openMenu('user', e)}>
          <span className="av">LM</span>
          <span className="meta"><div className="nm">Lena Marsh</div><div className="rl">{tr(lang, 'Data Engineer')}</div></span>
        </button>
      </div>

      {menu === 'help' && (
        <Menu anchorRect={rect} width={240} onClose={() => setMenu(null)}>
          <div className="w-menu__lbl">{tr(lang, 'Help & resources')}</div>
          <MenuItem icon="document" onClick={() => setMenu(null)}>{tr(lang, 'Documentation')}</MenuItem>
          <MenuItem icon="keyboard" meta="⌘ /" onClick={() => setMenu(null)}>{tr(lang, 'Keyboard shortcuts')}</MenuItem>
          <MenuItem icon="idea" onClick={() => setMenu(null)}>{tr(lang, "What's new")}</MenuItem>
          <MenuItem icon="help-desk" onClick={() => setMenu(null)}>{tr(lang, 'Support')}</MenuItem>
        </Menu>
      )}
      {menu === 'user' && (
        <Menu anchorRect={rect} width={272} onClose={() => setMenu(null)}>
          <div className="w-menu__hd">
            <div className="nm">Lena Marsh</div>
            <div className="sub">lmarsh@ipas</div>
            <div className="badges"><Tag type="blue" size="sm">{tr(lang, 'Data Engineer')}</Tag><Tag type="cool-gray" size="sm">Manufacturing</Tag></div>
          </div>
          <MenuItem icon="user" onClick={() => go(() => onProfile && onProfile('profile'))}>{tr(lang, 'My profile')}</MenuItem>
          <MenuItem icon="settings--adjust" onClick={() => go(() => onProfile && onProfile('prefs'))}>{tr(lang, 'Preferences')}</MenuItem>
          <MenuItem icon="security" onClick={() => go(() => onProfile && onProfile('perms'))}>{tr(lang, 'My permissions')}</MenuItem>
          <MenuItem icon="api" onClick={() => go(() => onProfile && onProfile('keys'))}>{tr(lang, 'API keys')}</MenuItem>
          <div className="w-menu__sep" />
          <MenuItem icon="enterprise" meta="Manufacturing" onClick={() => setMenu(null)}>{tr(lang, 'Switch organization')}</MenuItem>
          <MenuItem icon="screen" meta={tr(lang, 'Light')} onClick={() => go(onAppearance)}>{tr(lang, 'Appearance')}</MenuItem>
          <MenuItem icon="translate" meta={lang === 'zh' ? '中文' : 'English'} onClick={() => go(() => onLang(lang === 'zh' ? 'en' : 'zh'))}>{tr(lang, 'Language')}</MenuItem>
          <div className="w-menu__sep" />
          <MenuItem icon="logout" onClick={() => { setMenu(null); window.location.href = 'Login.html'; }}>{tr(lang, 'Sign out')}</MenuItem>
        </Menu>
      )}
    </nav>
  );
}

Object.assign(window, { IpSideNav, IPAS_NAV });
