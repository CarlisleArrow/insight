/* global React, SidePanel, StatusDot, tr */
const { Icon, Button, Tag } = window.CarbonDesignSystem_280d33;

/* ---- notification model ---- */
const NOTIF_META = {
  'pipeline-success': { icon: 'checkmark--filled', color: 'var(--cds-support-success)' },
  'pipeline-fail': { icon: 'error--filled', color: 'var(--cds-support-error)' },
  'pipeline-running': { icon: 'renew', color: 'var(--cds-blue-60)' },
  'quality': { icon: 'warning--alt--filled', color: 'var(--cds-support-warning)' },
  'sla': { icon: 'warning--filled', color: 'var(--cds-support-error)' },
  'access': { icon: 'user--follow', color: 'var(--cds-blue-60)' },
  'system': { icon: 'information--filled', color: 'var(--cds-text-secondary)' },
  'mention': { icon: 'chat', color: 'var(--cds-purple-60,#8a3ffc)' },
};

const SEED_NOTIFS = [
  { id: 'n1', type: 'access', title: 'Access request', desc: 'Ade Okafor requested the Analyst role on gold.fact_production.', ts: '2 min ago', unread: true, request: true },
  { id: 'n2', type: 'pipeline-fail', title: 'Pipeline failed', desc: 'crm_sync · load_customers failed after 3 retries.', ts: '14 min ago', unread: true },
  { id: 'n3', type: 'sla', title: 'SLA breach', desc: 'crm_sync freshness SLA breached (3h vs 30m target).', ts: '18 min ago', unread: true },
  { id: 'n4', type: 'quality', title: 'Data quality alert', desc: 'silver.orders.customer_id — 142 null rows (High).', ts: '32 min ago', unread: true },
  { id: 'n5', type: 'mention', title: 'Mentioned you', desc: 'R. Vance: “@lmarsh can you certify this metric?”', ts: '1 hour ago', unread: true, mention: true },
  { id: 'n6', type: 'pipeline-success', title: 'Pipeline completed', desc: 'erp_to_gold finished in 11m 04s.', ts: '1 hour ago', unread: false },
  { id: 'n7', type: 'system', title: 'Platform update', desc: 'ClickHouse upgraded to 24.3 · maintenance window closed.', ts: 'Yesterday', unread: false },
];

function NotificationsPanel({ lang, notifs, onClose, onMarkAll, onAct, onDismiss, onRead }) {
  const [tab, setTab] = React.useState('all');
  const list = notifs.filter((n) => tab === 'all' ? true : tab === 'unread' ? n.unread : n.mention);
  return (
    <SidePanel sup={tr(lang, 'Notifications')} title={tr(lang, 'Notifications')} width={400} onClose={onClose}
      footer={<React.Fragment>
        <Button kind="secondary" onClick={onMarkAll}>{tr(lang, 'Mark all as read')}</Button>
        <Button kind="primary" icon="settings">{tr(lang, 'Settings')}</Button>
      </React.Fragment>}>
      <div style={{ margin: '-20px -24px 0', display: 'flex', flexDirection: 'column', flex: 1, minHeight: 0 }}>
        <div className="w-notif__tabs">
          {[['all', 'All'], ['unread', 'Unread'], ['mentions', 'Mentions']].map(([id, lbl]) => (
            <button key={id} className={tab === id ? 'on' : ''} onClick={() => setTab(id)}>{tr(lang, lbl)}{id === 'unread' && notifs.some((n) => n.unread) ? ` (${notifs.filter((n) => n.unread).length})` : ''}</button>
          ))}
        </div>
        <div style={{ overflow: 'auto', flex: 1 }}>
          {list.length === 0 ? (
            <div style={{ padding: 48, textAlign: 'center', color: 'var(--cds-text-secondary)', fontSize: '.875rem' }}>{tr(lang, 'Nothing here.')}</div>
          ) : list.map((n) => {
            const m = NOTIF_META[n.type] || NOTIF_META.system;
            return (
              <div key={n.id} className={`w-notif ${n.unread ? 'unread' : ''}`} onClick={() => onRead(n.id)}>
                <span className="w-notif__ic" style={{ color: m.color }}><Icon name={m.icon} size={20} /></span>
                <div className="w-notif__bd">
                  <div className="t">{n.title}</div>
                  <div className="d">{n.desc}</div>
                  <div className="ts">{n.ts}</div>
                  {n.request && (
                    <div className="w-notif__req">
                      <Button kind="primary" size="sm" onClick={(e) => { e.stopPropagation(); onAct(n.id, 'approve'); }}>{tr(lang, 'Approve')}</Button>
                      <Button kind="tertiary" size="sm" onClick={(e) => { e.stopPropagation(); onAct(n.id, 'deny'); }}>{tr(lang, 'Deny')}</Button>
                    </div>
                  )}
                </div>
                {n.unread && <span className="w-notif__dot" />}
              </div>
            );
          })}
        </div>
      </div>
    </SidePanel>
  );
}

Object.assign(window, { NotificationsPanel, SEED_NOTIFS });
