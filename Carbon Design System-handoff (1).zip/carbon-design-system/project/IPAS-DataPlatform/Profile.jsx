/* global React, PageHead, WireTable, TableToolbar, Overflow, StatusDot, Modal, tr */
const { Icon, Tag, Button, TextInput, Dropdown, Toggle, Checkbox, Tabs } = window.CarbonDesignSystem_280d33;

const PR_CSS = `
.pr-card { background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:24px; max-width:760px; }
.pr-id { display:flex; align-items:center; gap:20px; margin-bottom:24px; }
.pr-id .av { width:72px; height:72px; border-radius:50%; background:var(--cds-blue-60); color:#fff; display:flex; align-items:center; justify-content:center; font-size:1.5rem; font-weight:600; flex:0 0 72px; }
.pr-id .nm { font-size:1.25rem; font-weight:600; color:var(--cds-text-primary); }
.pr-id .em { font-size:.875rem; color:var(--cds-text-secondary); font-family:var(--cds-font-mono); }
.pr-id .badges { display:flex; gap:6px; margin-top:8px; }
.pr-ro { display:inline-flex; align-items:center; gap:6px; font-size:.6875rem; color:var(--cds-text-secondary); background:var(--cds-layer-01); border:1px solid var(--wire-border); padding:3px 8px; }
.pr-matrix { width:100%; border-collapse:collapse; border:1px solid var(--wire-border); font-size:.8125rem; }
.pr-matrix th, .pr-matrix td { border:1px solid var(--wire-border); padding:8px 12px; text-align:center; }
.pr-matrix th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.pr-matrix td:first-child, .pr-matrix th:first-child { text-align:left; color:var(--cds-text-primary); font-weight:500; }
.pr-matrix input { accent-color:var(--cds-blue-60); width:16px; height:16px; }
.pr-grp { margin-bottom:28px; }
.pr-grp h3 { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); margin:0 0 4px; }
.pr-grp p.h { font-size:.75rem; color:var(--cds-text-secondary); margin:0 0 14px; }
`;
(function(){ if (!document.getElementById('ipas-pr-styles')) { const e=document.createElement('style'); e.id='ipas-pr-styles'; e.textContent=PR_CSS; document.head.appendChild(e);} })();

function MyProfile({ lang }) {
  return (
    <div className="pr-card">
      <div className="pr-id">
        <span className="av">LM</span>
        <div>
          <div className="nm">Lena Marsh</div>
          <div className="em">lmarsh@ipas</div>
          <div className="badges"><Tag type="blue" size="sm">{tr(lang, 'Data Engineer')}</Tag><Tag type="cool-gray" size="sm">Manufacturing</Tag></div>
        </div>
      </div>
      <div style={{ marginBottom: 16 }}><span className="pr-ro"><Icon name="locked" size={14} />{tr(lang, 'Identity fields are managed in corporate IAM (read-only).')}</span></div>
      <div className="w-dl">
        <dt>{tr(lang, 'Full name')}</dt><dd>Lena Marsh</dd>
        <dt>{tr(lang, 'Email')}</dt><dd>lmarsh@ipas</dd>
        <dt>{tr(lang, 'Department')}</dt><dd>Manufacturing Analytics</dd>
        <dt>{tr(lang, 'Identity source')}</dt><dd>Active Directory · SCIM</dd>
        <dt>{tr(lang, 'Member since')}</dt><dd>Mar 2024</dd>
        <dt>{tr(lang, 'Roles')}</dt><dd>Data Engineer, Steward</dd>
      </div>
    </div>
  );
}

function Preferences({ lang, notify }) {
  return (
    <div className="pr-card">
      <div className="pr-grp">
        <h3>{tr(lang, 'Appearance')}</h3>
        <p className="h">{tr(lang, 'Choose how the platform looks.')}</p>
        <div style={{ display: 'flex', gap: 8 }}>
          {['Light', 'Dark', 'High contrast'].map((m, i) => (
            <Button key={m} kind={i === 0 ? 'primary' : 'tertiary'} size="md">{tr(lang, m)}</Button>
          ))}
        </div>
      </div>
      <div className="pr-grp">
        <h3>{tr(lang, 'Localization & defaults')}</h3>
        <div className="w-row" style={{ marginBottom: 16 }}>
          <Dropdown label={tr(lang, 'Language')} items={['English', '中文']} value={lang === 'zh' ? '中文' : 'English'} onChange={() => {}} />
          <Dropdown label={tr(lang, 'Timezone')} items={['UTC', 'America/New_York', 'Asia/Shanghai']} value="Asia/Shanghai" onChange={() => {}} />
        </div>
        <div className="w-row" style={{ marginBottom: 16 }}>
          <Dropdown label={tr(lang, 'Default landing page')} items={['Home / Overview', 'Dashboards', 'Pipelines']} value="Home / Overview" onChange={() => {}} />
          <Dropdown label={tr(lang, 'Default query engine')} items={['Auto', 'ClickHouse', 'Trino']} value="Auto" onChange={() => {}} />
        </div>
        <div className="w-row">
          <Dropdown label={tr(lang, 'Table page size')} items={['10', '25', '50']} value="25" onChange={() => {}} />
          <Dropdown label={tr(lang, 'Date format')} items={['YYYY-MM-DD', 'DD/MM/YYYY', 'MM/DD/YYYY']} value="YYYY-MM-DD" onChange={() => {}} />
        </div>
      </div>
      <Button kind="primary" icon="save" onClick={() => notify && notify({ kind: 'success', title: tr(lang, 'Preferences saved.') })}>{tr(lang, 'Save preferences')}</Button>
    </div>
  );
}

const NOTIF_EVENTS = ['Pipeline success', 'Pipeline failure', 'Quality alert', 'SLA breach', 'Access request', 'Mentions', 'Announcements'];
function NotificationSettings({ lang, notify }) {
  return (
    <div className="pr-card" style={{ maxWidth: 680 }}>
      <div className="pr-grp" style={{ marginBottom: 16 }}>
        <h3>{tr(lang, 'Notification channels')}</h3>
        <p className="h">{tr(lang, 'Pick how you are notified for each event type.')}</p>
      </div>
      <table className="pr-matrix">
        <thead><tr><th>{tr(lang, 'Event')}</th><th>{tr(lang, 'In-app')}</th><th>{tr(lang, 'Email')}</th><th>IM</th></tr></thead>
        <tbody>
          {NOTIF_EVENTS.map((e, i) => (
            <tr key={e}><td>{tr(lang, e)}</td>
              <td><input type="checkbox" defaultChecked /></td>
              <td><input type="checkbox" defaultChecked={i < 4} /></td>
              <td><input type="checkbox" defaultChecked={i === 1 || i === 3} /></td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ display: 'flex', gap: 24, margin: '20px 0', flexWrap: 'wrap' }}>
        <Toggle size="sm" label={tr(lang, 'Daily digest instead of per-event email')} />
        <Toggle size="sm" label={tr(lang, 'Mute 22:00–07:00')} defaultChecked />
      </div>
      <Button kind="primary" icon="save" onClick={() => notify && notify({ kind: 'success', title: tr(lang, 'Notification settings saved.') })}>{tr(lang, 'Save settings')}</Button>
    </div>
  );
}

function MyPermissions({ lang }) {
  const cols = [
    { key: 'asset', label: tr(lang, 'Asset'), cellClass: 'mono' },
    { key: 'access', label: tr(lang, 'Access') },
    { key: 'masking', label: tr(lang, 'Masking applied') },
  ];
  const rows = [
    { asset: 'gold.fact_production', access: 'Read / Write', masking: 'None' },
    { asset: 'gold.dim_product', access: 'Read', masking: 'None' },
    { asset: 'silver.orders', access: 'Read', masking: 'customer_id → hash' },
    { asset: 'silver.customers', access: 'Read', masking: 'email → partial, ssn → full' },
    { asset: 'gold.spc_xbar_r_chart', access: 'Read', masking: 'row filter: process_id IN (P1,P2)' },
  ];
  return (
    <div>
      <div style={{ display: 'flex', gap: 8, marginBottom: 16, flexWrap: 'wrap' }}>
        <span className="pr-ro"><Icon name="security" size={14} />{tr(lang, 'Effective access — computed from your roles & policies')}</span>
      </div>
      <div className="pr-grp" style={{ maxWidth: 760 }}>
        <h3>{tr(lang, 'My roles')}</h3>
        <div style={{ display: 'flex', gap: 6, marginTop: 8 }}><Tag type="blue" size="md">Data Engineer</Tag><Tag type="purple" size="md">Steward</Tag></div>
      </div>
      <div className="w-tblwrap" style={{ maxWidth: 920 }}>
        <TableToolbar placeholder={tr(lang, 'Search assets I can access')} search="" onSearch={() => {}}
          actions={<Button kind="primary" size="lg" icon="add">{tr(lang, 'Request access')}</Button>} />
        <WireTable columns={cols} rows={rows} footer={false}
          renderCell={(r, k) => k === 'masking' ? (r.masking === 'None' ? <Tag type="green" size="sm">None</Tag> : <span style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.75rem' }}>{r.masking}</span>) : r[k]} />
      </div>
    </div>
  );
}

function MyApiKeys({ lang, notify }) {
  const [open, setOpen] = React.useState(false);
  const [created, setCreated] = React.useState(false);
  const cols = [
    { key: 'name', label: tr(lang, 'Name'), cellClass: 'name' },
    { key: 'prefix', label: tr(lang, 'Token'), cellClass: 'mono' },
    { key: 'scope', label: tr(lang, 'Scopes') },
    { key: 'used', label: tr(lang, 'Last used') },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  const rows = [
    { name: 'personal-cli', prefix: 'ipas_pat_4f9a…', scope: 'read:gold', used: '2 hours ago' },
    { name: 'notebook-dev', prefix: 'ipas_pat_b21c…', scope: 'read:silver, read:gold', used: 'Yesterday' },
  ];
  return (
    <div>
      <div className="w-tblwrap" style={{ maxWidth: 920 }}>
        <TableToolbar placeholder={tr(lang, 'Search keys')} search="" onSearch={() => {}}
          actions={<Button kind="primary" size="lg" icon="add" onClick={() => { setOpen(true); setCreated(false); }}>{tr(lang, 'Create API key')}</Button>} />
        <WireTable columns={cols} rows={rows} footer={false}
          renderCell={(r, k) => {
            if (k === 'scope') return <Tag type="cool-gray" size="sm">{r.scope}</Tag>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup={tr(lang, 'Personal access token')} title={tr(lang, 'Create API key')} onClose={() => setOpen(false)}
          footer={created
            ? <Button kind="primary" onClick={() => setOpen(false)}>{tr(lang, 'Done')}</Button>
            : <React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>{tr(lang, 'Cancel')}</Button><Button kind="primary" icon="add" onClick={() => { setCreated(true); }}>{tr(lang, 'Generate token')}</Button></React.Fragment>}>
          {created ? (
            <div className="w-fld">
              <label>{tr(lang, 'Copy this token now — it will not be shown again.')}</label>
              <div style={{ display: 'flex', gap: 8 }}>
                <div style={{ flex: 1, fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', background: 'var(--cds-gray-100)', color: '#f4f4f4', padding: '12px 14px', wordBreak: 'break-all' }}>ipas_pat_9e2b7c41a8f0d3654b9012ee</div>
                <Button kind="tertiary" icon="copy" onClick={() => notify && notify({ kind: 'info', title: tr(lang, 'Token copied.') })}>{tr(lang, 'Copy')}</Button>
              </div>
            </div>
          ) : (
            <React.Fragment>
              <TextInput label={tr(lang, 'Key name')} placeholder="personal-cli" />
              <div className="w-row">
                <Dropdown label={tr(lang, 'Scope')} items={['read:gold', 'read:silver', 'write:pipelines']} value="read:gold" onChange={() => {}} />
                <Dropdown label={tr(lang, 'Expiry')} items={['30 days', '90 days', '1 year', 'No expiry']} value="90 days" onChange={() => {}} />
              </div>
            </React.Fragment>
          )}
        </Modal>
      )}
    </div>
  );
}

function Sessions({ lang, notify }) {
  const sessions = [
    { dev: 'MacBook Pro · Chrome', loc: 'Shanghai, CN', ip: '10.4.22.18', when: 'Active now', cur: true },
    { dev: 'iPhone 15 · Safari', loc: 'Shanghai, CN', ip: '10.4.30.9', when: '3 hours ago' },
    { dev: 'Windows · Edge', loc: 'Singapore, SG', ip: '52.187.11.4', when: '2 days ago' },
  ];
  return (
    <div className="pr-card" style={{ maxWidth: 760 }}>
      <div className="pr-grp" style={{ marginBottom: 16 }}>
        <h3>{tr(lang, 'Active sessions')}</h3>
        <p className="h">{tr(lang, 'Your password is managed in corporate SSO (Keycloak).')}</p>
      </div>
      {sessions.map((s, i) => (
        <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '12px 0', borderBottom: i < sessions.length - 1 ? '1px solid var(--wire-border)' : 'none' }}>
          <Icon name={s.dev.includes('iPhone') ? 'mobile' : 'laptop'} size={20} style={{ color: 'var(--cds-icon-secondary)' }} />
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: '.8125rem', color: 'var(--cds-text-primary)', fontWeight: 500 }}>{s.dev}{s.cur && <Tag type="green" size="sm" style={{ marginLeft: 8 }}>{tr(lang, 'This device')}</Tag>}</div>
            <div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', fontFamily: 'var(--cds-font-mono)' }}>{s.loc} · {s.ip} · {s.when}</div>
          </div>
          {!s.cur && <Button kind="ghost" size="sm" onClick={() => notify && notify({ kind: 'info', title: tr(lang, 'Session signed out.') })}>{tr(lang, 'Sign out')}</Button>}
        </div>
      ))}
      <div style={{ marginTop: 20 }}><Button kind="danger" size="md" icon="logout" onClick={() => notify && notify({ kind: 'info', title: tr(lang, 'Signed out of all other sessions.') })}>{tr(lang, 'Sign out all other sessions')}</Button></div>
    </div>
  );
}

const PR_TABS = [
  { id: 'profile', label: 'My profile' },
  { id: 'prefs', label: 'Preferences' },
  { id: 'notify', label: 'Notification settings' },
  { id: 'perms', label: 'My permissions' },
  { id: 'keys', label: 'API keys' },
  { id: 'sessions', label: 'Security & sessions' },
];

function Profile({ tab, lang, notify, onNavigate }) {
  const idx = Math.max(0, PR_TABS.findIndex((t) => t.id === (tab || 'profile')));
  return (
    <div className="w-page">
      <PageHead crumb={[tr(lang, 'Personal center'), tr(lang, PR_TABS[idx].label)]} title={tr(lang, 'Personal center')} sub={tr(lang, 'Your profile, preferences, permissions, and security.')} />
      <Tabs selectedIndex={idx} tabs={PR_TABS.map((t) => ({
        label: tr(lang, t.label),
        content: (
          <div style={{ marginTop: 16 }}>
            {t.id === 'profile' && <MyProfile lang={lang} />}
            {t.id === 'prefs' && <Preferences lang={lang} notify={notify} />}
            {t.id === 'notify' && <NotificationSettings lang={lang} notify={notify} />}
            {t.id === 'perms' && <MyPermissions lang={lang} />}
            {t.id === 'keys' && <MyApiKeys lang={lang} notify={notify} />}
            {t.id === 'sessions' && <Sessions lang={lang} notify={notify} />}
          </div>
        ),
      }))} />
    </div>
  );
}

Object.assign(window, { Profile });
