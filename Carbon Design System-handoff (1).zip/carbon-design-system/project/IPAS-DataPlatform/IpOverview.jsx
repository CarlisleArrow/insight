/* global React, PageHead, WireTable, StatusDot, BarChart, Overflow, tr */
const { Icon, Tag, Button } = window.CarbonDesignSystem_280d33;

const OV_CSS = `
.ov-greet { display:flex; align-items:flex-end; justify-content:space-between; gap:24px; margin-bottom:24px; flex-wrap:wrap; }
.ov-greet h1 { font-size:1.75rem; font-weight:300; margin:0; color:var(--cds-text-primary); }
.ov-greet h1 b { font-weight:600; }
.ov-greet .badges { display:flex; gap:8px; align-items:center; }
.ov-kpis { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.ov-kpi { background:var(--cds-layer-02); padding:20px; }
.ov-kpi .k { font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.ov-kpi .v { font-size:2.5rem; font-weight:300; line-height:1; margin-top:12px; color:var(--cds-text-primary); }
.ov-kpi .v.ok { color:var(--cds-support-success); } .ov-kpi .v.fail { color:var(--cds-support-error); } .ov-kpi .v.warn { color:var(--cds-support-warning); }
.ov-kpi .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:8px; display:flex; align-items:center; gap:4px; }
.ov-grid { display:grid; grid-template-columns:1.6fr 1fr; gap:16px; align-items:start; }
.ov-block { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.ov-block__h { display:flex; align-items:center; gap:8px; height:48px; padding:0 16px; border-bottom:1px solid var(--wire-border); font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.ov-block__h .more { margin-left:auto; }
.ov-quick { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.ov-qa { background:var(--cds-layer-02); border:none; padding:18px 16px; display:flex; align-items:center; gap:12px; cursor:pointer; font-family:var(--cds-font-sans); text-align:left; }
.ov-qa:hover { background:var(--cds-layer-hover-01); }
.ov-qa .ic { width:36px; height:36px; flex:0 0 36px; background:rgba(15,98,254,.08); color:var(--cds-blue-60); display:flex; align-items:center; justify-content:center; }
.ov-qa .t { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.ov-qa .s { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; }
.ov-req { padding:14px 16px; border-bottom:1px solid var(--wire-border); }
.ov-req:last-child { border-bottom:none; }
.ov-req .t { font-size:.8125rem; color:var(--cds-text-primary); }
.ov-req .s { font-size:.75rem; color:var(--cds-text-secondary); margin:2px 0 10px; }
.ov-req .acts { display:flex; gap:8px; }
.ov-fav { display:flex; align-items:center; gap:10px; padding:12px 16px; border-bottom:1px solid var(--wire-border); cursor:pointer; }
.ov-fav:last-child { border-bottom:none; }
.ov-fav:hover { background:var(--cds-layer-hover-01); }
.ov-fav .ic { color:var(--cds-blue-60); display:flex; }
.ov-fav .nm { font-size:.8125rem; color:var(--cds-text-primary); font-weight:500; }
.ov-fav .mt { font-size:.6875rem; color:var(--cds-text-secondary); }
`;
(function(){ if (!document.getElementById('ipas-ov-styles')) { const e=document.createElement('style'); e.id='ipas-ov-styles'; e.textContent=OV_CSS; document.head.appendChild(e);} })();

const OV_RUNS = [
  { id: 1, pipe: 'erp_to_gold', status: 'Success', dur: '11m 04s', when: '14:32' },
  { id: 2, pipe: 'mes_stream', status: 'Running', dur: '—', when: '14:30' },
  { id: 3, pipe: 'crm_sync', status: 'Failed', dur: '1m 02s', when: '14:18' },
  { id: 4, pipe: 'finance_daily', status: 'Success', dur: '3m 30s', when: '13:55' },
  { id: 5, pipe: 'logistics_etl', status: 'Success', dur: '5m 01s', when: '13:40' },
];
const OV_FAVS = [
  { name: 'Production Yield Overview', mt: 'Edited 2 hours ago' },
  { name: 'SPC Control — Line 4', mt: 'Viewed yesterday' },
  { name: 'Daily Revenue & Margin', mt: 'Viewed 3 days ago' },
];

function IpOverview({ notify, lang, onNavigate }) {
  const h = new Date().getHours();
  const greetEn = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  const greet = lang === 'zh' ? (h < 12 ? '早上好' : h < 18 ? '下午好' : '晚上好') : greetEn;
  const runCols = [
    { key: 'pipe', label: tr(lang, 'Pipeline'), cellClass: 'mono' },
    { key: 'status', label: tr(lang, 'Status') },
    { key: 'dur', label: tr(lang, 'Duration') },
    { key: 'when', label: tr(lang, 'Started') },
  ];
  return (
    <div className="w-page">
      <div className="ov-greet">
        <h1>{greet}, <b>Lena</b>.</h1>
        <div className="badges">
          <Tag type="blue" size="md">Manufacturing</Tag>
          <Tag type="cool-gray" size="md">{tr(lang, 'Data Engineer')}</Tag>
        </div>
      </div>

      <div className="ov-kpis">
        <div className="ov-kpi"><div className="k"><Icon name="checkmark--filled" size={16} />{tr(lang, 'Healthy pipelines')}</div><div className="v ok">38</div><div className="d"><Icon name="arrow--up" size={14} />2 since yesterday</div></div>
        <div className="ov-kpi"><div className="k"><Icon name="error--filled" size={16} />{tr(lang, 'Failed (24h)')}</div><div className="v fail">7</div><div className="d">3 awaiting retry</div></div>
        <div className="ov-kpi"><div className="k"><Icon name="data--base" size={16} />{tr(lang, 'Catalog assets')}</div><div className="v">186</div><div className="d">12 certified this week</div></div>
        <div className="ov-kpi"><div className="k"><Icon name="warning--filled" size={16} />{tr(lang, 'Open alerts')}</div><div className="v warn">4</div><div className="d">1 SLA breach</div></div>
      </div>

      <div className="ov-quick">
        <button className="ov-qa" onClick={() => onNavigate('devconfig')}><span className="ic"><Icon name="flow" size={20} /></span><span><div className="t">{tr(lang, 'New pipeline')}</div><div className="s">{tr(lang, 'Ingest a source to a layer')}</div></span></button>
        <button className="ov-qa" onClick={() => onNavigate('analytics')}><span className="ic"><Icon name="dashboard" size={20} /></span><span><div className="t">{tr(lang, 'New dashboard')}</div><div className="s">{tr(lang, 'Build on the canvas')}</div></span></button>
        <button className="ov-qa" onClick={() => onNavigate('analytics')}><span className="ic"><Icon name="terminal" size={20} /></span><span><div className="t">{tr(lang, 'Run a query')}</div><div className="s">{tr(lang, 'Visual builder or SQL')}</div></span></button>
      </div>

      <div className="ov-grid">
        <div className="ov-block">
          <div className="ov-block__h"><Icon name="flow" size={16} />{tr(lang, 'Recent pipelines')}<Button className="more" kind="ghost" size="sm" onClick={() => onNavigate('monitoring')}>{tr(lang, 'View all')}</Button></div>
          <WireTable columns={runCols} rows={OV_RUNS} footer={false} onRowClick={() => onNavigate('monitoring')}
            renderCell={(r, k) => k === 'status' ? <StatusDot kind={r.status}>{r.status}</StatusDot> : r[k]} />
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
          <div className="ov-block">
            <div className="ov-block__h"><Icon name="user--follow" size={16} />{tr(lang, 'Pending access requests')}<Tag type="red" size="sm" style={{ marginLeft: 'auto' }}>2</Tag></div>
            <div className="ov-req">
              <div className="t">Ade Okafor → <b>Analyst</b></div>
              <div className="s">gold.fact_production · requested 2 min ago</div>
              <div className="acts"><Button kind="primary" size="sm" onClick={() => notify({ kind: 'success', title: 'Access approved' })}>{tr(lang, 'Approve')}</Button><Button kind="tertiary" size="sm" onClick={() => notify({ kind: 'info', title: 'Access denied' })}>{tr(lang, 'Deny')}</Button></div>
            </div>
            <div className="ov-req">
              <div className="t">Mara Díaz → <b>dataset access</b></div>
              <div className="s">silver.shipments · requested 1 hour ago</div>
              <div className="acts"><Button kind="primary" size="sm" onClick={() => notify({ kind: 'success', title: 'Access approved' })}>{tr(lang, 'Approve')}</Button><Button kind="tertiary" size="sm" onClick={() => notify({ kind: 'info', title: 'Access denied' })}>{tr(lang, 'Deny')}</Button></div>
            </div>
          </div>

          <div className="ov-block">
            <div className="ov-block__h"><Icon name="dashboard" size={16} />{tr(lang, 'My dashboards')}</div>
            {OV_FAVS.map((f) => (
              <div key={f.name} className="ov-fav" onClick={() => onNavigate('analytics')}>
                <span className="ic"><Icon name="star--filled" size={16} /></span>
                <span style={{ flex: 1 }}><div className="nm">{f.name}</div><div className="mt">{f.mt}</div></span>
                <Icon name="chevron--right" size={16} style={{ color: 'var(--cds-icon-secondary)' }} />
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { IpOverview });
