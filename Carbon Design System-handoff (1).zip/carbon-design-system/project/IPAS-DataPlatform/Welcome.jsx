/* global React, tr */
const { Icon } = window.CarbonDesignSystem_280d33;

const WELCOME_CSS = `
.wc { min-height:100vh; box-sizing:border-box; padding:56px 56px 64px; display:flex; flex-direction:column; justify-content:center; }
.wc-hero { display:flex; align-items:center; gap:40px; margin-bottom:48px; }
.wc-hero__text { flex:1; min-width:0; }
.wc-h1 { font-size:clamp(2rem,3.2vw,2.75rem); font-weight:300; line-height:1.16; color:var(--cds-text-primary); margin:0; letter-spacing:-.3px; }
.wc-sub { font-size:1.25rem; color:var(--cds-text-secondary); margin:18px 0 0; font-weight:400; }
.wc-hero__illus { flex:0 0 420px; }
.wc-hero__illus svg { width:100%; height:auto; display:block; }
.wc-actions { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:16px; max-width:1000px; }
.wc-tile { position:relative; background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:20px; cursor:pointer; min-height:150px; display:flex; flex-direction:column; transition:box-shadow .11s, border-color .11s; text-align:left; }
.wc-tile:hover { box-shadow:0 2px 12px rgba(0,0,0,.12); border-color:var(--cds-border-strong-01); }
.wc-tile .ic { color:var(--cds-icon-primary); margin-bottom:18px; }
.wc-tile h3 { font-size:1rem; font-weight:600; margin:0 0 6px; color:var(--cds-text-primary); }
.wc-tile p { font-size:.875rem; color:var(--cds-text-secondary); margin:0; line-height:1.42; }
.wc-tile .go { position:absolute; right:16px; bottom:14px; color:var(--cds-link-primary); opacity:0; transition:opacity .11s; }
.wc-tile:hover .go { opacity:1; }
@media (max-width: 1080px) { .wc-hero { flex-direction:column-reverse; align-items:flex-start; } .wc-hero__illus { flex:0 0 auto; width:340px; } .wc-actions { grid-template-columns:repeat(2,1fr); } }
`;
(function(){ if (!document.getElementById('ipas-welcome-styles')) { const e=document.createElement('style'); e.id='ipas-welcome-styles'; e.textContent=WELCOME_CSS; document.head.appendChild(e);} })();

function Cloud({ x, y, s = 1, fill }) {
  return (
    <g transform={`translate(${x},${y}) scale(${s})`} fill={fill}>
      <rect x="6" y="30" width="84" height="22" rx="11" />
      <circle cx="28" cy="30" r="18" />
      <circle cx="56" cy="23" r="25" />
      <circle cx="80" cy="32" r="16" />
    </g>
  );
}

function WelcomeIllustration() {
  return (
    <svg viewBox="0 0 440 380" role="img" aria-label="SiPTORY InSight data flow illustration">
      <defs>
        <linearGradient id="wcCloudA" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#4589ff" /><stop offset="1" stopColor="#0f62fe" />
        </linearGradient>
        <marker id="wcArr" markerWidth="9" markerHeight="9" refX="4.5" refY="4.5" orient="auto">
          <path d="M1,1 L8,4.5 L1,8" fill="none" stroke="#8d8d8d" strokeWidth="1.4" />
        </marker>
      </defs>

      {/* flow ring with two arrowheads (gaps left open) */}
      <path d="M210 70 A140 140 0 0 1 350 210" fill="none" stroke="#c6c6c6" strokeWidth="1.6" markerEnd="url(#wcArr)" />
      <path d="M350 210 A140 140 0 0 1 210 350" fill="none" stroke="#c6c6c6" strokeWidth="1.6" markerEnd="url(#wcArr)" />
      <path d="M210 350 A140 140 0 0 1 86 286" fill="none" stroke="#c6c6c6" strokeWidth="1.6" markerEnd="url(#wcArr)" />
      <path d="M78 270 A140 140 0 0 1 150 92" fill="none" stroke="#c6c6c6" strokeWidth="1.6" />

      {/* clouds */}
      <Cloud x={300} y={86} s={1.15} fill="url(#wcCloudA)" />
      <Cloud x={250} y={150} s={0.7} fill="#a6c8ff" />

      {/* hexagon network node */}
      <g>
        <polygon points="150,36 184,55 184,93 150,112 116,93 116,55" fill="#d9fbfb" stroke="#009d9a" strokeWidth="1.6" />
        <g stroke="#009d9a" strokeWidth="1.3">
          <line x1="150" y1="74" x2="133" y2="60" /><line x1="150" y1="74" x2="167" y2="62" />
          <line x1="150" y1="74" x2="136" y2="90" /><line x1="150" y1="74" x2="166" y2="88" />
        </g>
        <g fill="#009d9a">
          <circle cx="150" cy="74" r="3.4" /><circle cx="133" cy="60" r="2.6" /><circle cx="167" cy="62" r="2.6" />
          <circle cx="136" cy="90" r="2.6" /><circle cx="166" cy="88" r="2.6" />
        </g>
      </g>

      {/* blue accent dots on ring */}
      <circle cx="210" cy="70" r="7" fill="#0f62fe" />
      <circle cx="210" cy="350" r="7" fill="#0f62fe" />

      {/* triangle (play) accent */}
      <polygon points="78,260 78,290 104,275" fill="#3ddbd9" />

      {/* three asset tiles arc'd inside the ring */}
      <g>
        <rect x="120" y="196" width="60" height="78" fill="#ffffff" stroke="#e0e0e0" strokeWidth="1.4" />
        <circle cx="135" cy="214" r="5" fill="none" stroke="#161616" strokeWidth="1.4" /><circle cx="139" cy="218" r="2" fill="#161616" />
        <rect x="128" y="232" width="44" height="4" fill="#e0e0e0" /><rect x="128" y="242" width="36" height="4" fill="#e0e0e0" /><rect x="128" y="252" width="40" height="4" fill="#e0e0e0" />

        <rect x="190" y="208" width="60" height="78" fill="#ffffff" stroke="#e0e0e0" strokeWidth="1.4" />
        <path d="M205 222 h16 M213 222 v10 M209 228 l4 4 4 -4" fill="none" stroke="#161616" strokeWidth="1.4" />
        <rect x="198" y="244" width="44" height="4" fill="#e0e0e0" /><rect x="198" y="254" width="36" height="4" fill="#e0e0e0" /><rect x="198" y="264" width="40" height="4" fill="#e0e0e0" />

        <rect x="260" y="200" width="60" height="78" fill="#ffffff" stroke="#e0e0e0" strokeWidth="1.4" />
        <polygon points="290,214 297,219 290,224 283,219" fill="none" stroke="#161616" strokeWidth="1.4" />
        <rect x="268" y="236" width="44" height="4" fill="#e0e0e0" /><rect x="268" y="246" width="36" height="4" fill="#e0e0e0" /><rect x="268" y="256" width="40" height="4" fill="#e0e0e0" />
      </g>
    </svg>
  );
}

const WC_ACTIONS = [
  { icon: 'dashboard', title: 'Build a dashboard', desc: 'Compose charts on a drag-and-drop canvas.', to: 'analytics' },
  { icon: 'data--base', title: 'Define a metric', desc: 'Add a governed metric to the metrics store.', to: 'modeling' },
  { icon: 'folder', title: 'Browse the catalog', desc: 'Search every table and field across layers.', to: 'governance' },
  { icon: 'chart--line', title: 'Check operations', desc: 'Monitor pipeline runs and data SLAs.', to: 'monitoring' },
];

function Welcome({ onNavigate, lang }) {
  const h = new Date().getHours();
  const greetEn = h < 12 ? 'Morning' : h < 18 ? 'Afternoon' : 'Evening';
  const greetZh = h < 12 ? '早上好' : h < 18 ? '下午好' : '晚上好';
  const line1 = lang === 'zh' ? `${greetZh}，Lena。` : `${greetEn}, Lena.`;
  return (
    <div className="wc">
      <div className="wc-hero">
        <div className="wc-hero__text">
          <h1 className="wc-h1">{line1}<br />{tr(lang, 'Welcome to SiPTORY InSight')}</h1>
          <p className="wc-sub">{tr(lang, 'What do you want to do today?')}</p>
        </div>
        <div className="wc-hero__illus"><WelcomeIllustration /></div>
      </div>
      <div className="wc-actions">
        {WC_ACTIONS.map((a) => (
          <button key={a.to} className="wc-tile" onClick={() => onNavigate(a.to)}>
            <span className="ic"><Icon name={a.icon} size={24} /></span>
            <h3>{tr(lang, a.title)}</h3>
            <p>{tr(lang, a.desc)}</p>
            <span className="go"><Icon name="arrow--right" size={20} /></span>
          </button>
        ))}
      </div>
    </div>
  );
}

Object.assign(window, { Welcome });
