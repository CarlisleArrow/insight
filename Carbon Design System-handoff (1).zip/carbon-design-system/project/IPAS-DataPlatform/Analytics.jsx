/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, BarChart, EmptyState, FieldChip, StatusDot, ToolBtn, tr, trList */
const { Icon, Tag, Button, Search, TextInput, Dropdown, Toggle, Checkbox } = window.CarbonDesignSystem_280d33;

const ANALYTICS_CSS = `
.an-gallery { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:16px; }
.an-gallery.list { display:block; }
.an-card { background:var(--cds-layer-02); border:1px solid var(--wire-border); cursor:pointer; transition:box-shadow .11s, border-color .11s; }
.an-card:hover { box-shadow:var(--cds-shadow-overlay,0 2px 8px rgba(0,0,0,.16)); border-color:var(--cds-border-strong-01); }
.an-card__meta { padding:12px 16px 16px; }
.an-card__meta h3 { font-size:.875rem; font-weight:600; margin:0 0 8px; color:var(--cds-text-primary); }
.an-card__meta .row { display:flex; align-items:center; gap:6px; font-size:.75rem; color:var(--cds-text-secondary); margin-top:4px; }
.an-card__tags { display:flex; gap:6px; margin-top:10px; flex-wrap:wrap; }
.an-listcard { display:flex; align-items:center; gap:16px; background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:12px 16px; margin-bottom:-1px; cursor:pointer; }
.an-listcard:hover { background:var(--cds-layer-hover-01); }
.an-listcard .th { width:80px; height:48px; flex:0 0 auto; }

/* editor */
.an-editor { display:flex; flex-direction:column; height:100vh; }
.an-editor__body { display:flex; flex:1; min-height:0; }
.an-pane { background:var(--cds-layer-02); border-right:1px solid var(--wire-border); display:flex; flex-direction:column; min-height:0; }
.an-pane--right { border-right:none; border-left:1px solid var(--wire-border); }
.an-pane__h { display:flex; align-items:center; gap:8px; height:40px; padding:0 8px 0 16px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; letter-spacing:.16px; color:var(--cds-text-primary); }
.an-pane__h .x { margin-left:auto; width:28px; height:28px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.an-pane__h .x:hover { background:var(--cds-layer-hover-01); }
.an-pane__body { padding:12px; overflow:auto; flex:1; min-height:0; }
.an-palette { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
.an-charttype { display:flex; flex-direction:column; align-items:center; gap:6px; padding:10px 4px; border:1px solid var(--wire-border); background:var(--cds-layer-02); cursor:grab; font-size:.6875rem; color:var(--cds-text-secondary); text-align:center; }
.an-charttype:hover { border-color:var(--cds-border-interactive); color:var(--cds-text-primary); }
.an-canvas { flex:1; position:relative; overflow:auto; padding:16px;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.an-widget { position:absolute; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.08); display:flex; flex-direction:column; }
.an-widget.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.an-widget__h { display:flex; align-items:center; gap:6px; height:32px; padding:0 8px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; color:var(--cds-text-primary); cursor:move; }
.an-widget__h .grip { margin-left:auto; color:var(--cds-icon-secondary); display:flex; }
.an-widget__b { flex:1; padding:8px; min-height:0; }
.an-resize { position:absolute; right:-4px; bottom:-4px; width:12px; height:12px; border-right:2px solid var(--cds-border-interactive); border-bottom:2px solid var(--cds-border-interactive); cursor:nwse-resize; }
.an-shelf { margin-bottom:16px; }
.an-shelf > .lbl { font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); margin-bottom:6px; display:block; }
.an-shelf__drop { min-height:40px; border:1px dashed var(--cds-border-strong-01); padding:6px; display:flex; flex-direction:column; gap:6px; }
.an-pill { display:flex; align-items:center; gap:8px; background:var(--cds-blue-60); color:#fff; font-size:.75rem; padding:4px 8px; }
.an-pill .x { margin-left:auto; cursor:pointer; display:flex; }
.an-pill.agg { background:var(--cds-layer-01); color:var(--cds-text-primary); border:1px solid var(--wire-border); }

/* sql editor */
.an-sql { display:flex; flex-direction:column; gap:0; border:1px solid var(--wire-border); }
.an-sql__bar { display:flex; align-items:center; gap:1px; height:48px; padding:0 8px; border-bottom:1px solid var(--wire-border); background:var(--cds-layer-02); }
.an-sql__bar .spacer { flex:1; }
.an-sql__code { font-family:var(--cds-font-mono); font-size:.8125rem; line-height:1.6; background:var(--cds-gray-100); color:#f4f4f4; padding:16px; min-height:200px; white-space:pre; overflow:auto; }
.an-sql__code .kw { color:#78a9ff; } .an-sql__code .fn { color:#3ddbd9; } .an-sql__code .str { color:#42be65; } .an-sql__code .cm { color:#8d8d8d; }
.an-sql__ln { color:var(--cds-gray-50,#6f6f6f); display:inline-block; width:24px; user-select:none; }
.an-vbuilder { display:flex; gap:0; border:1px solid var(--wire-border); }
.an-vbuilder .step { flex:1; padding:16px; border-right:1px solid var(--wire-border); }
.an-vbuilder .step:last-child { border-right:none; }
.an-vbuilder .step h4 { font-size:.75rem; font-weight:600; margin:0 0 12px; color:var(--cds-text-primary); display:flex; align-items:center; gap:6px; }
.an-fieldlist { display:flex; flex-direction:column; gap:6px; }
`;
(function(){ if (!document.getElementById('ipas-analytics-styles')) { const e=document.createElement('style'); e.id='ipas-analytics-styles'; e.textContent=ANALYTICS_CSS; document.head.appendChild(e);} })();

const DASHBOARDS = [
  { id: 1, name: 'Production Yield Overview', owner: 'L. Marsh', mod: '2 hours ago', tags: ['Manufacturing', 'Gold'] },
  { id: 2, name: 'Daily Revenue & Margin', owner: 'A. Okafor', mod: 'Yesterday', tags: ['Finance'] },
  { id: 3, name: 'Supply Chain Latency', owner: 'R. Vance', mod: '3 days ago', tags: ['Logistics', 'SLA'] },
  { id: 4, name: 'SPC Control — Line 4', owner: 'L. Marsh', mod: '5 days ago', tags: ['Quality', 'SPC'] },
  { id: 5, name: 'Customer Cohort Retention', owner: 'J. Singh', mod: 'Apr 18', tags: ['Growth'] },
  { id: 6, name: 'Warehouse Throughput', owner: 'R. Vance', mod: 'Apr 16', tags: ['Logistics'] },
  { id: 7, name: 'Energy Consumption', owner: 'M. Díaz', mod: 'Apr 12', tags: ['Ops', 'IoT'] },
  { id: 8, name: 'Defect Pareto Analysis', owner: 'L. Marsh', mod: 'Apr 9', tags: ['Quality'] },
];

const CHART_TYPES = [
  { label: 'Line', icon: 'chart--line' }, { label: 'Bar', icon: 'chart--bar' }, { label: 'Pie', icon: 'dashboard' },
  { label: 'Scatter', icon: 'interactions' }, { label: 'Map', icon: 'cloud' }, { label: 'Funnel', icon: 'filter' },
  { label: 'Table', icon: 'list' }, { label: 'SPC chart', icon: 'analytics' },
];

const REPORTS = [
  { id: 1, name: 'Weekly Yield Digest', schedule: '0 7 * * 1', recipients: 'ops-leads@ipas', format: 'PDF', channel: 'Email', status: 'Active' },
  { id: 2, name: 'Daily Revenue Snapshot', schedule: '0 6 * * *', recipients: 'finance@ipas', format: 'Excel', channel: 'Email', status: 'Active' },
  { id: 3, name: 'SLA Breach Alert Roll-up', schedule: '0 */4 * * *', recipients: '#data-sla', format: 'PDF', channel: 'IM', status: 'Active' },
  { id: 4, name: 'Monthly Exec Board Pack', schedule: '0 8 1 * *', recipients: 'exec@ipas', format: 'PDF', channel: 'Email', status: 'Paused' },
  { id: 5, name: 'Quality NCR Summary', schedule: '0 18 * * 5', recipients: 'quality@ipas', format: 'Excel', channel: 'Email', status: 'Draft' },
];

function GalleryCard({ d, list, onOpen }) {
  if (list) {
    return (
      <div className="an-listcard" onClick={onOpen}>
        <Placeholder label="" icon="chart--bar" height={48} style={{ width: 80 }} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 600, fontSize: '.875rem', color: 'var(--cds-text-primary)' }}>{d.name}</div>
          <div style={{ fontSize: '.75rem', color: 'var(--cds-text-secondary)', marginTop: 2 }}>{d.owner} · {d.mod}</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>{d.tags.map((t) => <Tag key={t} type="cool-gray" size="sm">{t}</Tag>)}</div>
        <Overflow />
      </div>
    );
  }
  return (
    <div className="an-card" onClick={onOpen}>
      <Placeholder label="dashboard preview" icon="chart--bar" height={140} style={{ borderTop: 'none', borderLeft: 'none', borderRight: 'none' }} />
      <div className="an-card__meta">
        <h3>{d.name}</h3>
        <div className="row"><Icon name="user--avatar" size={16} />{d.owner}</div>
        <div className="row"><Icon name="time" size={16} />Modified {d.mod}</div>
        <div className="an-card__tags">{d.tags.map((t) => <Tag key={t} type="cool-gray" size="sm">{t}</Tag>)}</div>
      </div>
    </div>
  );
}

function DashboardGallery({ onOpenEditor }) {
  const [view, setView] = React.useState('grid');
  const [q, setQ] = React.useState('');
  const rows = DASHBOARDS.filter((d) => d.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 20 }}>
        <div style={{ flex: 1, maxWidth: 480 }}><Search value={q} onChange={setQ} size="lg" placeholder="Search dashboards" /></div>
        <Dropdown items={['All tags', 'Quality', 'Finance', 'Logistics', 'Ops']} value="All tags" onChange={() => {}} />
        <Dropdown items={['All owners', 'L. Marsh', 'A. Okafor', 'R. Vance']} value="All owners" onChange={() => {}} />
        <div style={{ display: 'flex', border: '1px solid var(--cds-border-strong-01)' }}>
          <Button kind={view === 'grid' ? 'primary' : 'ghost'} size="md" icon="grid" iconOnly onClick={() => setView('grid')} />
          <Button kind={view === 'list' ? 'primary' : 'ghost'} size="md" icon="list" iconOnly onClick={() => setView('list')} />
        </div>
        <Button kind="primary" size="md" icon="add" onClick={onOpenEditor}>Create dashboard</Button>
      </div>
      <div className={`an-gallery ${view === 'list' ? 'list' : ''}`}>
        {rows.map((d) => <GalleryCard key={d.id} d={d} list={view === 'list'} onOpen={onOpenEditor} />)}
      </div>
    </div>
  );
}

function DashboardEditor({ onExit }) {
  const [leftOpen, setLeftOpen] = React.useState(true);
  const [selected, setSelected] = React.useState('w1');
  return (
    <div className="an-editor">
      {/* top toolbar */}
      <div className="w-etoolbar">
        <ToolBtn icon="arrow--left" label="Exit" onClick={onExit} />
        <span className="gap" />
        <ToolBtn icon="save" label="Save" />
        <ToolBtn icon="restart" label="" title="Undo" />
        <ToolBtn icon="renew" label="" title="Redo" />
        <span className="gap" />
        <ToolBtn icon="filter" label="Add filter" />
        <ToolBtn icon="calendar" label="Last 30 days" title="Global date filter" />
        <span className="spacer" />
        <ToolBtn icon="view" label="Preview" />
        <ToolBtn icon="share" label="Share" />
        <span style={{ padding: '0 4px' }}><Button kind="primary" size="sm" icon="send">Subscribe</Button></span>
      </div>

      <div className="an-editor__body">
        {/* left pane */}
        {leftOpen ? (
          <div className="an-pane" style={{ width: 260, flex: '0 0 260px' }}>
            <div className="an-pane__h">Datasets<button className="x" onClick={() => setLeftOpen(false)} aria-label="Collapse"><Icon name="chevron--left" size={16} /></button></div>
            <div className="an-pane__body">
              <div style={{ marginBottom: 8 }}><Search size="sm" placeholder="Search fields" /></div>
              <div className="w-treeitem"><Icon name="data--base" size={16} />fact_production</div>
              <div className="w-section-label" style={{ margin: '8px 4px 4px' }}>Dimensions</div>
              <div className="an-fieldlist">
                {['line_id', 'shift', 'product_sku', 'plant', 'date'].map((f) => <FieldChip key={f} kind="dim">{f}</FieldChip>)}
              </div>
              <div className="w-section-label" style={{ margin: '12px 4px 4px' }}>Measures</div>
              <div className="an-fieldlist">
                {['units_produced', 'defect_count', 'yield_pct', 'cycle_time'].map((f) => <FieldChip key={f} kind="msr">{f}</FieldChip>)}
              </div>
              <div className="an-pane__h" style={{ border: 'none', marginTop: 16, paddingLeft: 0 }}>Chart types</div>
              <div className="an-palette">
                {CHART_TYPES.map((c) => <div key={c.label} className="an-charttype" draggable><Icon name={c.icon} size={20} />{c.label}</div>)}
              </div>
            </div>
          </div>
        ) : (
          <div className="an-pane" style={{ width: 40, flex: '0 0 40px', alignItems: 'center' }}>
            <button className="x" style={{ width: 40, height: 40, border: 'none', background: 'transparent', cursor: 'pointer', color: 'var(--cds-icon-primary)' }} onClick={() => setLeftOpen(true)} aria-label="Expand datasets"><Icon name="chevron--right" size={16} /></button>
          </div>
        )}

        {/* canvas */}
        <div className="an-canvas">
          <div className={`an-widget ${selected === 'w1' ? 'sel' : ''}`} style={{ left: 24, top: 24, width: 360, height: 200 }} onClick={() => setSelected('w1')}>
            <div className="an-widget__h">Yield % by line<span className="grip"><span className="w-grip"><i /><i /><i /><i /><i /><i /></span></span></div>
            <div className="an-widget__b"><BarChart data={[62, 78, 71, 88, 80, 74]} height={120} /></div>
            {selected === 'w1' && <span className="an-resize" />}
          </div>
          <div className={`an-widget ${selected === 'w2' ? 'sel' : ''}`} style={{ left: 408, top: 24, width: 300, height: 200 }} onClick={() => setSelected('w2')}>
            <div className="an-widget__h">Defect trend<span className="grip"><span className="w-grip"><i /><i /><i /><i /><i /><i /></span></span></div>
            <div className="an-widget__b"><Placeholder label="line chart" icon="chart--line" height={120} /></div>
            {selected === 'w2' && <span className="an-resize" />}
          </div>
          <div className={`an-widget ${selected === 'w3' ? 'sel' : ''}`} style={{ left: 24, top: 248, width: 684, height: 180 }} onClick={() => setSelected('w3')}>
            <div className="an-widget__h">SPC control chart — cycle time<span className="grip"><span className="w-grip"><i /><i /><i /><i /><i /><i /></span></span></div>
            <div className="an-widget__b"><Placeholder label="SPC control chart · UCL / LCL" icon="analytics" height={104} /></div>
            {selected === 'w3' && <span className="an-resize" />}
          </div>
          <div className="w-engine"><Icon name="data--base" size={16} /><span>Query engine: <b>ClickHouse</b> · auto-routed</span></div>
        </div>

        {/* right config pane */}
        <div className="an-pane an-pane--right" style={{ width: 280, flex: '0 0 280px' }}>
          <div className="an-pane__h">Configure · Yield % by line</div>
          <div className="an-pane__body">
            <div className="an-shelf">
              <span className="lbl">X axis</span>
              <div className="an-shelf__drop"><span className="an-pill">line_id<span className="x"><Icon name="close" size={16} /></span></span></div>
            </div>
            <div className="an-shelf">
              <span className="lbl">Y axis (measure)</span>
              <div className="an-shelf__drop"><span className="an-pill">yield_pct<span className="x"><Icon name="close" size={16} /></span></span></div>
            </div>
            <div className="an-shelf">
              <span className="lbl">Aggregation</span>
              <Dropdown items={['Average', 'Sum', 'Min', 'Max', 'Count']} value="Average" onChange={() => {}} />
            </div>
            <div className="an-shelf">
              <span className="lbl">Filters</span>
              <div className="an-shelf__drop"><span className="an-pill agg">shift = "Day"<span className="x"><Icon name="close" size={16} /></span></span></div>
            </div>
            <div className="an-shelf">
              <span className="lbl">Calculated field</span>
              <div style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.75rem', background: 'var(--cds-field-01)', border: '1px solid var(--wire-border)', padding: 8, color: 'var(--cds-text-secondary)' }}>1 - (defect_count / units_produced)</div>
            </div>
            <Button kind="tertiary" size="sm" icon="add">Add calculated field</Button>
            <div className="an-shelf" style={{ marginTop: 8 }}>
              <span className="lbl">Style</span>
              <div className="w-fld"><Toggle size="sm" label="Show data labels" defaultChecked /></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SqlBlock() {
  return (
    <div className="an-sql__code"><span className="an-sql__ln">1</span><span className="cm">-- Daily yield by production line</span>
{'\n'}<span className="an-sql__ln">2</span><span className="kw">SELECT</span>  line_id,
{'\n'}<span className="an-sql__ln">3</span>        <span className="fn">avg</span>(yield_pct) <span className="kw">AS</span> avg_yield,
{'\n'}<span className="an-sql__ln">4</span>        <span className="fn">sum</span>(units_produced) <span className="kw">AS</span> units
{'\n'}<span className="an-sql__ln">5</span><span className="kw">FROM</span>    gold.fact_production
{'\n'}<span className="an-sql__ln">6</span><span className="kw">WHERE</span>   event_date {'>='} <span className="str">'2026-04-01'</span>
{'\n'}<span className="an-sql__ln">7</span><span className="kw">GROUP BY</span> line_id
{'\n'}<span className="an-sql__ln">8</span><span className="kw">ORDER BY</span> avg_yield <span className="kw">DESC</span>;</div>
  );
}

function AdHocQuery() {
  const [mode, setMode] = React.useState('sql');
  const cols = [
    { key: 'line_id', label: 'line_id' }, { key: 'avg_yield', label: 'avg_yield' }, { key: 'units', label: 'units' },
  ];
  const data = [
    { line_id: 'LINE-04', avg_yield: '88.2', units: '142,800' },
    { line_id: 'LINE-02', avg_yield: '80.4', units: '131,250' },
    { line_id: 'LINE-05', avg_yield: '78.9', units: '128,910' },
    { line_id: 'LINE-01', avg_yield: '74.1', units: '120,400' },
  ];
  return (
    <div>
      <div style={{ marginBottom: 16, display: 'inline-flex', border: '1px solid var(--cds-border-strong-01)' }}>
        <button className={`w-iconbtn`} style={{ height: 40, padding: '0 16px', background: mode === 'visual' ? 'var(--cds-gray-100)' : 'transparent', color: mode === 'visual' ? '#fff' : 'var(--cds-text-secondary)' }} onClick={() => setMode('visual')}>Visual query builder</button>
        <button className={`w-iconbtn`} style={{ height: 40, padding: '0 16px', borderLeft: '1px solid var(--cds-border-strong-01)', background: mode === 'sql' ? 'var(--cds-gray-100)' : 'transparent', color: mode === 'sql' ? '#fff' : 'var(--cds-text-secondary)' }} onClick={() => setMode('sql')}>SQL editor</button>
      </div>

      {mode === 'visual' ? (
        <div className="an-vbuilder">
          <div className="step"><h4><Icon name="data--base" size={16} />1 · Source</h4><Dropdown items={['gold.fact_production', 'silver.orders', 'gold.dim_product']} value="gold.fact_production" onChange={() => {}} /></div>
          <div className="step"><h4><Icon name="add" size={16} />2 · Fields</h4><div className="an-fieldlist">{['line_id', 'yield_pct', 'units_produced'].map((f) => <FieldChip key={f} kind="">{f}</FieldChip>)}</div></div>
          <div className="step"><h4><Icon name="filter" size={16} />3 · Conditions</h4><div className="an-shelf__drop"><span className="an-pill agg">event_date ≥ 2026-04-01</span></div></div>
          <div className="step"><h4><Icon name="list" size={16} />4 · Group / sort</h4><div className="an-fieldlist"><FieldChip kind="group">line_id</FieldChip><FieldChip kind="sort">avg_yield ↓</FieldChip></div></div>
        </div>
      ) : (
        <div className="an-sql">
          <div className="an-sql__bar">
            <Dropdown items={['gold.fact_production', 'silver.orders']} value="gold.fact_production" onChange={() => {}} style={{ width: 260 }} />
            <span className="spacer" />
            <Button kind="primary" size="sm" icon="play">Run</Button>
          </div>
          <SqlBlock />
        </div>
      )}

      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', margin: '24px 0 8px' }}>
        <div style={{ fontSize: '.875rem', fontWeight: 600, color: 'var(--cds-text-primary)' }}>Results <span style={{ color: 'var(--cds-text-secondary)', fontWeight: 400 }}>· 4 rows · 0.42s</span></div>
        <div style={{ display: 'flex', gap: 1 }}>
          <Button kind="tertiary" size="sm" icon="download">CSV</Button>
          <Button kind="tertiary" size="sm" icon="export">Excel</Button>
        </div>
      </div>
      <WireTable columns={cols} rows={data} footer={false} renderCell={(r, k) => <span style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem' }}>{r[k]}</span>} />
    </div>
  );
}

function ReportSubscriptions({ notify }) {
  const [open, setOpen] = React.useState(false);
  const cols = [
    { key: 'name', label: 'Report', cellClass: 'name' },
    { key: 'schedule', label: 'Schedule', cellClass: 'mono' },
    { key: 'recipients', label: 'Recipients' },
    { key: 'format', label: 'Format' },
    { key: 'channel', label: 'Channel' },
    { key: 'status', label: 'Status' },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  return (
    <div>
      <div className="w-tblwrap" style={{ border: 'none' }}>
        <TableToolbar placeholder="Search subscriptions" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => setOpen(true)}>New subscription</Button></React.Fragment>} />
        <WireTable columns={cols} rows={REPORTS}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => e.preventDefault()}>{r.name}</a>;
            if (k === 'channel') return <Tag type={r.channel === 'IM' ? 'purple' : 'blue'} size="sm">{r.channel}</Tag>;
            if (k === 'status') return <StatusDot kind={r.status}>{r.status}</StatusDot>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Distribution" title="New subscription" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Subscription created.', subtitle: 'First run scheduled.' }); }}>Create</Button></React.Fragment>}>
          <TextInput label="Subscription name" placeholder="Weekly digest" />
          <div className="w-row">
            <Dropdown label="Source dashboard" items={['Production Yield Overview', 'Daily Revenue & Margin']} value="Production Yield Overview" onChange={() => {}} />
            <Dropdown label="Format" items={['PDF', 'Excel', 'PNG']} value="PDF" onChange={() => {}} />
          </div>
          <TextInput label="Schedule (cron)" defaultValue="0 7 * * 1" helperText="Runs every Monday at 07:00." />
          <div className="w-row">
            <Dropdown label="Channel" items={['Email', 'IM', 'Webhook']} value="Email" onChange={() => {}} />
            <TextInput label="Recipients" placeholder="team@ipas" />
          </div>
        </Modal>
      )}
    </div>
  );
}

const ANALYTICS_SUBS = [
  { id: 'gallery', label: 'Dashboard gallery' },
  { id: 'editor', label: 'Dashboard editor' },
  { id: 'query', label: 'Ad-hoc query' },
  { id: 'datasets', label: 'Datasets' },
  { id: 'reports', label: 'Report subscriptions' },
];

const DATASETS = [
  { id: 1, name: 'yield_by_line_daily', source: 'gold.fact_production', owner: 'L. Marsh', refreshed: '14m ago', rows: '142,800', usedBy: 8 },
  { id: 2, name: 'revenue_margin_v2', source: 'SQL · gold.fact_sales', owner: 'A. Okafor', refreshed: '1h ago', rows: '512,440', usedBy: 5 },
  { id: 3, name: 'on_time_delivery', source: 'gold.fact_logistics', owner: 'R. Vance', refreshed: '3h ago', rows: '88,210', usedBy: 3 },
  { id: 4, name: 'spc_cycle_time_l4', source: 'SQL · gold.spc_xbar_r_chart', owner: 'L. Marsh', refreshed: '20m ago', rows: '24,990', usedBy: 2 },
  { id: 5, name: 'cohort_retention', source: 'silver.events', owner: 'J. Singh', refreshed: 'Yesterday', rows: '1,204,000', usedBy: 4 },
];

function Datasets({ notify }) {
  const [open, setOpen] = React.useState(false);
  const [sel, setSel] = React.useState(null);
  const cols = [
    { key: 'name', label: 'Dataset', cellClass: 'name' },
    { key: 'source', label: 'Source', cellClass: 'mono' },
    { key: 'owner', label: 'Owner' },
    { key: 'refreshed', label: 'Last refreshed' },
    { key: 'rows', label: 'Rows' },
    { key: 'usedBy', label: 'Used by' },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  if (sel) {
    const schemaCols = [{ key: 'col', label: 'Column', cellClass: 'mono' }, { key: 'type', label: 'Type' }, { key: 'desc', label: 'Description' }];
    const schema = [
      { col: 'line_id', type: 'varchar', desc: 'Production line' },
      { col: 'event_date', type: 'date', desc: 'Aggregation day' },
      { col: 'avg_yield', type: 'double', desc: 'Average first-pass yield' },
      { col: 'units', type: 'bigint', desc: 'Units produced' },
    ];
    return (
      <div>
        <Button kind="ghost" size="sm" icon="arrow--left" onClick={() => setSel(null)} style={{ marginBottom: 12 }}>Back to datasets</Button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 4 }}>
          <h1 style={{ fontSize: '1.5rem', fontWeight: 400, margin: 0, fontFamily: 'var(--cds-font-mono)' }}>{sel.name}</h1>
          <Tag type="teal" size="sm">Gold</Tag>
        </div>
        <p style={{ color: 'var(--cds-text-secondary)', fontSize: '.875rem', margin: '0 0 20px' }}>{sel.source} · {sel.rows} rows · used by {sel.usedBy} dashboards · owner {sel.owner}</p>
        <div style={{ display: 'flex', gap: 1, marginBottom: 20 }}>
          <Button kind="primary" size="sm" icon="renew" onClick={() => notify && notify({ kind: 'success', title: 'Refresh queued.' })}>Refresh now</Button>
          <Button kind="tertiary" size="sm" icon="edit">Edit definition</Button>
          <Button kind="tertiary" size="sm" icon="chart--bar">Create chart</Button>
        </div>
        <Tabs tabs={[
          { label: 'Schema', content: <div style={{ marginTop: 8 }}><WireTable columns={schemaCols} rows={schema} footer={false} renderCell={(r, k) => r[k]} /></div> },
          { label: 'Definition', content: <div style={{ marginTop: 8 }}><div className="an-sql"><SqlBlock /></div></div> },
          { label: 'Refresh schedule', content: <div style={{ marginTop: 8, maxWidth: 480, display: 'flex', flexDirection: 'column', gap: 16 }}><TextInput label="Schedule (cron)" defaultValue="*/30 * * * *" helperText="Every 30 minutes." /><Toggle size="sm" label="Incremental refresh" defaultChecked /></div> },
          { label: 'Lineage', content: <div style={{ marginTop: 8 }}><Placeholder label="upstream tables → this dataset → dashboards" icon="data--base" height={240} /></div> },
        ]} />
      </div>
    );
  }
  return (
    <div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search datasets" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => setOpen(true)}>Create dataset</Button></React.Fragment>} />
        <WireTable columns={cols} rows={DATASETS} onRowClick={setSel}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => { e.preventDefault(); setSel(r); }}>{r.name}</a>;
            if (k === 'usedBy') return <Tag type="cool-gray" size="sm">{r.usedBy}</Tag>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Datasets" title="Create dataset" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Dataset created.' }); }}>Create</Button></React.Fragment>}>
          <TextInput label="Dataset name" placeholder="yield_by_line_daily" />
          <div className="w-row">
            <Dropdown label="Build from" items={['Saved query', 'Catalog table', 'SQL']} value="Catalog table" onChange={() => {}} />
            <Dropdown label="Source" items={['gold.fact_production', 'silver.orders', 'gold.dim_product']} value="gold.fact_production" onChange={() => {}} />
          </div>
          <TextInput label="Refresh schedule (cron)" defaultValue="*/30 * * * *" helperText="Leave blank for on-demand only." />
        </Modal>
      )}
    </div>
  );
}

function Analytics({ notify, lang }) {
  const [sub, setSub] = React.useState('gallery');

  if (sub === 'editor') {
    // full-bleed editor
    return <DashboardEditor onExit={() => setSub('gallery')} />;
  }

  const TITLES = {
    gallery: ['Dashboard gallery', 'Browse, open, and create self-service dashboards.'],
    query: ['Ad-hoc query', 'Explore data with a visual builder or SQL — results auto-route across engines.'],
    datasets: ['Datasets', 'Saved, governed query results reused across dashboards and reports.'],
    reports: ['Report subscription & distribution', 'Schedule and deliver reports to people and channels.'],
  };
  const [title, subtitle] = TITLES[sub];
  return (
    <div className="w-page">
      <PageHead crumb={['Self-Service Analytics', title].map((c) => tr(lang, c))} title={tr(lang, title)} sub={tr(lang, subtitle)} />
      <SubSwitch items={trList(lang, ANALYTICS_SUBS)} value={sub} onChange={setSub} />
      {sub === 'gallery' && <DashboardGallery onOpenEditor={() => setSub('editor')} />}
      {sub === 'query' && <AdHocQuery />}
      {sub === 'datasets' && <Datasets notify={notify} />}
      {sub === 'reports' && <ReportSubscriptions notify={notify} />}
    </div>
  );
}

Object.assign(window, { Analytics });
