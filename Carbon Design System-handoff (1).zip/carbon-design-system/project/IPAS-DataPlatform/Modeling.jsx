/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, StatusDot, ToolBtn, tr, trList */
const { Icon, Tag, Button, Search, TextInput, Dropdown } = window.CarbonDesignSystem_280d33;

const MODELING_CSS = `
.md-editor { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.md-body { display:flex; flex:1; min-height:0; }
.md-canvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.md-tablebox { position:absolute; width:200px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); }
.md-tablebox.fact { border:2px solid var(--cds-border-interactive); }
.md-tablebox.sel { box-shadow:0 0 0 2px var(--cds-border-interactive); }
.md-tablebox__h { display:flex; align-items:center; gap:8px; height:32px; padding:0 10px; background:var(--cds-gray-100); color:#fff; font-size:.75rem; font-weight:600; cursor:move; }
.md-tablebox.fact .md-tablebox__h { background:var(--cds-blue-60); }
.md-tablebox__row { display:flex; align-items:center; gap:8px; padding:5px 10px; font-size:.75rem; color:var(--cds-text-secondary); border-bottom:1px solid var(--wire-border); }
.md-tablebox__row:last-child { border-bottom:none; }
.md-tablebox__row .key { color:var(--cds-blue-60); }
.md-tablebox__row.pk { color:var(--cds-text-primary); font-weight:500; }
.md-side { width:300px; flex:0 0 300px; background:var(--cds-layer-02); border-left:1px solid var(--wire-border); display:flex; flex-direction:column; }
.md-side__h { height:40px; display:flex; align-items:center; padding:0 16px; font-size:.75rem; font-weight:600; border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.md-side__body { padding:16px; overflow:auto; flex:1; display:flex; flex-direction:column; gap:16px; }
.md-map { display:flex; flex-direction:column; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.md-map__row { background:var(--cds-layer-02); padding:8px 10px; display:flex; flex-direction:column; gap:2px; }
.md-map__row .phys { font-family:var(--cds-font-mono); font-size:.6875rem; color:var(--cds-text-secondary); }
.md-map__row .biz { font-size:.8125rem; color:var(--cds-text-primary); display:flex; align-items:center; gap:6px; }
.md-lineage { display:flex; align-items:center; gap:6px; font-size:.75rem; color:var(--cds-link-primary); cursor:pointer; }
.md-lineage:hover { text-decoration:underline; }
`;
(function(){ if (!document.getElementById('ipas-modeling-styles')) { const e=document.createElement('style'); e.id='ipas-modeling-styles'; e.textContent=MODELING_CSS; document.head.appendChild(e);} })();

const METRICS = [
  { id: 1, name: 'First-pass yield', def: 'Units passing QC on first attempt ÷ total units started', formula: '1 - (defects / units_started)', owner: 'L. Marsh', status: 'Certified', unit: '%' },
  { id: 2, name: 'Gross margin', def: 'Revenue minus COGS, as a share of revenue', formula: '(revenue - cogs) / revenue', owner: 'A. Okafor', status: 'Certified', unit: '%' },
  { id: 3, name: 'On-time delivery', def: 'Orders delivered by promised date ÷ total orders', formula: 'on_time_orders / total_orders', owner: 'R. Vance', status: 'Draft', unit: '%' },
  { id: 4, name: 'Mean cycle time', def: 'Average elapsed time per production run', formula: 'avg(end_ts - start_ts)', owner: 'L. Marsh', status: 'Certified', unit: 'min' },
  { id: 5, name: 'Scrap cost', def: 'Total cost of scrapped material per period', formula: 'sum(scrap_qty * unit_cost)', owner: 'M. Díaz', status: 'Review', unit: 'USD' },
  { id: 6, name: 'Net revenue retention', def: 'Recurring revenue retained + expansion ÷ starting', formula: '(start + expansion - churn) / start', owner: 'J. Singh', status: 'Draft', unit: '%' },
];

function MetricsStore({ notify }) {
  const [open, setOpen] = React.useState(false);
  const cols = [
    { key: 'name', label: 'Metric', cellClass: 'name' },
    { key: 'def', label: 'Business definition' },
    { key: 'formula', label: 'Formula', cellClass: 'mono' },
    { key: 'owner', label: 'Owner' },
    { key: 'status', label: 'Status' },
    { key: 'lineage', label: 'Lineage', sortable: false },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  return (
    <div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search metrics" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => setOpen(true)}>Define metric</Button></React.Fragment>} />
        <WireTable columns={cols} rows={METRICS} total={48}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => e.preventDefault()}>{r.name}</a>;
            if (k === 'def') return <span style={{ display: 'block', maxWidth: 280, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{r.def}</span>;
            if (k === 'status') return <Tag type={r.status === 'Certified' ? 'green' : r.status === 'Review' ? 'purple' : 'gray'} size="sm">{r.status}</Tag>;
            if (k === 'lineage') return <span className="md-lineage"><Icon name="data--base" size={16} />View</span>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Metrics store" title="Define metric" size="lg" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Metric submitted for review.' }); }}>Save metric</Button></React.Fragment>}>
          <div className="w-row">
            <TextInput label="Metric name" placeholder="First-pass yield" />
            <Dropdown label="Unit" items={['%', 'USD', 'min', 'count', 'ratio']} value="%" onChange={() => {}} />
          </div>
          <TextInput label="Caliber / business definition" placeholder="Plain-language definition of what this measures" helperText="Shown to every consumer of the metric." />
          <div className="w-fld">
            <label>Expression</label>
            <div style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', background: 'var(--cds-gray-100)', color: '#f4f4f4', padding: 12, minHeight: 72, whiteSpace: 'pre' }}>{'1 - (sum(defects) / sum(units_started))'}</div>
          </div>
          <div className="w-fld">
            <label>Dimensions</label>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {['plant', 'line_id', 'shift', 'product_sku', 'date'].map((d) => <Tag key={d} type="cool-gray" size="sm">{d}</Tag>)}
              <Tag type="outline" size="sm" icon="add">Add dimension</Tag>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

function TableBox({ id, x, y, fact, title, rows, sel, onSelect }) {
  return (
    <div className={`md-tablebox ${fact ? 'fact' : ''} ${sel ? 'sel' : ''}`} style={{ left: x, top: y }} onClick={() => onSelect(id)}>
      <div className="md-tablebox__h"><Icon name="data--base" size={16} />{title}</div>
      {rows.map((r, i) => (
        <div key={i} className={`md-tablebox__row ${r.pk ? 'pk' : ''}`}>
          {r.key && <Icon name="locked" size={16} className="key" />}{r.name}
          <span style={{ marginLeft: 'auto', fontFamily: 'var(--cds-font-mono)', fontSize: '.625rem', color: 'var(--cds-text-placeholder)' }}>{r.type}</span>
        </div>
      ))}
    </div>
  );
}

function SemanticModeler() {
  const [sel, setSel] = React.useState('fact');
  return (
    <div className="md-editor">
      <div className="w-etoolbar">
        <ToolBtn icon="save" label="Save model" />
        <span className="gap" />
        <ToolBtn icon="add" label="Add table" />
        <ToolBtn icon="share" label="Add join" />
        <span className="spacer" />
        <ToolBtn icon="zoom--out" label="" title="Zoom out" />
        <ToolBtn icon="zoom--in" label="" title="Zoom in" />
        <ToolBtn icon="view" label="Validate" />
      </div>
      <div className="md-body">
        <div className="md-canvas">
          <svg style={{ position: 'absolute', inset: 0, width: '100%', height: '100%', pointerEvents: 'none' }}>
            <g stroke="var(--cds-border-strong-01)" strokeWidth="1.5" fill="none">
              <path d="M 340 160 L 230 90" /><path d="M 340 180 L 230 300" />
              <path d="M 540 160 L 650 90" /><path d="M 540 200 L 650 320" />
            </g>
            <g fill="var(--cds-blue-60)"><circle cx="340" cy="160" r="4" /><circle cx="340" cy="180" r="4" /><circle cx="540" cy="160" r="4" /><circle cx="540" cy="200" r="4" /></g>
          </svg>
          <TableBox id="dim_product" x={40} y={40} title="dim_product" sel={sel === 'dim_product'} onSelect={setSel}
            rows={[{ name: 'product_key', key: true, pk: true, type: 'PK' }, { name: 'sku', type: 'str' }, { name: 'category', type: 'str' }]} />
          <TableBox id="dim_plant" x={40} y={280} title="dim_plant" sel={sel === 'dim_plant'} onSelect={setSel}
            rows={[{ name: 'plant_key', key: true, pk: true, type: 'PK' }, { name: 'region', type: 'str' }]} />
          <TableBox id="fact" x={340} y={120} fact title="fact_production" sel={sel === 'fact'} onSelect={setSel}
            rows={[{ name: 'product_key', key: true, type: 'FK' }, { name: 'plant_key', key: true, type: 'FK' }, { name: 'date_key', key: true, type: 'FK' }, { name: 'units_produced', type: 'num' }, { name: 'defect_count', type: 'num' }]} />
          <TableBox id="dim_date" x={650} y={40} title="dim_date" sel={sel === 'dim_date'} onSelect={setSel}
            rows={[{ name: 'date_key', key: true, pk: true, type: 'PK' }, { name: 'week', type: 'int' }, { name: 'quarter', type: 'str' }]} />
          <TableBox id="dim_shift" x={650} y={280} title="dim_shift" sel={sel === 'dim_shift'} onSelect={setSel}
            rows={[{ name: 'shift_key', key: true, pk: true, type: 'PK' }, { name: 'shift_name', type: 'str' }]} />
        </div>
        <aside className="md-side">
          <div className="md-side__h">fact_production · field mapping</div>
          <div className="md-side__body">
            <div className="w-fld"><label>Physical → business names</label>
              <div className="md-map">
                <div className="md-map__row"><span className="phys">units_produced</span><span className="biz">Units produced <Icon name="edit" size={16} style={{ color: 'var(--cds-icon-secondary)' }} /></span></div>
                <div className="md-map__row"><span className="phys">defect_count</span><span className="biz">Defects <Icon name="edit" size={16} style={{ color: 'var(--cds-icon-secondary)' }} /></span></div>
                <div className="md-map__row"><span className="phys">cycle_time_s</span><span className="biz">Cycle time (sec) <Icon name="edit" size={16} style={{ color: 'var(--cds-icon-secondary)' }} /></span></div>
              </div>
            </div>
            <div className="w-fld"><label>Hierarchies</label>
              <div style={{ fontSize: '.8125rem', color: 'var(--cds-text-primary)', border: '1px solid var(--wire-border)', padding: 10 }}>Plant → Line → Workstation</div>
            </div>
            <div className="w-fld"><label>Measures</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                <Tag type="blue" size="sm">SUM units</Tag><Tag type="blue" size="sm">AVG yield</Tag><Tag type="outline" size="sm" icon="add">Add</Tag>
              </div>
            </div>
            <div className="w-fld"><label>Field-level lineage</label>
              <span className="md-lineage"><Icon name="launch" size={16} />Open in DataHub</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

const MODELING_SUBS = [
  { id: 'metrics', label: 'Metrics store' },
  { id: 'semantic', label: 'Semantic model editor' },
];

function Modeling({ notify, lang }) {
  const [sub, setSub] = React.useState('metrics');
  if (sub === 'semantic') {
    return (
      <div className="w-page">
        <PageHead crumb={['Data Modeling & Semantics', 'Semantic model editor'].map((c) => tr(lang, c))} title={tr(lang, 'Semantic model editor')} sub={tr(lang, 'Model star schemas, map physical tables to business names, and link field lineage.')} />
        <SubSwitch items={trList(lang, MODELING_SUBS)} value={sub} onChange={setSub} />
        <SemanticModeler />
      </div>
    );
  }
  return (
    <div className="w-page">
      <PageHead crumb={['Data Modeling & Semantics', 'Metrics store'].map((c) => tr(lang, c))} title={tr(lang, 'Metrics store')} sub={tr(lang, 'A governed catalog of business metrics — definitions, formulas, and ownership.')} />
      <SubSwitch items={trList(lang, MODELING_SUBS)} value={sub} onChange={setSub} />
      <MetricsStore notify={notify} />
    </div>
  );
}

Object.assign(window, { Modeling });
