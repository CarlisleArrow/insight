/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, StatusDot, tr, trList */
const { Icon, Tag, Button, Search, Dropdown } = window.CarbonDesignSystem_280d33;

const ADMIN_TABS = [
  { id: 'users', label: 'Users & roles' },
  { id: 'orgs', label: 'Organizations' },
  { id: 'config', label: 'System config' },
  { id: 'audit', label: 'Audit log' },
  { id: 'api', label: 'API gateway' },
  { id: 'tenancy', label: 'Multi-tenancy' },
];

const ADMIN_DATA = {
  users: {
    create: 'Add user',
    cols: [
      { key: 'name', label: 'Name', cellClass: 'name' }, { key: 'email', label: 'Email', cellClass: 'mono' },
      { key: 'role', label: 'Role' }, { key: 'org', label: 'Organization' }, { key: 'status', label: 'Status' }, { key: 'ofw', label: '', sortable: false, width: 48 },
    ],
    rows: [
      { name: 'Lena Marsh', email: 'lmarsh@ipas', role: 'Admin', org: 'Manufacturing', status: 'Active' },
      { name: 'Ade Okafor', email: 'aokafor@ipas', role: 'Editor', org: 'Finance', status: 'Active' },
      { name: 'Ravi Vance', email: 'rvance@ipas', role: 'Steward', org: 'Logistics', status: 'Active' },
      { name: 'Mara Díaz', email: 'mdiaz@ipas', role: 'Viewer', org: 'Operations', status: 'Suspended' },
      { name: 'Jon Singh', email: 'jsingh@ipas', role: 'Editor', org: 'Growth', status: 'Invited' },
    ],
    cell: (r, k) => {
      if (k === 'role') return <Tag type="cool-gray" size="sm">{r.role}</Tag>;
      if (k === 'status') return <StatusDot kind={r.status === 'Active' ? 'active' : r.status === 'Suspended' ? 'failed' : 'gray'}>{r.status}</StatusDot>;
      if (k === 'ofw') return <Overflow />;
      return r[k];
    },
  },
  orgs: {
    create: 'Create organization',
    cols: [
      { key: 'org', label: 'Organization', cellClass: 'name' }, { key: 'members', label: 'Members' }, { key: 'projects', label: 'Projects' }, { key: 'owner', label: 'Owner' }, { key: 'ofw', label: '', sortable: false, width: 48 },
    ],
    rows: [
      { org: 'Manufacturing', members: '48', projects: '12', owner: 'L. Marsh' },
      { org: 'Finance', members: '22', projects: '7', owner: 'A. Okafor' },
      { org: 'Logistics', members: '31', projects: '9', owner: 'R. Vance' },
      { org: 'Operations', members: '18', projects: '5', owner: 'M. Díaz' },
    ],
    cell: (r, k) => k === 'ofw' ? <Overflow /> : r[k],
  },
  config: {
    create: 'New setting',
    cols: [
      { key: 'key', label: 'Setting', cellClass: 'mono' }, { key: 'val', label: 'Value', cellClass: 'mono' }, { key: 'scope', label: 'Scope' }, { key: 'by', label: 'Updated by' }, { key: 'ofw', label: '', sortable: false, width: 48 },
    ],
    rows: [
      { key: 'query.engine.default', val: 'auto', scope: 'Global', by: 'system' },
      { key: 'retention.bronze.days', val: '90', scope: 'Global', by: 'L. Marsh' },
      { key: 'sla.freshness.minutes', val: '30', scope: 'Manufacturing', by: 'L. Marsh' },
      { key: 'auth.session.ttl', val: '8h', scope: 'Global', by: 'system' },
      { key: 'masking.pii.default', val: 'full', scope: 'Global', by: 'R. Vance' },
    ],
    cell: (r, k) => k === 'ofw' ? <Overflow /> : k === 'scope' ? <Tag type="cool-gray" size="sm">{r.scope}</Tag> : r[k],
  },
  audit: {
    create: null,
    cols: [
      { key: 'time', label: 'Timestamp', cellClass: 'mono' }, { key: 'actor', label: 'Actor' }, { key: 'action', label: 'Action' }, { key: 'target', label: 'Target', cellClass: 'mono' }, { key: 'res', label: 'Result' },
    ],
    rows: [
      { time: '14:32:08', actor: 'L. Marsh', action: 'grant.role', target: 'analyst → aokafor', res: 'OK' },
      { time: '14:21:55', actor: 'system', action: 'pipeline.run', target: 'erp_to_gold', res: 'OK' },
      { time: '14:02:31', actor: 'R. Vance', action: 'policy.update', target: 'orders.row_filter', res: 'OK' },
      { time: '13:48:12', actor: 'aokafor', action: 'query.export', target: 'gold.fact_production', res: 'Denied' },
      { time: '13:30:00', actor: 'system', action: 'cdc.restart', target: 'crm-cdc', res: 'OK' },
    ],
    cell: (r, k) => k === 'res' ? <StatusDot kind={r.res === 'OK' ? 'success' : 'failed'}>{r.res}</StatusDot> : r[k],
  },
  api: {
    create: 'Create API key',
    cols: [
      { key: 'name', label: 'Key name', cellClass: 'name' }, { key: 'prefix', label: 'Key', cellClass: 'mono' }, { key: 'scope', label: 'Scopes' }, { key: 'rate', label: 'Rate limit' }, { key: 'status', label: 'Status' }, { key: 'ofw', label: '', sortable: false, width: 48 },
    ],
    rows: [
      { name: 'bi-readonly', prefix: 'ipas_sk_a91f…', scope: 'read:gold', rate: '600/min', status: 'Active' },
      { name: 'airflow-orchestrator', prefix: 'ipas_sk_77c2…', scope: 'write:pipelines', rate: '1200/min', status: 'Active' },
      { name: 'legacy-export', prefix: 'ipas_sk_0b34…', scope: 'read:silver', rate: '120/min', status: 'Revoked' },
    ],
    cell: (r, k) => {
      if (k === 'scope') return <Tag type="cool-gray" size="sm">{r.scope}</Tag>;
      if (k === 'status') return <StatusDot kind={r.status === 'Active' ? 'active' : 'gray'}>{r.status}</StatusDot>;
      if (k === 'ofw') return <Overflow />;
      return r[k];
    },
  },
  tenancy: {
    create: 'Add tenant',
    cols: [
      { key: 'tenant', label: 'Tenant', cellClass: 'name' }, { key: 'plan', label: 'Plan' }, { key: 'isolation', label: 'Isolation' }, { key: 'storage', label: 'Storage' }, { key: 'status', label: 'Status' }, { key: 'ofw', label: '', sortable: false, width: 48 },
    ],
    rows: [
      { tenant: 'acme-mfg', plan: 'Enterprise', isolation: 'Dedicated schema', storage: '4.2 TB', status: 'Active' },
      { tenant: 'globex-fin', plan: 'Enterprise', isolation: 'Dedicated schema', storage: '1.8 TB', status: 'Active' },
      { tenant: 'initech-logistics', plan: 'Standard', isolation: 'Shared (RLS)', storage: '640 GB', status: 'Active' },
      { tenant: 'umbrella-trial', plan: 'Trial', isolation: 'Shared (RLS)', storage: '12 GB', status: 'Provisioning' },
    ],
    cell: (r, k) => {
      if (k === 'plan') return <Tag type={r.plan === 'Enterprise' ? 'teal' : r.plan === 'Trial' ? 'cool-gray' : 'blue'} size="sm">{r.plan}</Tag>;
      if (k === 'status') return <StatusDot kind={r.status}>{r.status}</StatusDot>;
      if (k === 'ofw') return <Overflow />;
      return r[k];
    },
  },
};

function Admin({ lang }) {
  const [tab, setTab] = React.useState('users');
  const d = ADMIN_DATA[tab];
  const label = ADMIN_TABS.find((t) => t.id === tab).label;
  return (
    <div className="w-page">
      <PageHead crumb={['Platform Admin', label].map((c) => tr(lang, c))} title={tr(lang, 'Platform administration')} sub={tr(lang, 'Manage people, organizations, configuration, and platform-wide controls.')} />
      <SubSwitch items={trList(lang, ADMIN_TABS)} value={tab} onChange={setTab} />
      <div className="w-tblwrap">
        <TableToolbar placeholder={`Search ${label.toLowerCase()}`} search="" onSearch={() => {}}
          actions={<React.Fragment>
            <Button kind="ghost" size="lg" icon="filter" iconOnly />
            {tab === 'audit' && <Button kind="ghost" size="lg" icon="download" iconOnly />}
            {d.create && <Button kind="primary" size="lg" icon="add">{d.create}</Button>}
          </React.Fragment>} />
        <WireTable columns={d.cols} rows={d.rows} total={tab === 'audit' ? 4821 : d.rows.length} renderCell={d.cell} />
      </div>
    </div>
  );
}

Object.assign(window, { Admin });
