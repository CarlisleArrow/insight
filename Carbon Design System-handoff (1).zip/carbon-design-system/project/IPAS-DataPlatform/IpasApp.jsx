/* global React, IpSideNav, Welcome, IpOverview, Profile, Analytics, Modeling, DevConfig, Governance, Monitoring, Admin, NotificationsPanel, SEED_NOTIFS, tr */
const { InlineNotification } = window.CarbonDesignSystem_280d33;

const IPAS_APP_CSS = `
.ip-toaststack { position:fixed; top:16px; right:16px; z-index:80; width:360px; display:flex; flex-direction:column; gap:8px; }
`;
(function(){ if (!document.getElementById('ipas-app-styles')) { const e=document.createElement('style'); e.id='ipas-app-styles'; e.textContent=IPAS_APP_CSS; document.head.appendChild(e);} })();

function IpasApp() {
  const [nav, setNav] = React.useState(null);
  const [profileTab, setProfileTab] = React.useState(null); // when set, render Profile
  const [collapsed, setCollapsed] = React.useState(false);
  const [lang, setLang] = React.useState('en');
  const [toasts, setToasts] = React.useState([]);
  const [notifs, setNotifs] = React.useState(SEED_NOTIFS);
  const [notifOpen, setNotifOpen] = React.useState(false);

  const notify = React.useCallback((t) => {
    const id = Math.random().toString(36).slice(2);
    setToasts((ts) => [...ts, { ...t, id }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 4500);
  }, []);

  // live pipeline toast demo — a run completes shortly after first load
  React.useEffect(() => {
    const t = setTimeout(() => notify({ kind: 'success', title: 'Pipeline qms-cdc completed', subtitle: 'Loaded 3 layers in 2m 41s.' }), 6000);
    return () => clearTimeout(t);
  }, [notify]);

  const unread = notifs.filter((n) => n.unread).length;
  const markRead = (id) => setNotifs((ns) => ns.map((n) => n.id === id ? { ...n, unread: false } : n));
  const markAll = () => setNotifs((ns) => ns.map((n) => ({ ...n, unread: false })));
  const actRequest = (id, decision) => {
    setNotifs((ns) => ns.filter((n) => n.id !== id));
    notify({ kind: decision === 'approve' ? 'success' : 'info', title: decision === 'approve' ? 'Access approved' : 'Access denied', subtitle: 'Ade Okafor · Analyst role' });
  };

  const goProfile = (tab) => { setProfileTab(tab); setNav('__profile'); };
  const selectNav = (id) => { setProfileTab(null); setNav(id); };

  const SECTIONS = {
    overview: IpOverview,
    analytics: Analytics,
    modeling: Modeling,
    devconfig: DevConfig,
    governance: Governance,
    monitoring: Monitoring,
    admin: Admin,
  };

  let content;
  if (nav === '__profile') content = <Profile key="profile" tab={profileTab} lang={lang} notify={notify} onNavigate={selectNav} />;
  else if (nav && SECTIONS[nav]) { const S = SECTIONS[nav]; content = <S key={nav} notify={notify} lang={lang} onNavigate={selectNav} />; }
  else content = <Welcome onNavigate={selectNav} lang={lang} />;

  return (
    <div className="ip-shell">
      <IpSideNav current={nav} onSelect={selectNav} collapsed={collapsed} onToggle={() => setCollapsed((c) => !c)}
        onHome={() => selectNav(null)} lang={lang} onLang={setLang}
        unread={unread} onNotifications={() => setNotifOpen(true)} onProfile={goProfile}
        onAppearance={() => notify({ kind: 'info', title: tr(lang, 'Appearance'), subtitle: 'Light / Dark / High-contrast — set in Preferences.' })} />
      <main className="ip-main">{content}</main>

      {notifOpen && (
        <NotificationsPanel lang={lang} notifs={notifs} onClose={() => setNotifOpen(false)}
          onMarkAll={markAll} onAct={actRequest} onRead={markRead} />
      )}

      {toasts.length > 0 && (
        <div className="ip-toaststack">
          {toasts.map((t) => (
            <InlineNotification key={t.id} kind={t.kind} title={t.title} subtitle={t.subtitle}
              onClose={() => setToasts((ts) => ts.filter((x) => x.id !== t.id))} />
          ))}
        </div>
      )}
    </div>
  );
}

Object.assign(window, { IpasApp });
