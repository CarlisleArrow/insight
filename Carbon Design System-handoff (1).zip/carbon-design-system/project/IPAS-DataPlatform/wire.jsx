/* global React */
const { Icon, Tag, Button, Search, TextInput, Dropdown, Checkbox, Toggle, Tabs, Tile, InlineNotification } =
  window.CarbonDesignSystem_280d33;

/* ============================================================
   IPAS Data Platform — shared wireframe primitives
   Carbon language: square corners, 1px borders, flat surfaces,
   IBM Plex, blue #0f62fe interactive, structure-first wireframe.
   ============================================================ */
const WIRE_CSS = `
:root { --wire-border: #e0e0e0; }
.w-page { padding: 24px 32px 80px; }
.w-page--flush { padding: 0; }
.w-crumb { font-size: .75rem; color: var(--cds-text-secondary); margin-bottom: 12px; letter-spacing:.32px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.w-crumb a { color: var(--cds-link-primary); text-decoration: none; }
.w-crumb a:hover { text-decoration: underline; }
.w-crumb .sep { color: var(--cds-text-placeholder); }
.w-head { display:flex; align-items:flex-end; justify-content:space-between; gap:24px; margin-bottom:20px; }
.w-head h1 { font-size: 1.75rem; font-weight: 400; line-height: 1.25; margin:0; color: var(--cds-text-primary); }
.w-head p { margin: 6px 0 0; font-size: .875rem; color: var(--cds-text-secondary); max-width: 64ch; }
.w-head .acts { display:flex; gap:1px; flex:0 0 auto; }

/* sub-page switcher (content switcher) */
.w-switch { display:inline-flex; border:1px solid var(--cds-border-strong-01); margin-bottom:24px; max-width:100%; overflow:auto; }
.w-switch button { appearance:none; border:none; background:var(--cds-layer-02); color:var(--cds-text-secondary);
  font-family:var(--cds-font-sans); font-size:.875rem; padding:0 16px; height:40px; cursor:pointer; white-space:nowrap;
  border-right:1px solid var(--cds-border-strong-01); }
.w-switch button:last-child { border-right:none; }
.w-switch button:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.w-switch button.active { background:var(--cds-gray-100); color:#fff; }

/* generic data table */
.w-tblwrap { background: var(--cds-layer-02); border:1px solid var(--wire-border); }
.w-toolbar { display:flex; align-items:stretch; height:48px; border-bottom:1px solid var(--wire-border); }
.w-toolbar .grow { flex:1; display:flex; align-items:center; min-width:0; }
.w-toolbar .grow .cds--search__input { background:var(--cds-layer-02); height:48px; }
.w-toolbar .chips { display:flex; align-items:center; gap:8px; padding:0 12px; flex-wrap:nowrap; overflow:hidden; }
.w-tbl { width:100%; border-collapse:collapse; font-family:var(--cds-font-sans); }
.w-tbl th { text-align:left; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); background:var(--cds-layer-01);
  height:40px; padding:0 16px; white-space:nowrap; border-bottom:1px solid var(--wire-border); letter-spacing:.16px; }
.w-tbl th .sort { display:inline-flex; align-items:center; gap:4px; cursor:pointer; }
.w-tbl th .sort:hover { color:var(--cds-link-primary); }
.w-tbl td { font-size:.875rem; color:var(--cds-text-secondary); height:48px; padding:0 16px; border-bottom:1px solid var(--wire-border); vertical-align:middle; }
.w-tbl tr:last-child td { border-bottom:none; }
.w-tbl tbody tr { cursor:default; }
.w-tbl tbody tr.click { cursor:pointer; }
.w-tbl tbody tr:hover td { background:var(--cds-layer-hover-01); }
.w-tbl td.name { color:var(--cds-text-primary); font-weight:500; }
.w-tbl td.name a { color:var(--cds-link-primary); text-decoration:none; }
.w-tbl td.name a:hover { text-decoration:underline; }
.w-tbl td.mono { font-family:var(--cds-font-mono); font-size:.8125rem; color:var(--cds-text-secondary); }
.w-tbl .ofw { width:48px; text-align:center; }
.w-ofw-btn { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-ofw-btn:hover { background:var(--cds-layer-hover-01); }
.w-tblfoot { display:flex; align-items:center; justify-content:space-between; height:40px; padding:0 16px; border-top:1px solid var(--wire-border); font-size:.75rem; color:var(--cds-text-secondary); background:var(--cds-layer-02); }
.w-tblfoot .pg { display:flex; align-items:center; gap:2px; }
.w-pgbtn { width:28px; height:28px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-pgbtn:hover { background:var(--cds-layer-hover-01); }
.w-pgbtn.on { background:var(--cds-gray-100); color:#fff; }

/* status dot+label */
.w-status { display:inline-flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-primary); }
.w-status .dot { width:8px; height:8px; border-radius:50%; flex:0 0 auto; }

/* modal */
.w-scrim { position:fixed; inset:0; background:var(--cds-overlay); z-index:60; display:flex; align-items:flex-start; justify-content:center; padding:64px 16px; overflow:auto; }
.w-modal { background:var(--cds-layer-02); width:640px; max-width:100%; box-shadow:var(--cds-shadow-modal); display:flex; flex-direction:column; }
.w-modal--sm { width:480px; }
.w-modal--lg { width:840px; }
.w-modal__head { padding:20px 24px 8px; }
.w-modal__head .sup { font-size:.75rem; color:var(--cds-text-secondary); letter-spacing:.32px; }
.w-modal__head h2 { font-size:1.25rem; font-weight:400; margin:4px 0 0; color:var(--cds-text-primary); }
.w-modal__head .x { position:absolute; top:0; right:0; width:48px; height:48px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-modal__head .x:hover { background:var(--cds-layer-hover-01); }
.w-modal__wrap { position:relative; }
.w-modal__body { padding:16px 24px 32px; display:flex; flex-direction:column; gap:20px; max-height:60vh; overflow:auto; }
.w-modal__foot { display:flex; }
.w-modal__foot > * { flex:1; }

/* right slide-over panel */
.w-panel { position:fixed; top:0; right:0; bottom:0; background:var(--cds-layer-02); z-index:55; box-shadow:var(--cds-shadow-modal); display:flex; flex-direction:column; }
.w-panel__head { padding:20px 24px; border-bottom:1px solid var(--wire-border); position:relative; }
.w-panel__head .sup { font-size:.75rem; color:var(--cds-text-secondary); letter-spacing:.32px; }
.w-panel__head h2 { font-size:1.125rem; font-weight:600; margin:4px 0 0; color:var(--cds-text-primary); }
.w-panel__head .x { position:absolute; top:12px; right:12px; width:40px; height:40px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-panel__head .x:hover { background:var(--cds-layer-hover-01); }
.w-panel__body { padding:20px 24px; display:flex; flex-direction:column; gap:20px; flex:1; overflow:auto; }
.w-panel__foot { display:flex; }
.w-panel__foot > * { flex:1; }

/* field group helpers */
.w-fld { display:flex; flex-direction:column; gap:6px; }
.w-fld > label { font-size:.75rem; color:var(--cds-text-secondary); }
.w-row { display:flex; gap:16px; }
.w-row > * { flex:1; }

/* chart / image placeholders */
.w-ph { position:relative; background:
    repeating-linear-gradient(135deg, var(--cds-layer-01) 0 10px, var(--cds-layer-02) 10px 20px);
  border:1px solid var(--wire-border); display:flex; align-items:center; justify-content:center; color:var(--cds-text-helper); }
.w-ph .lbl { font-family:var(--cds-font-mono); font-size:.6875rem; letter-spacing:.32px; color:var(--cds-text-secondary);
  background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:4px 10px; display:inline-flex; align-items:center; gap:8px; }

/* mini bar chart (real, lightweight) */
.w-bars { display:flex; align-items:flex-end; gap:8px; width:100%; }
.w-bars .b { flex:1; background:var(--cds-blue-60); min-height:4px; }
.w-bars .b:nth-child(even){ background:var(--cds-blue-40); }

/* skeleton */
@keyframes wshimmer { 0%{opacity:.5} 50%{opacity:1} 100%{opacity:.5} }
.w-sk { background:var(--cds-layer-01); animation:wshimmer 1.2s ease-in-out infinite; }
.w-sk-line { height:12px; margin:8px 0; }

/* empty state */
.w-empty { border:1px dashed var(--cds-border-strong-01); background:var(--cds-layer-02); padding:48px 24px; text-align:center; color:var(--cds-text-secondary); }
.w-empty .ic { color:var(--cds-icon-secondary); margin-bottom:12px; display:flex; justify-content:center; }
.w-empty h3 { font-size:1rem; font-weight:600; color:var(--cds-text-primary); margin:0 0 6px; }
.w-empty p { font-size:.875rem; margin:0 0 20px; }

/* draggable affordance */
.w-grip { display:inline-grid; grid-template-columns:repeat(2,3px); gap:2px; cursor:grab; flex:0 0 auto; }
.w-grip i { width:3px; height:3px; background:var(--cds-icon-secondary); }
.w-chip { display:flex; align-items:center; gap:8px; padding:6px 10px; background:var(--cds-layer-02); border:1px solid var(--wire-border); font-size:.8125rem; color:var(--cds-text-primary); cursor:grab; }
.w-chip:hover { border-color:var(--cds-border-interactive); background:var(--cds-layer-hover-01); }
.w-chip .t { color:var(--cds-text-secondary); font-size:.6875rem; font-family:var(--cds-font-mono); margin-left:auto; }

/* generic card grid */
.w-grid { display:grid; gap:16px; }

/* panel / column shells for 3-pane editors */
.w-shellrow { display:flex; min-height: calc(100vh - 48px - 0px); }
.w-col { background:var(--cds-layer-02); border-right:1px solid var(--wire-border); display:flex; flex-direction:column; min-height:100%; }
.w-col__h { display:flex; align-items:center; gap:8px; height:40px; padding:0 12px 0 16px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; color:var(--cds-text-primary); letter-spacing:.16px; }
.w-col__h .collapse { margin-left:auto; width:28px; height:28px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.w-col__h .collapse:hover { background:var(--cds-layer-hover-01); }
.w-col__body { padding:12px; overflow:auto; flex:1; }
.w-section-label { font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); margin:8px 4px; }

/* tree */
.w-tree { font-size:.8125rem; }
.w-treeitem { display:flex; align-items:center; gap:6px; padding:5px 4px; color:var(--cds-text-primary); cursor:pointer; }
.w-treeitem:hover { background:var(--cds-layer-hover-01); }
.w-treeitem.indent { padding-left:24px; color:var(--cds-text-secondary); cursor:grab; }
.w-treeitem.indent:hover { color:var(--cds-text-primary); }

/* toolbar above editor canvases */
.w-etoolbar { display:flex; align-items:center; gap:1px; height:48px; padding:0 8px; background:var(--cds-layer-02); border-bottom:1px solid var(--wire-border); }
.w-etoolbar .gap { width:1px; height:24px; background:var(--wire-border); margin:0 8px; }
.w-etoolbar .spacer { flex:1; }
.w-iconbtn { height:32px; min-width:32px; padding:0 8px; display:inline-flex; align-items:center; gap:6px; border:none; background:transparent; color:var(--cds-text-primary); font-family:var(--cds-font-sans); font-size:.8125rem; cursor:pointer; }
.w-iconbtn:hover { background:var(--cds-layer-hover-01); }

/* canvas */
.w-canvas { flex:1; position:relative; overflow:auto; background:
    linear-gradient(var(--cds-layer-01) 1px, transparent 1px) 0 0 / 100% 24px,
    linear-gradient(90deg, var(--cds-layer-01) 1px, transparent 1px) 0 0 / 24px 100%,
    var(--cds-layer-02); }

/* engine indicator */
.w-engine { position:absolute; right:16px; bottom:16px; display:flex; align-items:center; gap:8px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:var(--cds-shadow-overlay,0 2px 6px rgba(0,0,0,.12)); padding:8px 12px; font-size:.75rem; color:var(--cds-text-secondary); }
.w-engine b { color:var(--cds-text-primary); font-weight:600; }

/* stat tiles */
.w-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.w-stats .s { background:var(--cds-layer-02); padding:20px; }
.w-stats .s .k { font-size:.75rem; letter-spacing:.16px; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.w-stats .s .v { font-size:2.25rem; font-weight:300; line-height:1.1; margin-top:10px; color:var(--cds-text-primary); }
.w-stats .s .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:6px; }

/* multi-step wizard stepper */
.w-stepper { display:flex; gap:0; margin-bottom:24px; border:1px solid var(--wire-border); }
.w-step { flex:1; display:flex; align-items:center; gap:10px; padding:12px 16px; border-right:1px solid var(--wire-border); background:var(--cds-layer-02); cursor:pointer; min-width:0; }
.w-step:last-child { border-right:none; }
.w-step .n { width:24px; height:24px; flex:0 0 24px; border-radius:50%; border:1px solid var(--cds-border-strong-01); display:flex; align-items:center; justify-content:center; font-size:.75rem; color:var(--cds-text-secondary); background:var(--cds-layer-02); }
.w-step .tx { min-width:0; } .w-step .tx .t { font-size:.8125rem; font-weight:500; color:var(--cds-text-secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.w-step .tx .s { font-size:.6875rem; color:var(--cds-text-placeholder); }
.w-step.active { background:var(--cds-layer-01); }
.w-step.active .n { border-color:var(--cds-border-interactive); color:#fff; background:var(--cds-blue-60); }
.w-step.active .tx .t { color:var(--cds-text-primary); }
.w-step.done .n { border-color:var(--cds-support-success); color:#fff; background:var(--cds-support-success); }
.w-step.done .tx .t { color:var(--cds-text-primary); }

/* visual condition builder */
.w-cond { border:1px solid var(--wire-border); background:var(--cds-layer-02); padding:12px; }
.w-cond__grp { border-left:2px solid var(--cds-border-interactive); padding:8px 0 8px 12px; margin-bottom:8px; display:flex; flex-direction:column; gap:8px; }
.w-cond__row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.w-cond__row .x { width:32px; height:32px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.w-cond__row .x:hover { background:var(--cds-layer-hover-01); }
.w-cond__join { display:inline-flex; align-items:center; gap:6px; align-self:flex-start; }
.w-cond__pill { font-size:.6875rem; font-weight:600; letter-spacing:.16px; padding:2px 8px; background:var(--cds-blue-60); color:#fff; }
.w-cond__sql { font-family:var(--cds-font-mono); font-size:.75rem; background:var(--cds-gray-100); color:#f4f4f4; padding:10px 12px; margin-top:8px; white-space:pre-wrap; }

/* floating menu / popover */
.w-menu { position:fixed; z-index:90; min-width:240px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:var(--cds-shadow-overlay,0 4px 16px rgba(0,0,0,.2)); display:flex; flex-direction:column; }
.w-menu__hd { padding:14px 16px; border-bottom:1px solid var(--wire-border); }
.w-menu__hd .nm { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.w-menu__hd .sub { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; font-family:var(--cds-font-mono); }
.w-menu__hd .badges { display:flex; gap:6px; margin-top:8px; flex-wrap:wrap; }
.w-menu__item { display:flex; align-items:center; gap:12px; padding:0 16px; height:40px; font-size:.875rem; color:var(--cds-text-primary); background:transparent; border:none; width:100%; text-align:left; cursor:pointer; }
.w-menu__item:hover { background:var(--cds-layer-hover-01); }
.w-menu__item .mr { margin-left:auto; font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:6px; }
.w-menu__sep { height:1px; background:var(--wire-border); margin:4px 0; }
.w-menu__lbl { font-size:.6875rem; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); padding:10px 16px 4px; }
.w-menu__scrim { position:fixed; inset:0; z-index:89; }

/* notification items */
.w-notif { display:flex; gap:12px; padding:14px 16px; border-bottom:1px solid var(--wire-border); position:relative; cursor:pointer; }
.w-notif:hover { background:var(--cds-layer-hover-01); }
.w-notif.unread { background:var(--cds-layer-01); }
.w-notif.unread:hover { background:var(--cds-layer-hover-01); }
.w-notif__ic { width:32px; height:32px; flex:0 0 32px; display:flex; align-items:center; justify-content:center; }
.w-notif__bd { flex:1; min-width:0; }
.w-notif__bd .t { font-size:.8125rem; font-weight:600; color:var(--cds-text-primary); }
.w-notif__bd .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; line-height:1.4; }
.w-notif__bd .ts { font-size:.6875rem; color:var(--cds-text-placeholder); margin-top:6px; }
.w-notif__bd .req { display:flex; gap:8px; margin-top:10px; }
.w-notif__dot { position:absolute; top:18px; right:14px; width:8px; height:8px; border-radius:50%; background:var(--cds-blue-60); }
.w-notif__tabs { display:flex; border-bottom:1px solid var(--wire-border); }
.w-notif__tabs button { flex:1; height:44px; border:none; background:transparent; font-family:var(--cds-font-sans); font-size:.8125rem; color:var(--cds-text-secondary); cursor:pointer; border-bottom:2px solid transparent; }
.w-notif__tabs button.on { color:var(--cds-text-primary); font-weight:600; border-bottom-color:var(--cds-border-interactive); }

/* simple key-value descriptive list */
.w-dl { display:grid; grid-template-columns:160px 1fr; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.w-dl dt, .w-dl dd { background:var(--cds-layer-02); margin:0; padding:10px 14px; font-size:.8125rem; }
.w-dl dt { color:var(--cds-text-secondary); } .w-dl dd { color:var(--cds-text-primary); font-weight:500; }

/* segmented matrix checkbox grid */
.w-permgrid { width:100%; border-collapse:collapse; border:1px solid var(--wire-border); font-size:.8125rem; }
.w-permgrid th, .w-permgrid td { border:1px solid var(--wire-border); padding:8px 12px; text-align:center; }
.w-permgrid th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.w-permgrid td:first-child, .w-permgrid th:first-child { text-align:left; color:var(--cds-text-primary); font-weight:500; }
.w-permgrid input { accent-color:var(--cds-blue-60); width:16px; height:16px; }
`;

function injectWire() {
  if (typeof document === 'undefined' || document.getElementById('ipas-wire-styles')) return;
  const el = document.createElement('style'); el.id = 'ipas-wire-styles'; el.textContent = WIRE_CSS;
  document.head.appendChild(el);
}
injectWire();

/* ---- status mapping ---- */
const STATUS_DOT = {
  green: 'var(--cds-support-success)', running: 'var(--cds-support-success)', connected: 'var(--cds-support-success)',
  success: 'var(--cds-support-success)', active: 'var(--cds-support-success)', healthy: 'var(--cds-support-success)',
  amber: 'var(--cds-support-warning)', warning: 'var(--cds-support-warning)', retrying: 'var(--cds-support-warning)',
  degraded: 'var(--cds-support-warning)', paused: 'var(--cds-support-warning)',
  red: 'var(--cds-support-error)', error: 'var(--cds-support-error)', failed: 'var(--cds-support-error)',
  blue: 'var(--cds-blue-60)', provisioning: 'var(--cds-blue-60)', syncing: 'var(--cds-blue-60)', running2: 'var(--cds-blue-60)',
  gray: 'var(--cds-text-placeholder)', stopped: 'var(--cds-text-placeholder)', draft: 'var(--cds-text-placeholder)', inactive: 'var(--cds-text-placeholder)',
};
function StatusDot({ kind, children }) {
  const color = STATUS_DOT[(kind || 'gray').toLowerCase()] || STATUS_DOT.gray;
  return (
    <span className="w-status"><span className="dot" style={{ background: color }} />{children}</span>
  );
}

/* ---- page header ---- */
function PageHead({ crumb, title, sub, actions }) {
  return (
    <React.Fragment>
      {crumb && (
        <div className="w-crumb">
          {crumb.map((c, i) => (
            <React.Fragment key={i}>
              {i > 0 && <span className="sep">/</span>}
              {i < crumb.length - 1 ? <a href="#" onClick={(e) => e.preventDefault()}>{c}</a> : <span>{c}</span>}
            </React.Fragment>
          ))}
        </div>
      )}
      <div className="w-head">
        <div><h1>{title}</h1>{sub && <p>{sub}</p>}</div>
        {actions && <div className="acts">{actions}</div>}
      </div>
    </React.Fragment>
  );
}

/* ---- sub-page content switcher ---- */
function SubSwitch({ items, value, onChange }) {
  return (
    <div className="w-switch" role="tablist">
      {items.map((it) => (
        <button key={it.id} role="tab" className={value === it.id ? 'active' : ''} onClick={() => onChange(it.id)}>
          {it.label}
        </button>
      ))}
    </div>
  );
}

/* ---- generic data table ---- */
function WireTable({ columns, rows, renderCell, onRowClick, sortKey, footer = true, total }) {
  return (
    <div className="w-tblwrap">
      <table className="w-tbl">
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c.key} style={c.width ? { width: c.width } : null}>
                {c.sortable === false ? c.label : (
                  <span className="sort">{c.label}<Icon name={sortKey === c.key ? 'chevron--down' : 'chevron--sort'} size={16} /></span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((r, ri) => (
            <tr key={r.id || ri} className={onRowClick ? 'click' : ''} onClick={onRowClick ? () => onRowClick(r) : null}>
              {columns.map((c) => (
                <td key={c.key} className={c.cellClass || ''}>{renderCell(r, c.key)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
      {footer && (
        <div className="w-tblfoot">
          <span>{(total != null ? total : rows.length)} items</span>
          <div className="pg">
            <button className="w-pgbtn on">1</button>
            <button className="w-pgbtn">2</button>
            <button className="w-pgbtn">3</button>
            <button className="w-pgbtn" aria-label="Next page"><Icon name="chevron--right" size={16} /></button>
          </div>
        </div>
      )}
    </div>
  );
}

/* ---- table toolbar ---- */
function TableToolbar({ search, onSearch, placeholder, chips, actions }) {
  return (
    <div className="w-toolbar">
      <div className="grow"><Search value={search} onChange={onSearch} size="lg" placeholder={placeholder || 'Search'} /></div>
      {chips && <div className="chips">{chips}</div>}
      {actions}
    </div>
  );
}

/* ---- overflow menu (visual) ---- */
function Overflow() {
  return <button className="w-ofw-btn" aria-label="Row actions" onClick={(e) => e.stopPropagation()}><Icon name="overflow-menu--vertical" size={16} /></button>;
}

/* ---- modal ---- */
function Modal({ title, sup, size, onClose, children, footer }) {
  return (
    <div className="w-scrim" onClick={onClose}>
      <div className={`w-modal ${size === 'sm' ? 'w-modal--sm' : size === 'lg' ? 'w-modal--lg' : ''}`} onClick={(e) => e.stopPropagation()}>
        <div className="w-modal__wrap">
          <div className="w-modal__head">
            {sup && <div className="sup">{sup}</div>}
            <h2>{title}</h2>
            <button className="x" aria-label="Close" onClick={onClose}><Icon name="close" size={20} /></button>
          </div>
        </div>
        <div className="w-modal__body">{children}</div>
        {footer && <div className="w-modal__foot">{footer}</div>}
      </div>
    </div>
  );
}

/* ---- right slide-over ---- */
function SidePanel({ title, sup, width = 420, onClose, children, footer }) {
  return (
    <React.Fragment>
      <div className="w-scrim" style={{ display: 'block', padding: 0 }} onClick={onClose} />
      <aside className="w-panel" style={{ width }}>
        <div className="w-panel__head">
          {sup && <div className="sup">{sup}</div>}
          <h2>{title}</h2>
          <button className="x" aria-label="Close" onClick={onClose}><Icon name="close" size={20} /></button>
        </div>
        <div className="w-panel__body">{children}</div>
        {footer && <div className="w-panel__foot">{footer}</div>}
      </aside>
    </React.Fragment>
  );
}

/* ---- chart / image placeholder ---- */
function Placeholder({ label, height = 160, icon = 'chart--bar', style }) {
  return (
    <div className="w-ph" style={{ height, ...style }}>
      <span className="lbl"><Icon name={icon} size={14} />{label}</span>
    </div>
  );
}

/* ---- lightweight real bar chart ---- */
function BarChart({ data, height = 140 }) {
  const max = Math.max(...data);
  return <div className="w-bars" style={{ height }}>{data.map((d, i) => <div key={i} className="b" style={{ height: (d / max * 100) + '%' }} />)}</div>;
}

/* ---- skeleton block ---- */
function Skeleton({ rows = 3, width = '100%' }) {
  return <div>{Array.from({ length: rows }).map((_, i) => <div key={i} className="w-sk w-sk-line" style={{ width: i === rows - 1 ? '60%' : width }} />)}</div>;
}

/* ---- empty state ---- */
function EmptyState({ icon = 'document', title, sub, action }) {
  return (
    <div className="w-empty">
      <div className="ic"><Icon name={icon} size={32} /></div>
      <h3>{title}</h3>
      {sub && <p>{sub}</p>}
      {action}
    </div>
  );
}

/* ---- draggable field chip ---- */
function FieldChip({ children, kind }) {
  return (
    <div className="w-chip" draggable>
      <span className="w-grip"><i /><i /><i /><i /><i /><i /></span>
      {children}
      {kind && <span className="t">{kind}</span>}
    </div>
  );
}

/* ---- editor toolbar button ---- */
function ToolBtn({ icon, label, onClick, title }) {
  return <button className="w-iconbtn" onClick={onClick} title={title || label} aria-label={title || label}>{icon && <Icon name={icon} size={16} />}{label}</button>;
}

/* ---- multi-step wizard stepper ---- */
function Stepper({ steps, current, onStep }) {
  return (
    <div className="w-stepper">
      {steps.map((s, i) => (
        <div key={i} className={`w-step ${i === current ? 'active' : ''} ${i < current ? 'done' : ''}`} onClick={() => onStep && onStep(i)}>
          <span className="n">{i < current ? <Icon name="checkmark" size={14} /> : i + 1}</span>
          <span className="tx"><span className="t">{s.t}</span>{s.s && <span className="s">{s.s}</span>}</span>
        </div>
      ))}
    </div>
  );
}

/* ---- visual condition builder (field / op / value, AND-OR) ---- */
function ConditionBuilder({ fields = ['process_id', 'region', 'plant', 'shift'], ops = ['=', '≠', 'IN', 'NOT IN', '>', '<', 'LIKE'], initial, sql }) {
  const [rows, setRows] = React.useState(initial || [
    { field: 'process_id', op: 'IN', value: "'P1','P2'" },
  ]);
  const [join, setJoin] = React.useState('AND');
  const update = (i, key, v) => setRows((rs) => rs.map((r, j) => j === i ? { ...r, [key]: v } : r));
  const generated = sql || ('WHERE ' + rows.map((r) => `${r.field} ${r.op} (${r.value})`).join(`\n  ${join} `));
  return (
    <div className="w-cond">
      <div className="w-cond__grp">
        {rows.map((r, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="w-cond__join"><span className="w-cond__pill" onClick={() => setJoin(join === 'AND' ? 'OR' : 'AND')} style={{ cursor: 'pointer' }}>{join}</span></span>}
            <div className="w-cond__row">
              <Dropdown items={fields} value={r.field} onChange={(v) => update(i, 'field', v)} size="sm" style={{ width: 160 }} />
              <Dropdown items={ops} value={r.op} onChange={(v) => update(i, 'op', v)} size="sm" style={{ width: 110 }} />
              <TextInput size="sm" value={r.value} onChange={(e) => update(i, 'value', e.target ? e.target.value : e)} style={{ width: 180 }} />
              <button className="x" aria-label="Remove condition" onClick={() => setRows((rs) => rs.filter((_, j) => j !== i))}><Icon name="subtract" size={16} /></button>
            </div>
          </React.Fragment>
        ))}
      </div>
      <Button kind="ghost" size="sm" icon="add" onClick={() => setRows((rs) => [...rs, { field: fields[0], op: '=', value: '' }])}>Add condition</Button>
      <div className="w-cond__sql">{generated}</div>
    </div>
  );
}

/* ---- floating anchored menu / popover ---- */
function Menu({ anchorRect, onClose, width = 256, side = 'right', children }) {
  const ref = React.useRef(null);
  const [pos, setPos] = React.useState({ left: -9999, top: -9999 });
  React.useLayoutEffect(() => {
    const el = ref.current; if (!el || !anchorRect) return;
    const h = el.offsetHeight, w = el.offsetWidth;
    let top = anchorRect.top - h;
    if (top < 8) top = Math.min(anchorRect.bottom + 4, window.innerHeight - h - 8);
    let left = side === 'right' ? anchorRect.right + 8 : anchorRect.left;
    if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
    if (left < 8) left = 8;
    setPos({ left, top });
  }, [anchorRect]);
  return (
    <React.Fragment>
      <div className="w-menu__scrim" onClick={onClose} />
      <div className="w-menu" ref={ref} style={{ left: pos.left, top: pos.top, width }}>{children}</div>
    </React.Fragment>
  );
}
function MenuItem({ icon, children, meta, onClick }) {
  return <button className="w-menu__item" onClick={onClick}>{icon && <Icon name={icon} size={16} />}{children}{meta && <span className="mr">{meta}</span>}</button>;
}

/* ---- i18n: English → 简体中文 dictionary (chrome, welcome, section headers) ---- */
const IPAS_ZH = {
  // nav + chrome
  'Home / Overview': '首页 / 概览',
  'Self-Service Analytics': '自助分析',
  'Data Modeling & Semantics': '数据建模与语义',
  'Data Development / Config': '数据开发 / 配置',
  'Data Assets & Governance': '数据资产与治理',
  'Monitoring & Ops': '监控与运维',
  'Platform Admin': '平台管理',
  'Search platform': '搜索平台',
  'Data Engineer': '数据工程师',
  'Notifications': '通知',
  'Help': '帮助',
  'Help & resources': '帮助与资源',
  'Documentation': '文档',
  'Keyboard shortcuts': '键盘快捷键',
  "What's new": '更新日志',
  'Support': '技术支持',
  'My profile': '我的资料',
  'Preferences': '偏好设置',
  'My permissions': '我的权限',
  'API keys': 'API 密钥',
  'Switch organization': '切换组织',
  'Appearance': '外观',
  'Light': '浅色',
  'Language': '语言',
  'Sign out': '退出登录',
  'Mark all as read': '全部标为已读',
  'Settings': '设置',
  'Nothing here.': '暂无内容。',
  'Approve': '批准',
  'Deny': '拒绝',
  'All': '全部',
  'Unread': '未读',
  'Mentions': '提及我的',
  // overview
  'Healthy pipelines': '健康管道',
  'Failed (24h)': '失败（24h）',
  'Catalog assets': '目录资产',
  'Open alerts': '未处理告警',
  'New pipeline': '新建管道',
  'Ingest a source to a layer': '将数据源接入分层',
  'New dashboard': '新建仪表板',
  'Build on the canvas': '在画布上构建',
  'Run a query': '运行查询',
  'Visual builder or SQL': '可视化构建或 SQL',
  'Recent pipelines': '近期管道',
  'View all': '查看全部',
  'Pending access requests': '待处理访问申请',
  'My dashboards': '我的仪表板',
  'Pipeline': '管道',
  'Status': '状态',
  'Duration': '时长',
  'Started': '开始时间',
  // profile
  'Personal center': '个人中心',
  'Your profile, preferences, permissions, and security.': '你的资料、偏好、权限与安全。',
  'Notification settings': '通知设置',
  'Security & sessions': '安全与会话',
  'Identity fields are managed in corporate IAM (read-only).': '身份字段由企业 IAM 统一管理（只读）。',
  'Full name': '姓名',
  'Department': '部门',
  'Identity source': '身份来源',
  'Member since': '加入时间',
  'Roles': '角色',
  'Choose how the platform looks.': '选择平台的外观主题。',
  'Dark': '深色',
  'High contrast': '高对比',
  'Localization & defaults': '本地化与默认值',
  'Timezone': '时区',
  'Default landing page': '默认首页',
  'Default query engine': '默认查询引擎',
  'Table page size': '表格分页大小',
  'Date format': '日期格式',
  'Save preferences': '保存偏好',
  'Preferences saved.': '偏好已保存。',
  'Notification channels': '通知渠道',
  'Pick how you are notified for each event type.': '为每类事件选择通知方式。',
  'Event': '事件',
  'In-app': '应用内',
  'Pipeline success': '管道成功',
  'Pipeline failure': '管道失败',
  'Quality alert': '质量告警',
  'SLA breach': 'SLA 违约',
  'Access request': '访问申请',
  'Announcements': '公告',
  'Daily digest instead of per-event email': '每日汇总替代逐条邮件',
  'Mute 22:00–07:00': '静默 22:00–07:00',
  'Save settings': '保存设置',
  'Notification settings saved.': '通知设置已保存。',
  'Effective access — computed from your roles & policies': '有效访问权限 —— 由角色与策略计算得出',
  'My roles': '我的角色',
  'Search assets I can access': '搜索我可访问的资产',
  'Request access': '申请访问',
  'Asset': '资产',
  'Access': '访问',
  'Masking applied': '已应用脱敏',
  'Create API key': '创建 API 密钥',
  'Search keys': '搜索密钥',
  'Name': '名称',
  'Token': '令牌',
  'Scopes': '范围',
  'Last used': '最近使用',
  'Personal access token': '个人访问令牌',
  'Copy this token now — it will not be shown again.': '请立即复制令牌 —— 之后将不再显示。',
  'Copy': '复制',
  'Token copied.': '令牌已复制。',
  'Key name': '密钥名称',
  'Scope': '范围',
  'Expiry': '有效期',
  'Generate token': '生成令牌',
  'Cancel': '取消',
  'Done': '完成',
  'Active sessions': '活动会话',
  'Your password is managed in corporate SSO (Keycloak).': '密码由企业 SSO（Keycloak）统一管理。',
  'This device': '当前设备',
  'Session signed out.': '会话已退出。',
  'Sign out all other sessions': '退出所有其他会话',
  'Signed out of all other sessions.': '已退出所有其他会话。',
  // welcome
  'What do you want to do today?': '今天想做些什么？',
  'Welcome to SiPTORY InSight': '欢迎使用 SiPTORY InSight',
  'Build a dashboard': '创建仪表板',
  'Compose charts on a drag-and-drop canvas.': '在拖拽画布上组合图表。',
  'Define a metric': '定义指标',
  'Add a governed metric to the metrics store.': '向指标中心添加受治理的指标。',
  'Browse the catalog': '浏览数据目录',
  'Search every table and field across layers.': '检索各分层的表与字段。',
  'Check operations': '查看运维',
  'Monitor pipeline runs and data SLAs.': '监控管道运行与数据 SLA。',
  // analytics
  'Dashboard gallery': '仪表板库',
  'Dashboard editor': '仪表板编辑器',
  'Ad-hoc query': '即席查询',
  'Report subscriptions': '报表订阅',
  'Datasets': '数据集',
  'Saved, governed query results reused across dashboards and reports.': '可在仪表板与报表间复用的受治理查询结果。',
  'Browse, open, and create self-service dashboards.': '浏览、打开并创建自助仪表板。',
  'Explore data with a visual builder or SQL — results auto-route across engines.': '用可视化构建器或 SQL 探索数据 —— 结果在引擎间自动路由。',
  'Report subscription & distribution': '报表订阅与分发',
  'Schedule and deliver reports to people and channels.': '按计划将报表分发给人员与渠道。',
  // modeling
  'Metrics store': '指标中心',
  'Semantic model editor': '语义模型编辑器',
  'A governed catalog of business metrics — definitions, formulas, and ownership.': '受治理的业务指标目录 —— 定义、公式与归属。',
  'Model star schemas, map physical tables to business names, and link field lineage.': '建模星型架构，将物理表映射为业务字段，并关联字段血缘。',
  // devconfig
  'Pipelines': '数据管道',
  'Unified ingest-to-serve data pipelines across all layers.': '贯穿各分层的端到端数据管道。',
  'Data sources': '数据源',
  'ETL / DAG': 'ETL / DAG',
  'CDC / sync': 'CDC / 同步',
  'Data quality': '数据质量',
  'Data source management': '数据源管理',
  'Registered database, lakehouse, and streaming connections.': '已注册的数据库、湖仓与流式连接。',
  'ETL pipeline orchestration': 'ETL 管道编排',
  'Layered RAW → Bronze → Silver → Gold → ClickHouse DAG.': '分层 RAW → Bronze → Silver → Gold → ClickHouse 的 DAG。',
  'CDC / sync configuration': 'CDC / 同步配置',
  'Debezium change-data-capture connectors and watermarks.': 'Debezium 变更数据捕获连接器与水位。',
  'Data quality rules': '数据质量规则',
  'Assertions on tables and fields with severity and alerting.': '针对表与字段的断言，含严重级别与告警。',
  // governance
  'Data catalog': '数据目录',
  'Lineage graph': '血缘图谱',
  'Access control': '访问控制',
  'Search and explore every table and field across the platform.': '检索并浏览平台中的每一张表与字段。',
  'Trace data flow RAW → Bronze → Silver → Gold → ClickHouse, down to field level.': '追踪数据流转 RAW → Bronze → Silver → Gold → ClickHouse，细化到字段级。',
  'Manage users, roles, and row/column-level policies (RBAC / ABAC).': '管理用户、角色与行/列级策略（RBAC / ABAC）。',
  'Data classification': '数据分级',
  'Sensitivity levels, compliance tags, and auto-classification rules.': '敏感级别、合规标签与自动分级规则。',
  // monitoring
  'Task monitoring': '任务监控',
  'Resource & SLA': '资源与 SLA',
  'Live ETL run status with logs and failure recovery.': '实时 ETL 运行状态，含日志与失败恢复。',
  'Resource & SLA monitoring': '资源与 SLA 监控',
  'Cluster, Spark, and ClickHouse health plus per-pipeline data SLAs.': '集群、Spark 与 ClickHouse 健康度及各管道数据 SLA。',
  'Alerts': '告警',
  'Logs': '日志',
  'Log explorer': '日志浏览器',
  'Threshold and condition-based alert rules with severity and routing.': '基于阈值与条件的告警规则，含严重级别与路由。',
  'Search platform logs across services, levels, and time ranges.': '跨服务、级别与时间范围检索平台日志。',
  // admin
  'Users & roles': '用户与角色',
  'Organizations': '组织',
  'System config': '系统配置',
  'Audit log': '审计日志',
  'API gateway': 'API 网关',
  'Multi-tenancy': '多租户',
  'Platform administration': '平台管理',
  'Manage people, organizations, configuration, and platform-wide controls.': '管理人员、组织、配置及平台级控制。',
};
function tr(lang, s) { return lang === 'zh' ? (IPAS_ZH[s] || s) : s; }
function trList(lang, items) { return items.map((it) => ({ ...it, label: tr(lang, it.label) })); }

Object.assign(window, {
  PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, SidePanel,
  Placeholder, BarChart, Skeleton, EmptyState, FieldChip, StatusDot, ToolBtn,
  Stepper, ConditionBuilder, Menu, MenuItem,
  tr, trList,
});
