/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, StatusDot, ToolBtn, Stepper, tr, trList */
const { Icon, Tag, Button, Search, TextInput, Dropdown, Toggle, Checkbox, Tabs } = window.CarbonDesignSystem_280d33;

const DEV_CSS = `
.dv-dag { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.dv-runstrip { display:flex; align-items:center; gap:10px; padding:8px 12px; border-bottom:1px solid var(--wire-border); background:var(--cds-layer-01); font-size:.75rem; color:var(--cds-text-secondary); }
.dv-runstrip .bars { display:flex; gap:2px; }
.dv-runstrip .bars i { width:8px; height:20px; }
.dv-dagbody { display:flex; flex:1; min-height:0; }
.dv-canvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.dv-layer-labels { display:flex; position:absolute; top:0; left:0; right:0; pointer-events:none; }
.dv-layer-labels .ll { width:170px; padding:8px 0; text-align:center; font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-helper); border-right:1px dashed var(--wire-border); }
.dv-node { position:absolute; width:140px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); cursor:pointer; }
.dv-node.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.dv-node__h { display:flex; align-items:center; gap:6px; padding:8px 10px; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); }
.dv-node__h .st { margin-left:auto; width:8px; height:8px; border-radius:50%; }
.dv-node__m { padding:0 10px 8px; font-size:.625rem; font-family:var(--cds-font-mono); color:var(--cds-text-secondary); }
.dv-side { width:300px; flex:0 0 300px; background:var(--cds-layer-02); border-left:1px solid var(--wire-border); display:flex; flex-direction:column; }
.dv-side__h { height:40px; display:flex; align-items:center; padding:0 16px; font-size:.75rem; font-weight:600; border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.dv-side__body { padding:16px; overflow:auto; flex:1; display:flex; flex-direction:column; gap:16px; }
.dv-kv { display:flex; flex-direction:column; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.dv-kv__r { display:flex; justify-content:space-between; gap:12px; background:var(--cds-layer-02); padding:8px 10px; font-size:.75rem; }
.dv-kv__r .k { color:var(--cds-text-secondary); } .dv-kv__r .v { color:var(--cds-text-primary); font-weight:500; font-family:var(--cds-font-mono); }
.dv-lag { display:inline-flex; align-items:center; gap:6px; font-family:var(--cds-font-mono); font-size:.75rem; }
`;
(function(){ if (!document.getElementById('ipas-dev-styles')) { const e=document.createElement('style'); e.id='ipas-dev-styles'; e.textContent=DEV_CSS; document.head.appendChild(e);} })();

const SOURCES = [
  { id: 1, name: 'erp-oracle-prod', type: 'Oracle', host: 'erp-db.ipas.internal:1521', status: 'Connected', tested: '2 min ago' },
  { id: 2, name: 'mes-mysql', type: 'MySQL', host: 'mes.ipas.internal:3306', status: 'Connected', tested: '5 min ago' },
  { id: 3, name: 'crm-sqlserver', type: 'SQL Server', host: 'crm-sql.ipas.internal:1433', status: 'Error', tested: '1 hour ago' },
  { id: 4, name: 'lake-iceberg', type: 'Iceberg', host: 's3://ipas-lakehouse/warehouse', status: 'Connected', tested: '12 min ago' },
  { id: 5, name: 'analytics-clickhouse', type: 'ClickHouse', host: 'ch.ipas.internal:8123', status: 'Connected', tested: '1 min ago' },
  { id: 6, name: 'events-kafka', type: 'Kafka', host: 'kafka-0.ipas.internal:9092', status: 'Degraded', tested: '8 min ago' },
];

function DataSources({ notify }) {
  const [open, setOpen] = React.useState(false);
  const [tested, setTested] = React.useState(false);
  const cols = [
    { key: 'name', label: 'Connection', cellClass: 'name' },
    { key: 'type', label: 'Type' },
    { key: 'host', label: 'Host', cellClass: 'mono' },
    { key: 'status', label: 'Status' },
    { key: 'tested', label: 'Last tested' },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  return (
    <div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search connections" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => { setOpen(true); setTested(false); }}>Add data source</Button></React.Fragment>} />
        <WireTable columns={cols} rows={SOURCES}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => e.preventDefault()}>{r.name}</a>;
            if (k === 'type') return <Tag type="cool-gray" size="sm">{r.type}</Tag>;
            if (k === 'status') return <StatusDot kind={r.status}>{r.status}</StatusDot>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Connections" title="Add data source" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Data source added.' }); }}>Add source</Button></React.Fragment>}>
          <div className="w-row">
            <Dropdown label="Type" items={['Oracle', 'MySQL', 'SQL Server', 'Iceberg', 'ClickHouse', 'Kafka']} value="Oracle" onChange={() => {}} />
            <TextInput label="Connection name" placeholder="erp-oracle-prod" />
          </div>
          <div className="w-row">
            <TextInput label="Host" placeholder="db.ipas.internal" />
            <TextInput label="Port" defaultValue="1521" />
          </div>
          <div className="w-row">
            <TextInput label="Database / service" placeholder="ORCLPDB1" />
            <TextInput label="Username" placeholder="svc_ipas" />
          </div>
          <TextInput label="Password" type="password" defaultValue="••••••••••" />
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Button kind="tertiary" size="md" icon="renew" onClick={() => { setTested(true); }}>Test connection</Button>
            {tested && <StatusDot kind="connected">Connection successful · 38ms</StatusDot>}
          </div>
        </Modal>
      )}
    </div>
  );
}

/* ---- ETL DAG ---- */
const DAG_LAYERS = ['RAW', 'Bronze', 'Silver', 'Gold', 'ClickHouse'];
const DAG_NODES = [
  { id: 'n1', layer: 0, y: 60, label: 'ingest_erp', status: 'success', sub: 'extract · 2m' },
  { id: 'n2', layer: 0, y: 220, label: 'ingest_mes', status: 'success', sub: 'extract · 1m' },
  { id: 'n3', layer: 1, y: 60, label: 'clean_erp', status: 'success', sub: 'dbt · 3m' },
  { id: 'n4', layer: 1, y: 220, label: 'clean_mes', status: 'running', sub: 'dbt · running' },
  { id: 'n5', layer: 2, y: 140, label: 'conform_dims', status: 'success', sub: 'spark · 4m' },
  { id: 'n6', layer: 3, y: 60, label: 'fact_production', status: 'queued', sub: 'dbt · queued' },
  { id: 'n7', layer: 3, y: 220, label: 'agg_yield', status: 'queued', sub: 'dbt · queued' },
  { id: 'n8', layer: 4, y: 140, label: 'load_ch', status: 'queued', sub: 'sync · queued' },
];
const DAG_EDGES = [['n1', 'n3'], ['n2', 'n4'], ['n3', 'n5'], ['n4', 'n5'], ['n5', 'n6'], ['n5', 'n7'], ['n6', 'n8'], ['n7', 'n8']];
const DAG_STATUS_COLOR = { success: 'var(--cds-support-success)', running: 'var(--cds-blue-60)', queued: 'var(--cds-text-placeholder)', failed: 'var(--cds-support-error)' };
const COLW = 170, NODEX = (l) => l * COLW + 15, NODEW = 140;

function EtlDag() {
  const [sel, setSel] = React.useState('n6');
  const pos = {}; DAG_NODES.forEach((n) => { pos[n.id] = { x: NODEX(n.layer), y: n.y, cx: NODEX(n.layer) + NODEW, cy: n.y + 26 }; });
  const sn = DAG_NODES.find((n) => n.id === sel);
  return (
    <div className="dv-dag">
      <div className="w-etoolbar">
        <Button kind="primary" size="sm" icon="play" style={{ marginRight: 4 }}>Run</Button>
        <ToolBtn icon="pause" label="Pause" />
        <ToolBtn icon="renew" label="Backfill" />
        <span className="gap" />
        <ToolBtn icon="time" label="Schedule: 0 */2 * * *" />
        <span className="spacer" />
        <ToolBtn icon="zoom--out" label="" title="Zoom out" />
        <ToolBtn icon="zoom--in" label="" title="Zoom in" />
      </div>
      <div className="dv-runstrip">
        <span>Recent runs</span>
        <div className="bars">
          {['success','success','failed','success','success','success','running'].map((s, i) => <i key={i} style={{ background: DAG_STATUS_COLOR[s] }} title={s} />)}
        </div>
        <span style={{ marginLeft: 'auto' }}>Last run 14m ago · avg 11m · success rate 92%</span>
      </div>
      <div className="dv-dagbody">
        <div className="dv-canvas">
          <div className="dv-layer-labels">{DAG_LAYERS.map((l) => <div key={l} className="ll">{l}</div>)}</div>
          <svg style={{ position: 'absolute', inset: 0, width: '100%', height: 460, pointerEvents: 'none' }}>
            <defs><marker id="arr" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="var(--cds-border-strong-01)" /></marker></defs>
            {DAG_EDGES.map(([a, b], i) => {
              const p = pos[a], q = pos[b];
              const mx = (p.cx + q.x) / 2;
              return <path key={i} d={`M ${p.cx} ${p.cy} C ${mx} ${p.cy}, ${mx} ${q.y + 26}, ${q.x} ${q.y + 26}`} stroke="var(--cds-border-strong-01)" strokeWidth="1.5" fill="none" markerEnd="url(#arr)" />;
            })}
          </svg>
          {DAG_NODES.map((n) => (
            <div key={n.id} className={`dv-node ${sel === n.id ? 'sel' : ''}`} style={{ left: pos[n.id].x, top: n.y }} onClick={() => setSel(n.id)}>
              <div className="dv-node__h"><Icon name="data--base" size={16} />{n.label}<span className="st" style={{ background: DAG_STATUS_COLOR[n.status] }} /></div>
              <div className="dv-node__m">{n.sub}</div>
            </div>
          ))}
        </div>
        <aside className="dv-side">
          <div className="dv-side__h">Task · {sn.label}</div>
          <div className="dv-side__body">
            <StatusDot kind={sn.status}>{sn.status[0].toUpperCase() + sn.status.slice(1)}</StatusDot>
            <div className="w-fld"><label>Parameters</label>
              <div className="dv-kv">
                <div className="dv-kv__r"><span className="k">operator</span><span className="v">dbt_run</span></div>
                <div className="dv-kv__r"><span className="k">model</span><span className="v">{sn.label}</span></div>
                <div className="dv-kv__r"><span className="k">pool</span><span className="v">transform</span></div>
              </div>
            </div>
            <Dropdown label="Schedule" items={['Inherit from DAG', '0 */2 * * *', '@daily']} value="Inherit from DAG" onChange={() => {}} />
            <div className="w-row">
              <TextInput label="Retries" defaultValue="3" />
              <TextInput label="Retry delay" defaultValue="5m" />
            </div>
            <div className="w-fld"><label>Upstream dependencies</label>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}><Tag type="cool-gray" size="sm">conform_dims</Tag></div>
            </div>
            <Button kind="tertiary" size="sm" icon="document">View logs (ELK)</Button>
          </div>
        </aside>
      </div>
    </div>
  );
}

/* ---- CDC ---- */
const CONNECTORS = [
  { id: 1, name: 'erp-cdc', src: 'erp-oracle-prod', topic: 'cdc.erp.', status: 'Running', lag: '120 ms', lagKind: 'green' },
  { id: 2, name: 'mes-cdc', src: 'mes-mysql', topic: 'cdc.mes.', status: 'Running', lag: '1.4 s', lagKind: 'amber' },
  { id: 3, name: 'crm-cdc', src: 'crm-sqlserver', topic: 'cdc.crm.', status: 'Failed', lag: '— ', lagKind: 'red' },
  { id: 4, name: 'inventory-cdc', src: 'erp-oracle-prod', topic: 'cdc.inv.', status: 'Running', lag: '85 ms', lagKind: 'green' },
];
function Cdc() {
  const [sel, setSel] = React.useState(CONNECTORS[0]);
  const cols = [
    { key: 'name', label: 'Connector', cellClass: 'name' },
    { key: 'src', label: 'Source DB' },
    { key: 'topic', label: 'Topic prefix', cellClass: 'mono' },
    { key: 'status', label: 'Status' },
    { key: 'lag', label: 'Watermark lag' },
  ];
  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 16, alignItems: 'start' }}>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search connectors" search="" onSearch={() => {}}
          actions={<Button kind="primary" size="lg" icon="add">New connector</Button>} />
        <WireTable columns={cols} rows={CONNECTORS} footer={false} onRowClick={setSel}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => e.preventDefault()}>{r.name}</a>;
            if (k === 'status') return <StatusDot kind={r.status}>{r.status}</StatusDot>;
            if (k === 'lag') return <span className="dv-lag"><span style={{ width: 8, height: 8, borderRadius: '50%', background: `var(--cds-support-${r.lagKind === 'green' ? 'success' : r.lagKind === 'amber' ? 'warning' : 'error'})` }} />{r.lag}</span>;
            return r[k];
          }} />
      </div>
      <div className="w-tblwrap" style={{ padding: 0 }}>
        <div className="dv-side__h" style={{ borderBottom: '1px solid var(--wire-border)' }}>Connector · {sel.name}</div>
        <div style={{ padding: 16, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <StatusDot kind={sel.status}>{sel.status} · Debezium 2.5</StatusDot>
          <div className="w-fld"><label>Tables synced (4)</label>
            <div className="dv-kv">
              {['ORDERS', 'ORDER_LINES', 'CUSTOMERS', 'SHIPMENTS'].map((t) => <div key={t} className="dv-kv__r"><span className="k">{t}</span><span className="v">snapshot ✓</span></div>)}
            </div>
          </div>
          <div className="w-fld"><label>Schema-change retention</label><Dropdown items={['7 days', '30 days', '90 days']} value="30 days" onChange={() => {}} /></div>
          <Toggle size="sm" label="Auto-evolve downstream schema" defaultChecked />
        </div>
      </div>
    </div>
  );
}

/* ---- Data Quality ---- */
const DQ_RULES = [
  { id: 1, target: 'gold.fact_production.yield_pct', type: 'Range (0–1)', sev: 'High', result: 'Pass', n: '0 failed' },
  { id: 2, target: 'silver.orders.order_id', type: 'Uniqueness', sev: 'High', result: 'Pass', n: '0 failed' },
  { id: 3, target: 'silver.orders.customer_id', type: 'Not null', sev: 'High', result: 'Fail', n: '142 failed' },
  { id: 4, target: 'gold.dim_product.sku', type: 'Not null', sev: 'Medium', result: 'Pass', n: '0 failed' },
  { id: 5, target: 'silver.shipments.delivered_at', type: 'Custom assertion', sev: 'Low', result: 'Warn', n: '8 stale' },
];
function DataQuality({ notify }) {
  const [open, setOpen] = React.useState(false);
  const cols = [
    { key: 'target', label: 'Target table / field', cellClass: 'mono' },
    { key: 'type', label: 'Rule type' },
    { key: 'sev', label: 'Severity' },
    { key: 'result', label: 'Last result' },
    { key: 'n', label: 'Rows' },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  return (
    <div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search rules" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => setOpen(true)}>Add rule</Button></React.Fragment>} />
        <WireTable columns={cols} rows={DQ_RULES}
          renderCell={(r, k) => {
            if (k === 'sev') return <Tag type={r.sev === 'High' ? 'red' : r.sev === 'Medium' ? 'purple' : 'cool-gray'} size="sm">{r.sev}</Tag>;
            if (k === 'result') return <StatusDot kind={r.result === 'Pass' ? 'success' : r.result === 'Fail' ? 'failed' : 'warning'}>{r.result}</StatusDot>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {open && (
        <Modal sup="Data quality" title="Add rule" onClose={() => setOpen(false)}
          footer={<React.Fragment><Button kind="secondary" onClick={() => setOpen(false)}>Cancel</Button><Button kind="primary" icon="checkmark" onClick={() => { setOpen(false); notify && notify({ kind: 'success', title: 'Rule added and scheduled.' }); }}>Add rule</Button></React.Fragment>}>
          <div className="w-row">
            <Dropdown label="Target table" items={['gold.fact_production', 'silver.orders', 'gold.dim_product']} value="gold.fact_production" onChange={() => {}} />
            <Dropdown label="Field" items={['yield_pct', 'units_produced', 'defect_count']} value="yield_pct" onChange={() => {}} />
          </div>
          <div className="w-row">
            <Dropdown label="Rule type" items={['Not null', 'Range', 'Uniqueness', 'Custom assertion']} value="Range" onChange={() => {}} />
            <Dropdown label="Severity" items={['High', 'Medium', 'Low']} value="High" onChange={() => {}} />
          </div>
          <div className="w-fld"><label>Assertion (SQL)</label>
            <div style={{ fontFamily: 'var(--cds-font-mono)', fontSize: '.8125rem', background: 'var(--cds-gray-100)', color: '#f4f4f4', padding: 12, minHeight: 56, whiteSpace: 'pre' }}>{'yield_pct BETWEEN 0 AND 1'}</div>
          </div>
          <div className="w-fld"><label>Alert</label>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
              <Checkbox label="Notify #data-quality on failure" defaultChecked />
              <Checkbox label="Block downstream pipeline on High severity" defaultChecked />
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}

const PIPELINES = [
  { id: 1, name: 'erp_to_gold', source: 'erp-oracle-prod', target: 'Gold', schedule: '0 */2 * * *', last: 'Success', next: 'in 1h 12m', owner: 'L. Marsh' },
  { id: 2, name: 'mes_stream', source: 'events-kafka', target: 'Silver', schedule: 'streaming', last: 'Running', next: '—', owner: 'M. Díaz' },
  { id: 3, name: 'crm_sync', source: 'crm-sqlserver', target: 'Bronze', schedule: '*/15 * * * *', last: 'Failed', next: 'in 4m', owner: 'A. Okafor' },
  { id: 4, name: 'finance_daily', source: 'erp-oracle-prod', target: 'Gold', schedule: '0 6 * * *', last: 'Success', next: 'in 18h', owner: 'A. Okafor' },
  { id: 5, name: 'logistics_etl', source: 'mes-mysql', target: 'Gold', schedule: '0 */4 * * *', last: 'Success', next: 'in 2h', owner: 'R. Vance' },
];
const WIZ_STEPS = [
  { t: 'Source', s: 'Connection' }, { t: 'Tables', s: 'Select' }, { t: 'Target', s: 'Layer & format' },
  { t: 'Schedule', s: 'Cron / interval' }, { t: 'Transform', s: 'CDC / batch' }, { t: 'Review', s: 'Create' },
];

function PipelineWizard({ onClose, notify }) {
  const [step, setStep] = React.useState(0);
  const last = step === WIZ_STEPS.length - 1;
  return (
    <Modal sup="Pipelines" title="Create pipeline" size="lg" onClose={onClose}
      footer={<React.Fragment>
        <Button kind="secondary" onClick={step === 0 ? onClose : () => setStep(step - 1)}>{step === 0 ? 'Cancel' : 'Back'}</Button>
        <Button kind="primary" icon={last ? 'checkmark' : 'arrow--right'} onClick={last ? () => { onClose(); notify && notify({ kind: 'success', title: 'Pipeline created.', subtitle: 'First run scheduled.' }); } : () => setStep(step + 1)}>{last ? 'Create pipeline' : 'Next'}</Button>
      </React.Fragment>}>
      <Stepper steps={WIZ_STEPS} current={step} onStep={setStep} />
      {step === 0 && <React.Fragment>
        <Dropdown label="Source connection" items={['erp-oracle-prod', 'mes-mysql', 'crm-sqlserver', 'events-kafka']} value="erp-oracle-prod" onChange={() => {}} />
        <TextInput label="Pipeline name" placeholder="erp_to_gold" />
      </React.Fragment>}
      {step === 1 && <div className="w-fld"><label>Tables to ingest</label><div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
        {['ORDERS', 'ORDER_LINES', 'CUSTOMERS', 'SHIPMENTS', 'PRODUCTS'].map((tb, i) => <Checkbox key={tb} label={tb} defaultChecked={i < 3} />)}
      </div></div>}
      {step === 2 && <React.Fragment>
        <div className="w-row"><Dropdown label="Target layer" items={['RAW', 'Bronze', 'Silver', 'Gold']} value="Gold" onChange={() => {}} /><Dropdown label="Format" items={['Iceberg', 'Delta', 'Parquet']} value="Iceberg" onChange={() => {}} /></div>
        <TextInput label="Target namespace" defaultValue="gold.manufacturing" />
      </React.Fragment>}
      {step === 3 && <React.Fragment>
        <Dropdown label="Trigger" items={['Cron schedule', 'Fixed interval', 'On source change (CDC)']} value="Cron schedule" onChange={() => {}} />
        <TextInput label="Cron expression" defaultValue="0 */2 * * *" helperText="Every 2 hours." />
      </React.Fragment>}
      {step === 4 && <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        <Dropdown label="Load mode" items={['CDC (incremental)', 'Full batch', 'Append only']} value="CDC (incremental)" onChange={() => {}} />
        <Checkbox label="Deduplicate on primary key" defaultChecked />
        <Checkbox label="Run data quality rules after load" defaultChecked />
      </div>}
      {step === 5 && <div className="dv-kv">
        <div className="dv-kv__r"><span className="k">Name</span><span className="v">erp_to_gold</span></div>
        <div className="dv-kv__r"><span className="k">Source</span><span className="v">erp-oracle-prod</span></div>
        <div className="dv-kv__r"><span className="k">Tables</span><span className="v">3 selected</span></div>
        <div className="dv-kv__r"><span className="k">Target</span><span className="v">gold.manufacturing · Iceberg</span></div>
        <div className="dv-kv__r"><span className="k">Schedule</span><span className="v">0 */2 * * *</span></div>
        <div className="dv-kv__r"><span className="k">Mode</span><span className="v">CDC (incremental)</span></div>
      </div>}
    </Modal>
  );
}

function PipelineDetail({ pipe, onBack, notify }) {
  return (
    <div>
      <Button kind="ghost" size="sm" icon="arrow--left" onClick={onBack} style={{ marginBottom: 12 }}>Back to pipelines</Button>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 16, marginBottom: 20, flexWrap: 'wrap' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <h1 style={{ fontSize: '1.5rem', fontWeight: 400, margin: 0, fontFamily: 'var(--cds-font-mono)' }}>{pipe.name}</h1>
            <StatusDot kind={pipe.last}>{pipe.last}</StatusDot>
          </div>
          <p style={{ color: 'var(--cds-text-secondary)', fontSize: '.875rem', margin: '8px 0 0' }}>{pipe.source} → {pipe.target} · {pipe.schedule} · owner {pipe.owner}</p>
        </div>
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 1 }}>
          <Button kind="primary" size="md" icon="play" onClick={() => notify && notify({ kind: 'success', title: 'Run started.', subtitle: pipe.name })}>Run now</Button>
          <Button kind="tertiary" size="md" icon="pause">Pause</Button>
          <Button kind="tertiary" size="md" icon="calendar">Backfill</Button>
          <Button kind="tertiary" size="md" icon="stop">Stop</Button>
        </div>
      </div>
      <Tabs tabs={[
        { label: 'Overview', content: <div style={{ marginTop: 8 }}>
          <div className="dv-kv" style={{ maxWidth: 520 }}>
            <div className="dv-kv__r"><span className="k">Status</span><span className="v">{pipe.last}</span></div>
            <div className="dv-kv__r"><span className="k">Next run</span><span className="v">{pipe.next}</span></div>
            <div className="dv-kv__r"><span className="k">Avg duration</span><span className="v">11m 04s</span></div>
            <div className="dv-kv__r"><span className="k">Success rate (30d)</span><span className="v">92%</span></div>
          </div>
        </div> },
        { label: 'DAG', content: <div style={{ marginTop: 8 }}><EtlDag /></div> },
        { label: 'Run history', content: <div style={{ marginTop: 8 }} className="w-tblwrap">
          <WireTable footer={false}
            columns={[{ key: 'start', label: 'Started' }, { key: 'dur', label: 'Duration' }, { key: 'status', label: 'Status' }, { key: 'by', label: 'Triggered by' }, { key: 'act', label: '', sortable: false, width: 48 }]}
            rows={[
              { start: 'Today 14:32', dur: '11m 04s', status: 'Success', by: 'schedule' },
              { start: 'Today 12:30', dur: '10m 51s', status: 'Success', by: 'schedule' },
              { start: 'Today 10:30', dur: '1m 02s', status: 'Failed', by: 'schedule' },
              { start: 'Today 08:30', dur: '12m 18s', status: 'Success', by: 'L. Marsh' },
            ]}
            renderCell={(r, k) => k === 'status' ? <StatusDot kind={r.status}>{r.status}</StatusDot> : k === 'act' ? <Overflow /> : r[k]} />
        </div> },
        { label: 'Config', content: <div style={{ marginTop: 8, maxWidth: 520, display: 'flex', flexDirection: 'column', gap: 16 }}>
          <TextInput label="Schedule (cron)" defaultValue={pipe.schedule} />
          <Dropdown label="Load mode" items={['CDC (incremental)', 'Full batch']} value="CDC (incremental)" onChange={() => {}} />
          <Toggle size="sm" label="Run data quality after load" defaultChecked />
          <div><Button kind="primary" icon="save" onClick={() => notify && notify({ kind: 'success', title: 'Config saved.' })}>Save config</Button></div>
        </div> },
        { label: 'Lineage', content: <div style={{ marginTop: 8 }}><Placeholder label="end-to-end lineage RAW → Gold → ClickHouse" icon="data--base" height={260} /></div> },
      ]} />
    </div>
  );
}

function Pipelines({ notify }) {
  const [wiz, setWiz] = React.useState(false);
  const [sel, setSel] = React.useState(null);
  const cols = [
    { key: 'name', label: 'Pipeline', cellClass: 'name' },
    { key: 'source', label: 'Source' },
    { key: 'target', label: 'Target layer' },
    { key: 'schedule', label: 'Schedule', cellClass: 'mono' },
    { key: 'last', label: 'Last run' },
    { key: 'next', label: 'Next run' },
    { key: 'owner', label: 'Owner' },
    { key: 'ofw', label: '', sortable: false, width: 48 },
  ];
  if (sel) return <PipelineDetail pipe={sel} onBack={() => setSel(null)} notify={notify} />;
  return (
    <div>
      <div className="w-tblwrap">
        <TableToolbar placeholder="Search pipelines" search="" onSearch={() => {}}
          actions={<React.Fragment><Button kind="ghost" size="lg" icon="filter" iconOnly /><Button kind="primary" size="lg" icon="add" onClick={() => setWiz(true)}>Create pipeline</Button></React.Fragment>} />
        <WireTable columns={cols} rows={PIPELINES} onRowClick={setSel}
          renderCell={(r, k) => {
            if (k === 'name') return <a href="#" onClick={(e) => { e.preventDefault(); setSel(r); }}>{r.name}</a>;
            if (k === 'target') return <Tag type={r.target === 'Gold' ? 'teal' : r.target === 'Silver' ? 'cyan' : 'cool-gray'} size="sm">{r.target}</Tag>;
            if (k === 'last') return <StatusDot kind={r.last}>{r.last}</StatusDot>;
            if (k === 'ofw') return <Overflow />;
            return r[k];
          }} />
      </div>
      {wiz && <PipelineWizard onClose={() => setWiz(false)} notify={notify} />}
    </div>
  );
}

const DEV_SUBS = [
  { id: 'pipelines', label: 'Pipelines' },
  { id: 'sources', label: 'Data sources' },
  { id: 'etl', label: 'ETL / DAG' },
  { id: 'cdc', label: 'CDC / sync' },
  { id: 'quality', label: 'Data quality' },
];
const DEV_TITLES = {
  pipelines: ['Pipelines', 'Unified ingest-to-serve data pipelines across all layers.'],
  sources: ['Data source management', 'Registered database, lakehouse, and streaming connections.'],
  etl: ['ETL pipeline orchestration', 'Layered RAW → Bronze → Silver → Gold → ClickHouse DAG.'],
  cdc: ['CDC / sync configuration', 'Debezium change-data-capture connectors and watermarks.'],
  quality: ['Data quality rules', 'Assertions on tables and fields with severity and alerting.'],
};
function DevConfig({ notify, lang }) {
  const [sub, setSub] = React.useState('pipelines');
  const [t, s] = DEV_TITLES[sub];
  return (
    <div className="w-page">
      <PageHead crumb={['Data Development / Config', t].map((c) => tr(lang, c))} title={tr(lang, t)} sub={tr(lang, s)} />
      <SubSwitch items={trList(lang, DEV_SUBS)} value={sub} onChange={setSub} />
      {sub === 'pipelines' && <Pipelines notify={notify} />}
      {sub === 'sources' && <DataSources notify={notify} />}
      {sub === 'etl' && <EtlDag />}
      {sub === 'cdc' && <Cdc />}
      {sub === 'quality' && <DataQuality notify={notify} />}
    </div>
  );
}

Object.assign(window, { DevConfig });
