/* @ds-bundle: {"format":3,"namespace":"CarbonDesignSystem_280d33","components":[{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Icon","sourcePath":"components/core/Icon.jsx"},{"name":"Tabs","sourcePath":"components/data/Tabs.jsx"},{"name":"Tag","sourcePath":"components/data/Tag.jsx"},{"name":"Tile","sourcePath":"components/data/Tile.jsx"},{"name":"InlineNotification","sourcePath":"components/feedback/InlineNotification.jsx"},{"name":"Loading","sourcePath":"components/feedback/Loading.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Dropdown","sourcePath":"components/forms/Dropdown.jsx"},{"name":"Search","sourcePath":"components/forms/Search.jsx"},{"name":"TextInput","sourcePath":"components/forms/TextInput.jsx"},{"name":"Toggle","sourcePath":"components/forms/Toggle.jsx"}],"sourceHashes":{"IPAS-DataPlatform/Admin.jsx":"f722aaaef0c0","IPAS-DataPlatform/Analytics.jsx":"54bc6b5f1650","IPAS-DataPlatform/DevConfig.jsx":"71e889f74540","IPAS-DataPlatform/Governance.jsx":"271369e0cd6b","IPAS-DataPlatform/IpOverview.jsx":"b9c66267b187","IPAS-DataPlatform/IpasApp.jsx":"fe4f62b2d4b6","IPAS-DataPlatform/Modeling.jsx":"9472e9cb7d73","IPAS-DataPlatform/Monitoring.jsx":"2e5e90d63bf8","IPAS-DataPlatform/Notifications.jsx":"b85570309740","IPAS-DataPlatform/Profile.jsx":"c8c768699dea","IPAS-DataPlatform/Shell.jsx":"1e7e9ac1f212","IPAS-DataPlatform/Welcome.jsx":"1ca2779101a2","IPAS-DataPlatform/wire.jsx":"86c84f0d7f26","components/core/Button.jsx":"78832afed16d","components/core/Icon.jsx":"7ecc89669f5e","components/data/Tabs.jsx":"73eb0cd3c1aa","components/data/Tag.jsx":"d99335ea4225","components/data/Tile.jsx":"8fcacacd62f9","components/feedback/InlineNotification.jsx":"3d91d468c5c8","components/feedback/Loading.jsx":"0faf97f80784","components/forms/Checkbox.jsx":"aac5092c4a0a","components/forms/Dropdown.jsx":"7412015438e5","components/forms/Search.jsx":"f616cdb18086","components/forms/TextInput.jsx":"60c746781e79","components/forms/Toggle.jsx":"4fce043f7463","ui_kits/cloud-console/App.jsx":"47cf2a041a39","ui_kits/cloud-console/Overview.jsx":"218b8b459592","ui_kits/cloud-console/ResourcesTable.jsx":"10ab70014171","ui_kits/cloud-console/UIShell.jsx":"aa5e33000c56"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CarbonDesignSystem_280d33 = window.CarbonDesignSystem_280d33 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// IPAS-DataPlatform/Admin.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, StatusDot, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  Dropdown
} = window.CarbonDesignSystem_280d33;
const ADMIN_TABS = [{
  id: 'users',
  label: 'Users & roles'
}, {
  id: 'orgs',
  label: 'Organizations'
}, {
  id: 'config',
  label: 'System config'
}, {
  id: 'audit',
  label: 'Audit log'
}, {
  id: 'api',
  label: 'API gateway'
}, {
  id: 'tenancy',
  label: 'Multi-tenancy'
}];
const ADMIN_DATA = {
  users: {
    create: 'Add user',
    cols: [{
      key: 'name',
      label: 'Name',
      cellClass: 'name'
    }, {
      key: 'email',
      label: 'Email',
      cellClass: 'mono'
    }, {
      key: 'role',
      label: 'Role'
    }, {
      key: 'org',
      label: 'Organization'
    }, {
      key: 'status',
      label: 'Status'
    }, {
      key: 'ofw',
      label: '',
      sortable: false,
      width: 48
    }],
    rows: [{
      name: 'Lena Marsh',
      email: 'lmarsh@ipas',
      role: 'Admin',
      org: 'Manufacturing',
      status: 'Active'
    }, {
      name: 'Ade Okafor',
      email: 'aokafor@ipas',
      role: 'Editor',
      org: 'Finance',
      status: 'Active'
    }, {
      name: 'Ravi Vance',
      email: 'rvance@ipas',
      role: 'Steward',
      org: 'Logistics',
      status: 'Active'
    }, {
      name: 'Mara Díaz',
      email: 'mdiaz@ipas',
      role: 'Viewer',
      org: 'Operations',
      status: 'Suspended'
    }, {
      name: 'Jon Singh',
      email: 'jsingh@ipas',
      role: 'Editor',
      org: 'Growth',
      status: 'Invited'
    }],
    cell: (r, k) => {
      if (k === 'role') return /*#__PURE__*/React.createElement(Tag, {
        type: "cool-gray",
        size: "sm"
      }, r.role);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status === 'Active' ? 'active' : r.status === 'Suspended' ? 'failed' : 'gray'
      }, r.status);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  },
  orgs: {
    create: 'Create organization',
    cols: [{
      key: 'org',
      label: 'Organization',
      cellClass: 'name'
    }, {
      key: 'members',
      label: 'Members'
    }, {
      key: 'projects',
      label: 'Projects'
    }, {
      key: 'owner',
      label: 'Owner'
    }, {
      key: 'ofw',
      label: '',
      sortable: false,
      width: 48
    }],
    rows: [{
      org: 'Manufacturing',
      members: '48',
      projects: '12',
      owner: 'L. Marsh'
    }, {
      org: 'Finance',
      members: '22',
      projects: '7',
      owner: 'A. Okafor'
    }, {
      org: 'Logistics',
      members: '31',
      projects: '9',
      owner: 'R. Vance'
    }, {
      org: 'Operations',
      members: '18',
      projects: '5',
      owner: 'M. Díaz'
    }],
    cell: (r, k) => k === 'ofw' ? /*#__PURE__*/React.createElement(Overflow, null) : r[k]
  },
  config: {
    create: 'New setting',
    cols: [{
      key: 'key',
      label: 'Setting',
      cellClass: 'mono'
    }, {
      key: 'val',
      label: 'Value',
      cellClass: 'mono'
    }, {
      key: 'scope',
      label: 'Scope'
    }, {
      key: 'by',
      label: 'Updated by'
    }, {
      key: 'ofw',
      label: '',
      sortable: false,
      width: 48
    }],
    rows: [{
      key: 'query.engine.default',
      val: 'auto',
      scope: 'Global',
      by: 'system'
    }, {
      key: 'retention.bronze.days',
      val: '90',
      scope: 'Global',
      by: 'L. Marsh'
    }, {
      key: 'sla.freshness.minutes',
      val: '30',
      scope: 'Manufacturing',
      by: 'L. Marsh'
    }, {
      key: 'auth.session.ttl',
      val: '8h',
      scope: 'Global',
      by: 'system'
    }, {
      key: 'masking.pii.default',
      val: 'full',
      scope: 'Global',
      by: 'R. Vance'
    }],
    cell: (r, k) => k === 'ofw' ? /*#__PURE__*/React.createElement(Overflow, null) : k === 'scope' ? /*#__PURE__*/React.createElement(Tag, {
      type: "cool-gray",
      size: "sm"
    }, r.scope) : r[k]
  },
  audit: {
    create: null,
    cols: [{
      key: 'time',
      label: 'Timestamp',
      cellClass: 'mono'
    }, {
      key: 'actor',
      label: 'Actor'
    }, {
      key: 'action',
      label: 'Action'
    }, {
      key: 'target',
      label: 'Target',
      cellClass: 'mono'
    }, {
      key: 'res',
      label: 'Result'
    }],
    rows: [{
      time: '14:32:08',
      actor: 'L. Marsh',
      action: 'grant.role',
      target: 'analyst → aokafor',
      res: 'OK'
    }, {
      time: '14:21:55',
      actor: 'system',
      action: 'pipeline.run',
      target: 'erp_to_gold',
      res: 'OK'
    }, {
      time: '14:02:31',
      actor: 'R. Vance',
      action: 'policy.update',
      target: 'orders.row_filter',
      res: 'OK'
    }, {
      time: '13:48:12',
      actor: 'aokafor',
      action: 'query.export',
      target: 'gold.fact_production',
      res: 'Denied'
    }, {
      time: '13:30:00',
      actor: 'system',
      action: 'cdc.restart',
      target: 'crm-cdc',
      res: 'OK'
    }],
    cell: (r, k) => k === 'res' ? /*#__PURE__*/React.createElement(StatusDot, {
      kind: r.res === 'OK' ? 'success' : 'failed'
    }, r.res) : r[k]
  },
  api: {
    create: 'Create API key',
    cols: [{
      key: 'name',
      label: 'Key name',
      cellClass: 'name'
    }, {
      key: 'prefix',
      label: 'Key',
      cellClass: 'mono'
    }, {
      key: 'scope',
      label: 'Scopes'
    }, {
      key: 'rate',
      label: 'Rate limit'
    }, {
      key: 'status',
      label: 'Status'
    }, {
      key: 'ofw',
      label: '',
      sortable: false,
      width: 48
    }],
    rows: [{
      name: 'bi-readonly',
      prefix: 'ipas_sk_a91f…',
      scope: 'read:gold',
      rate: '600/min',
      status: 'Active'
    }, {
      name: 'airflow-orchestrator',
      prefix: 'ipas_sk_77c2…',
      scope: 'write:pipelines',
      rate: '1200/min',
      status: 'Active'
    }, {
      name: 'legacy-export',
      prefix: 'ipas_sk_0b34…',
      scope: 'read:silver',
      rate: '120/min',
      status: 'Revoked'
    }],
    cell: (r, k) => {
      if (k === 'scope') return /*#__PURE__*/React.createElement(Tag, {
        type: "cool-gray",
        size: "sm"
      }, r.scope);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status === 'Active' ? 'active' : 'gray'
      }, r.status);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  },
  tenancy: {
    create: 'Add tenant',
    cols: [{
      key: 'tenant',
      label: 'Tenant',
      cellClass: 'name'
    }, {
      key: 'plan',
      label: 'Plan'
    }, {
      key: 'isolation',
      label: 'Isolation'
    }, {
      key: 'storage',
      label: 'Storage'
    }, {
      key: 'status',
      label: 'Status'
    }, {
      key: 'ofw',
      label: '',
      sortable: false,
      width: 48
    }],
    rows: [{
      tenant: 'acme-mfg',
      plan: 'Enterprise',
      isolation: 'Dedicated schema',
      storage: '4.2 TB',
      status: 'Active'
    }, {
      tenant: 'globex-fin',
      plan: 'Enterprise',
      isolation: 'Dedicated schema',
      storage: '1.8 TB',
      status: 'Active'
    }, {
      tenant: 'initech-logistics',
      plan: 'Standard',
      isolation: 'Shared (RLS)',
      storage: '640 GB',
      status: 'Active'
    }, {
      tenant: 'umbrella-trial',
      plan: 'Trial',
      isolation: 'Shared (RLS)',
      storage: '12 GB',
      status: 'Provisioning'
    }],
    cell: (r, k) => {
      if (k === 'plan') return /*#__PURE__*/React.createElement(Tag, {
        type: r.plan === 'Enterprise' ? 'teal' : r.plan === 'Trial' ? 'cool-gray' : 'blue',
        size: "sm"
      }, r.plan);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status
      }, r.status);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  }
};
function Admin({
  lang
}) {
  const [tab, setTab] = React.useState('users');
  const d = ADMIN_DATA[tab];
  const label = ADMIN_TABS.find(t => t.id === tab).label;
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Platform Admin', label].map(c => tr(lang, c)),
    title: tr(lang, 'Platform administration'),
    sub: tr(lang, 'Manage people, organizations, configuration, and platform-wide controls.')
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, ADMIN_TABS),
    value: tab,
    onChange: setTab
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: `Search ${label.toLowerCase()}`,
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), tab === 'audit' && /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "download",
      iconOnly: true
    }), d.create && /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add"
    }, d.create))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: d.cols,
    rows: d.rows,
    total: tab === 'audit' ? 4821 : d.rows.length,
    renderCell: d.cell
  })));
}
Object.assign(window, {
  Admin
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Admin.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Analytics.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, BarChart, EmptyState, FieldChip, StatusDot, ToolBtn, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown,
  Toggle,
  Checkbox
} = window.CarbonDesignSystem_280d33;
const ANALYTICS_CSS = `
.an-gallery { display:grid; grid-template-columns:repeat(auto-fill,minmax(260px,1fr)); gap:16px; }
.an-gallery.list { display:block; }
.an-card { background:var(--cds-layer-02); border:1px solid var(--wire-border); cursor:pointer; transition:box-shadow .11s, border-color .11s; }
.an-card:hover { box-shadow:var(--cds-shadow-overlay,0 2px 8px rgba(0,0,0,.16)); border-color:var(--cds-border-strong-01); }
.an-card__meta { padding:12px 16px 16px; }
.an-card__meta h3 { font-size:.875rem; font-weight:600; margin:0 0 8px; color:var(--cds-text-primary); }
.an-card__meta .row { display:flex; align-items:center; gap:6px; font-size:.75rem; color:var(--cds-text-secondary); margin-top:4px; }
.an-card__tags { display:flex; gap:6px; margin-top:10px; flex-wrap:wrap; }
.an-listcard { display:flex; align-items:center; gap:16px; background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:12px 16px; margin-bottom:-1px; cursor:pointer; }
.an-listcard:hover { background:var(--cds-layer-hover-01); }
.an-listcard .th { width:80px; height:48px; flex:0 0 auto; }

/* editor */
.an-editor { display:flex; flex-direction:column; height:100vh; }
.an-editor__body { display:flex; flex:1; min-height:0; }
.an-pane { background:var(--cds-layer-02); border-right:1px solid var(--wire-border); display:flex; flex-direction:column; min-height:0; }
.an-pane--right { border-right:none; border-left:1px solid var(--wire-border); }
.an-pane__h { display:flex; align-items:center; gap:8px; height:40px; padding:0 8px 0 16px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; letter-spacing:.16px; color:var(--cds-text-primary); }
.an-pane__h .x { margin-left:auto; width:28px; height:28px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.an-pane__h .x:hover { background:var(--cds-layer-hover-01); }
.an-pane__body { padding:12px; overflow:auto; flex:1; min-height:0; }
.an-palette { display:grid; grid-template-columns:repeat(3,1fr); gap:8px; }
.an-charttype { display:flex; flex-direction:column; align-items:center; gap:6px; padding:10px 4px; border:1px solid var(--wire-border); background:var(--cds-layer-02); cursor:grab; font-size:.6875rem; color:var(--cds-text-secondary); text-align:center; }
.an-charttype:hover { border-color:var(--cds-border-interactive); color:var(--cds-text-primary); }
.an-canvas { flex:1; position:relative; overflow:auto; padding:16px;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.an-widget { position:absolute; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.08); display:flex; flex-direction:column; }
.an-widget.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.an-widget__h { display:flex; align-items:center; gap:6px; height:32px; padding:0 8px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; color:var(--cds-text-primary); cursor:move; }
.an-widget__h .grip { margin-left:auto; color:var(--cds-icon-secondary); display:flex; }
.an-widget__b { flex:1; padding:8px; min-height:0; }
.an-resize { position:absolute; right:-4px; bottom:-4px; width:12px; height:12px; border-right:2px solid var(--cds-border-interactive); border-bottom:2px solid var(--cds-border-interactive); cursor:nwse-resize; }
.an-shelf { margin-bottom:16px; }
.an-shelf > .lbl { font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); margin-bottom:6px; display:block; }
.an-shelf__drop { min-height:40px; border:1px dashed var(--cds-border-strong-01); padding:6px; display:flex; flex-direction:column; gap:6px; }
.an-pill { display:flex; align-items:center; gap:8px; background:var(--cds-blue-60); color:#fff; font-size:.75rem; padding:4px 8px; }
.an-pill .x { margin-left:auto; cursor:pointer; display:flex; }
.an-pill.agg { background:var(--cds-layer-01); color:var(--cds-text-primary); border:1px solid var(--wire-border); }

/* sql editor */
.an-sql { display:flex; flex-direction:column; gap:0; border:1px solid var(--wire-border); }
.an-sql__bar { display:flex; align-items:center; gap:1px; height:48px; padding:0 8px; border-bottom:1px solid var(--wire-border); background:var(--cds-layer-02); }
.an-sql__bar .spacer { flex:1; }
.an-sql__code { font-family:var(--cds-font-mono); font-size:.8125rem; line-height:1.6; background:var(--cds-gray-100); color:#f4f4f4; padding:16px; min-height:200px; white-space:pre; overflow:auto; }
.an-sql__code .kw { color:#78a9ff; } .an-sql__code .fn { color:#3ddbd9; } .an-sql__code .str { color:#42be65; } .an-sql__code .cm { color:#8d8d8d; }
.an-sql__ln { color:var(--cds-gray-50,#6f6f6f); display:inline-block; width:24px; user-select:none; }
.an-vbuilder { display:flex; gap:0; border:1px solid var(--wire-border); }
.an-vbuilder .step { flex:1; padding:16px; border-right:1px solid var(--wire-border); }
.an-vbuilder .step:last-child { border-right:none; }
.an-vbuilder .step h4 { font-size:.75rem; font-weight:600; margin:0 0 12px; color:var(--cds-text-primary); display:flex; align-items:center; gap:6px; }
.an-fieldlist { display:flex; flex-direction:column; gap:6px; }
`;
(function () {
  if (!document.getElementById('ipas-analytics-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-analytics-styles';
    e.textContent = ANALYTICS_CSS;
    document.head.appendChild(e);
  }
})();
const DASHBOARDS = [{
  id: 1,
  name: 'Production Yield Overview',
  owner: 'L. Marsh',
  mod: '2 hours ago',
  tags: ['Manufacturing', 'Gold']
}, {
  id: 2,
  name: 'Daily Revenue & Margin',
  owner: 'A. Okafor',
  mod: 'Yesterday',
  tags: ['Finance']
}, {
  id: 3,
  name: 'Supply Chain Latency',
  owner: 'R. Vance',
  mod: '3 days ago',
  tags: ['Logistics', 'SLA']
}, {
  id: 4,
  name: 'SPC Control — Line 4',
  owner: 'L. Marsh',
  mod: '5 days ago',
  tags: ['Quality', 'SPC']
}, {
  id: 5,
  name: 'Customer Cohort Retention',
  owner: 'J. Singh',
  mod: 'Apr 18',
  tags: ['Growth']
}, {
  id: 6,
  name: 'Warehouse Throughput',
  owner: 'R. Vance',
  mod: 'Apr 16',
  tags: ['Logistics']
}, {
  id: 7,
  name: 'Energy Consumption',
  owner: 'M. Díaz',
  mod: 'Apr 12',
  tags: ['Ops', 'IoT']
}, {
  id: 8,
  name: 'Defect Pareto Analysis',
  owner: 'L. Marsh',
  mod: 'Apr 9',
  tags: ['Quality']
}];
const CHART_TYPES = [{
  label: 'Line',
  icon: 'chart--line'
}, {
  label: 'Bar',
  icon: 'chart--bar'
}, {
  label: 'Pie',
  icon: 'dashboard'
}, {
  label: 'Scatter',
  icon: 'interactions'
}, {
  label: 'Map',
  icon: 'cloud'
}, {
  label: 'Funnel',
  icon: 'filter'
}, {
  label: 'Table',
  icon: 'list'
}, {
  label: 'SPC chart',
  icon: 'analytics'
}];
const REPORTS = [{
  id: 1,
  name: 'Weekly Yield Digest',
  schedule: '0 7 * * 1',
  recipients: 'ops-leads@ipas',
  format: 'PDF',
  channel: 'Email',
  status: 'Active'
}, {
  id: 2,
  name: 'Daily Revenue Snapshot',
  schedule: '0 6 * * *',
  recipients: 'finance@ipas',
  format: 'Excel',
  channel: 'Email',
  status: 'Active'
}, {
  id: 3,
  name: 'SLA Breach Alert Roll-up',
  schedule: '0 */4 * * *',
  recipients: '#data-sla',
  format: 'PDF',
  channel: 'IM',
  status: 'Active'
}, {
  id: 4,
  name: 'Monthly Exec Board Pack',
  schedule: '0 8 1 * *',
  recipients: 'exec@ipas',
  format: 'PDF',
  channel: 'Email',
  status: 'Paused'
}, {
  id: 5,
  name: 'Quality NCR Summary',
  schedule: '0 18 * * 5',
  recipients: 'quality@ipas',
  format: 'Excel',
  channel: 'Email',
  status: 'Draft'
}];
function GalleryCard({
  d,
  list,
  onOpen
}) {
  if (list) {
    return /*#__PURE__*/React.createElement("div", {
      className: "an-listcard",
      onClick: onOpen
    }, /*#__PURE__*/React.createElement(Placeholder, {
      label: "",
      icon: "chart--bar",
      height: 48,
      style: {
        width: 80
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: '.875rem',
        color: 'var(--cds-text-primary)'
      }
    }, d.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: '.75rem',
        color: 'var(--cds-text-secondary)',
        marginTop: 2
      }
    }, d.owner, " \xB7 ", d.mod)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 6
      }
    }, d.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
      key: t,
      type: "cool-gray",
      size: "sm"
    }, t))), /*#__PURE__*/React.createElement(Overflow, null));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "an-card",
    onClick: onOpen
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "dashboard preview",
    icon: "chart--bar",
    height: 140,
    style: {
      borderTop: 'none',
      borderLeft: 'none',
      borderRight: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "an-card__meta"
  }, /*#__PURE__*/React.createElement("h3", null, d.name), /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user--avatar",
    size: 16
  }), d.owner), /*#__PURE__*/React.createElement("div", {
    className: "row"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "time",
    size: 16
  }), "Modified ", d.mod), /*#__PURE__*/React.createElement("div", {
    className: "an-card__tags"
  }, d.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    type: "cool-gray",
    size: "sm"
  }, t)))));
}
function DashboardGallery({
  onOpenEditor
}) {
  const [view, setView] = React.useState('grid');
  const [q, setQ] = React.useState('');
  const rows = DASHBOARDS.filter(d => d.name.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      maxWidth: 480
    }
  }, /*#__PURE__*/React.createElement(Search, {
    value: q,
    onChange: setQ,
    size: "lg",
    placeholder: "Search dashboards"
  })), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['All tags', 'Quality', 'Finance', 'Logistics', 'Ops'],
    value: "All tags",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['All owners', 'L. Marsh', 'A. Okafor', 'R. Vance'],
    value: "All owners",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      border: '1px solid var(--cds-border-strong-01)'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: view === 'grid' ? 'primary' : 'ghost',
    size: "md",
    icon: "grid",
    iconOnly: true,
    onClick: () => setView('grid')
  }), /*#__PURE__*/React.createElement(Button, {
    kind: view === 'list' ? 'primary' : 'ghost',
    size: "md",
    icon: "list",
    iconOnly: true,
    onClick: () => setView('list')
  })), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "md",
    icon: "add",
    onClick: onOpenEditor
  }, "Create dashboard")), /*#__PURE__*/React.createElement("div", {
    className: `an-gallery ${view === 'list' ? 'list' : ''}`
  }, rows.map(d => /*#__PURE__*/React.createElement(GalleryCard, {
    key: d.id,
    d: d,
    list: view === 'list',
    onOpen: onOpenEditor
  }))));
}
function DashboardEditor({
  onExit
}) {
  const [leftOpen, setLeftOpen] = React.useState(true);
  const [selected, setSelected] = React.useState('w1');
  return /*#__PURE__*/React.createElement("div", {
    className: "an-editor"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-etoolbar"
  }, /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "arrow--left",
    label: "Exit",
    onClick: onExit
  }), /*#__PURE__*/React.createElement("span", {
    className: "gap"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "save",
    label: "Save"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "restart",
    label: "",
    title: "Undo"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "renew",
    label: "",
    title: "Redo"
  }), /*#__PURE__*/React.createElement("span", {
    className: "gap"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "filter",
    label: "Add filter"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "calendar",
    label: "Last 30 days",
    title: "Global date filter"
  }), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "view",
    label: "Preview"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "share",
    label: "Share"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '0 4px'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "sm",
    icon: "send"
  }, "Subscribe"))), /*#__PURE__*/React.createElement("div", {
    className: "an-editor__body"
  }, leftOpen ? /*#__PURE__*/React.createElement("div", {
    className: "an-pane",
    style: {
      width: 260,
      flex: '0 0 260px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-pane__h"
  }, "Datasets", /*#__PURE__*/React.createElement("button", {
    className: "x",
    onClick: () => setLeftOpen(false),
    "aria-label": "Collapse"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--left",
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    className: "an-pane__body"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement(Search, {
    size: "sm",
    placeholder: "Search fields"
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-treeitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), "fact_production"), /*#__PURE__*/React.createElement("div", {
    className: "w-section-label",
    style: {
      margin: '8px 4px 4px'
    }
  }, "Dimensions"), /*#__PURE__*/React.createElement("div", {
    className: "an-fieldlist"
  }, ['line_id', 'shift', 'product_sku', 'plant', 'date'].map(f => /*#__PURE__*/React.createElement(FieldChip, {
    key: f,
    kind: "dim"
  }, f))), /*#__PURE__*/React.createElement("div", {
    className: "w-section-label",
    style: {
      margin: '12px 4px 4px'
    }
  }, "Measures"), /*#__PURE__*/React.createElement("div", {
    className: "an-fieldlist"
  }, ['units_produced', 'defect_count', 'yield_pct', 'cycle_time'].map(f => /*#__PURE__*/React.createElement(FieldChip, {
    key: f,
    kind: "msr"
  }, f))), /*#__PURE__*/React.createElement("div", {
    className: "an-pane__h",
    style: {
      border: 'none',
      marginTop: 16,
      paddingLeft: 0
    }
  }, "Chart types"), /*#__PURE__*/React.createElement("div", {
    className: "an-palette"
  }, CHART_TYPES.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.label,
    className: "an-charttype",
    draggable: true
  }, /*#__PURE__*/React.createElement(Icon, {
    name: c.icon,
    size: 20
  }), c.label))))) : /*#__PURE__*/React.createElement("div", {
    className: "an-pane",
    style: {
      width: 40,
      flex: '0 0 40px',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: "x",
    style: {
      width: 40,
      height: 40,
      border: 'none',
      background: 'transparent',
      cursor: 'pointer',
      color: 'var(--cds-icon-primary)'
    },
    onClick: () => setLeftOpen(true),
    "aria-label": "Expand datasets"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--right",
    size: 16
  }))), /*#__PURE__*/React.createElement("div", {
    className: "an-canvas"
  }, /*#__PURE__*/React.createElement("div", {
    className: `an-widget ${selected === 'w1' ? 'sel' : ''}`,
    style: {
      left: 24,
      top: 24,
      width: 360,
      height: 200
    },
    onClick: () => setSelected('w1')
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-widget__h"
  }, "Yield % by line", /*#__PURE__*/React.createElement("span", {
    className: "grip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-grip"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)))), /*#__PURE__*/React.createElement("div", {
    className: "an-widget__b"
  }, /*#__PURE__*/React.createElement(BarChart, {
    data: [62, 78, 71, 88, 80, 74],
    height: 120
  })), selected === 'w1' && /*#__PURE__*/React.createElement("span", {
    className: "an-resize"
  })), /*#__PURE__*/React.createElement("div", {
    className: `an-widget ${selected === 'w2' ? 'sel' : ''}`,
    style: {
      left: 408,
      top: 24,
      width: 300,
      height: 200
    },
    onClick: () => setSelected('w2')
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-widget__h"
  }, "Defect trend", /*#__PURE__*/React.createElement("span", {
    className: "grip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-grip"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)))), /*#__PURE__*/React.createElement("div", {
    className: "an-widget__b"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "line chart",
    icon: "chart--line",
    height: 120
  })), selected === 'w2' && /*#__PURE__*/React.createElement("span", {
    className: "an-resize"
  })), /*#__PURE__*/React.createElement("div", {
    className: `an-widget ${selected === 'w3' ? 'sel' : ''}`,
    style: {
      left: 24,
      top: 248,
      width: 684,
      height: 180
    },
    onClick: () => setSelected('w3')
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-widget__h"
  }, "SPC control chart \u2014 cycle time", /*#__PURE__*/React.createElement("span", {
    className: "grip"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-grip"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)))), /*#__PURE__*/React.createElement("div", {
    className: "an-widget__b"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "SPC control chart \xB7 UCL / LCL",
    icon: "analytics",
    height: 104
  })), selected === 'w3' && /*#__PURE__*/React.createElement("span", {
    className: "an-resize"
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-engine"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), /*#__PURE__*/React.createElement("span", null, "Query engine: ", /*#__PURE__*/React.createElement("b", null, "ClickHouse"), " \xB7 auto-routed"))), /*#__PURE__*/React.createElement("div", {
    className: "an-pane an-pane--right",
    style: {
      width: 280,
      flex: '0 0 280px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-pane__h"
  }, "Configure \xB7 Yield % by line"), /*#__PURE__*/React.createElement("div", {
    className: "an-pane__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-shelf"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "X axis"), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf__drop"
  }, /*#__PURE__*/React.createElement("span", {
    className: "an-pill"
  }, "line_id", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 16
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Y axis (measure)"), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf__drop"
  }, /*#__PURE__*/React.createElement("span", {
    className: "an-pill"
  }, "yield_pct", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 16
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Aggregation"), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['Average', 'Sum', 'Min', 'Max', 'Count'],
    value: "Average",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Filters"), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf__drop"
  }, /*#__PURE__*/React.createElement("span", {
    className: "an-pill agg"
  }, "shift = \"Day\"", /*#__PURE__*/React.createElement("span", {
    className: "x"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 16
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf"
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Calculated field"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.75rem',
      background: 'var(--cds-field-01)',
      border: '1px solid var(--wire-border)',
      padding: 8,
      color: 'var(--cds-text-secondary)'
    }
  }, "1 - (defect_count / units_produced)")), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    icon: "add"
  }, "Add calculated field"), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf",
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, "Style"), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement(Toggle, {
    size: "sm",
    label: "Show data labels",
    defaultChecked: true
  })))))));
}
function SqlBlock() {
  return /*#__PURE__*/React.createElement("div", {
    className: "an-sql__code"
  }, /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "1"), /*#__PURE__*/React.createElement("span", {
    className: "cm"
  }, "-- Daily yield by production line"), '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "2"), /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "SELECT"), "  line_id,", '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "3"), "        ", /*#__PURE__*/React.createElement("span", {
    className: "fn"
  }, "avg"), "(yield_pct) ", /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "AS"), " avg_yield,", '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "4"), "        ", /*#__PURE__*/React.createElement("span", {
    className: "fn"
  }, "sum"), "(units_produced) ", /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "AS"), " units", '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "5"), /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "FROM"), "    gold.fact_production", '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "6"), /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "WHERE"), "   event_date ", '>=', " ", /*#__PURE__*/React.createElement("span", {
    className: "str"
  }, "'2026-04-01'"), '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "7"), /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "GROUP BY"), " line_id", '\n', /*#__PURE__*/React.createElement("span", {
    className: "an-sql__ln"
  }, "8"), /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "ORDER BY"), " avg_yield ", /*#__PURE__*/React.createElement("span", {
    className: "kw"
  }, "DESC"), ";");
}
function AdHocQuery() {
  const [mode, setMode] = React.useState('sql');
  const cols = [{
    key: 'line_id',
    label: 'line_id'
  }, {
    key: 'avg_yield',
    label: 'avg_yield'
  }, {
    key: 'units',
    label: 'units'
  }];
  const data = [{
    line_id: 'LINE-04',
    avg_yield: '88.2',
    units: '142,800'
  }, {
    line_id: 'LINE-02',
    avg_yield: '80.4',
    units: '131,250'
  }, {
    line_id: 'LINE-05',
    avg_yield: '78.9',
    units: '128,910'
  }, {
    line_id: 'LINE-01',
    avg_yield: '74.1',
    units: '120,400'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16,
      display: 'inline-flex',
      border: '1px solid var(--cds-border-strong-01)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    className: `w-iconbtn`,
    style: {
      height: 40,
      padding: '0 16px',
      background: mode === 'visual' ? 'var(--cds-gray-100)' : 'transparent',
      color: mode === 'visual' ? '#fff' : 'var(--cds-text-secondary)'
    },
    onClick: () => setMode('visual')
  }, "Visual query builder"), /*#__PURE__*/React.createElement("button", {
    className: `w-iconbtn`,
    style: {
      height: 40,
      padding: '0 16px',
      borderLeft: '1px solid var(--cds-border-strong-01)',
      background: mode === 'sql' ? 'var(--cds-gray-100)' : 'transparent',
      color: mode === 'sql' ? '#fff' : 'var(--cds-text-secondary)'
    },
    onClick: () => setMode('sql')
  }, "SQL editor")), mode === 'visual' ? /*#__PURE__*/React.createElement("div", {
    className: "an-vbuilder"
  }, /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("h4", null, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), "1 \xB7 Source"), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['gold.fact_production', 'silver.orders', 'gold.dim_product'],
    value: "gold.fact_production",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("h4", null, /*#__PURE__*/React.createElement(Icon, {
    name: "add",
    size: 16
  }), "2 \xB7 Fields"), /*#__PURE__*/React.createElement("div", {
    className: "an-fieldlist"
  }, ['line_id', 'yield_pct', 'units_produced'].map(f => /*#__PURE__*/React.createElement(FieldChip, {
    key: f,
    kind: ""
  }, f)))), /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("h4", null, /*#__PURE__*/React.createElement(Icon, {
    name: "filter",
    size: 16
  }), "3 \xB7 Conditions"), /*#__PURE__*/React.createElement("div", {
    className: "an-shelf__drop"
  }, /*#__PURE__*/React.createElement("span", {
    className: "an-pill agg"
  }, "event_date \u2265 2026-04-01"))), /*#__PURE__*/React.createElement("div", {
    className: "step"
  }, /*#__PURE__*/React.createElement("h4", null, /*#__PURE__*/React.createElement(Icon, {
    name: "list",
    size: 16
  }), "4 \xB7 Group / sort"), /*#__PURE__*/React.createElement("div", {
    className: "an-fieldlist"
  }, /*#__PURE__*/React.createElement(FieldChip, {
    kind: "group"
  }, "line_id"), /*#__PURE__*/React.createElement(FieldChip, {
    kind: "sort"
  }, "avg_yield \u2193")))) : /*#__PURE__*/React.createElement("div", {
    className: "an-sql"
  }, /*#__PURE__*/React.createElement("div", {
    className: "an-sql__bar"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    items: ['gold.fact_production', 'silver.orders'],
    value: "gold.fact_production",
    onChange: () => {},
    style: {
      width: 260
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "sm",
    icon: "play"
  }, "Run")), /*#__PURE__*/React.createElement(SqlBlock, null)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      margin: '24px 0 8px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.875rem',
      fontWeight: 600,
      color: 'var(--cds-text-primary)'
    }
  }, "Results ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--cds-text-secondary)',
      fontWeight: 400
    }
  }, "\xB7 4 rows \xB7 0.42s")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 1
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    icon: "download"
  }, "CSV"), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    icon: "export"
  }, "Excel"))), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: data,
    footer: false,
    renderCell: (r, k) => /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--cds-font-mono)',
        fontSize: '.8125rem'
      }
    }, r[k])
  }));
}
function ReportSubscriptions({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const cols = [{
    key: 'name',
    label: 'Report',
    cellClass: 'name'
  }, {
    key: 'schedule',
    label: 'Schedule',
    cellClass: 'mono'
  }, {
    key: 'recipients',
    label: 'Recipients'
  }, {
    key: 'format',
    label: 'Format'
  }, {
    key: 'channel',
    label: 'Channel'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap",
    style: {
      border: 'none'
    }
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search subscriptions",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setOpen(true)
    }, "New subscription"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: REPORTS,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault()
      }, r.name);
      if (k === 'channel') return /*#__PURE__*/React.createElement(Tag, {
        type: r.channel === 'IM' ? 'purple' : 'blue',
        size: "sm"
      }, r.channel);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status
      }, r.status);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Distribution",
    title: "New subscription",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Subscription created.',
          subtitle: 'First run scheduled.'
        });
      }
    }, "Create"))
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Subscription name",
    placeholder: "Weekly digest"
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Source dashboard",
    items: ['Production Yield Overview', 'Daily Revenue & Margin'],
    value: "Production Yield Overview",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Format",
    items: ['PDF', 'Excel', 'PNG'],
    value: "PDF",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Schedule (cron)",
    defaultValue: "0 7 * * 1",
    helperText: "Runs every Monday at 07:00."
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Channel",
    items: ['Email', 'IM', 'Webhook'],
    value: "Email",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Recipients",
    placeholder: "team@ipas"
  }))));
}
const ANALYTICS_SUBS = [{
  id: 'gallery',
  label: 'Dashboard gallery'
}, {
  id: 'editor',
  label: 'Dashboard editor'
}, {
  id: 'query',
  label: 'Ad-hoc query'
}, {
  id: 'datasets',
  label: 'Datasets'
}, {
  id: 'reports',
  label: 'Report subscriptions'
}];
const DATASETS = [{
  id: 1,
  name: 'yield_by_line_daily',
  source: 'gold.fact_production',
  owner: 'L. Marsh',
  refreshed: '14m ago',
  rows: '142,800',
  usedBy: 8
}, {
  id: 2,
  name: 'revenue_margin_v2',
  source: 'SQL · gold.fact_sales',
  owner: 'A. Okafor',
  refreshed: '1h ago',
  rows: '512,440',
  usedBy: 5
}, {
  id: 3,
  name: 'on_time_delivery',
  source: 'gold.fact_logistics',
  owner: 'R. Vance',
  refreshed: '3h ago',
  rows: '88,210',
  usedBy: 3
}, {
  id: 4,
  name: 'spc_cycle_time_l4',
  source: 'SQL · gold.spc_xbar_r_chart',
  owner: 'L. Marsh',
  refreshed: '20m ago',
  rows: '24,990',
  usedBy: 2
}, {
  id: 5,
  name: 'cohort_retention',
  source: 'silver.events',
  owner: 'J. Singh',
  refreshed: 'Yesterday',
  rows: '1,204,000',
  usedBy: 4
}];
function Datasets({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const [sel, setSel] = React.useState(null);
  const cols = [{
    key: 'name',
    label: 'Dataset',
    cellClass: 'name'
  }, {
    key: 'source',
    label: 'Source',
    cellClass: 'mono'
  }, {
    key: 'owner',
    label: 'Owner'
  }, {
    key: 'refreshed',
    label: 'Last refreshed'
  }, {
    key: 'rows',
    label: 'Rows'
  }, {
    key: 'usedBy',
    label: 'Used by'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  if (sel) {
    const schemaCols = [{
      key: 'col',
      label: 'Column',
      cellClass: 'mono'
    }, {
      key: 'type',
      label: 'Type'
    }, {
      key: 'desc',
      label: 'Description'
    }];
    const schema = [{
      col: 'line_id',
      type: 'varchar',
      desc: 'Production line'
    }, {
      col: 'event_date',
      type: 'date',
      desc: 'Aggregation day'
    }, {
      col: 'avg_yield',
      type: 'double',
      desc: 'Average first-pass yield'
    }, {
      col: 'units',
      type: 'bigint',
      desc: 'Units produced'
    }];
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "sm",
      icon: "arrow--left",
      onClick: () => setSel(null),
      style: {
        marginBottom: 12
      }
    }, "Back to datasets"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        fontSize: '1.5rem',
        fontWeight: 400,
        margin: 0,
        fontFamily: 'var(--cds-font-mono)'
      }
    }, sel.name), /*#__PURE__*/React.createElement(Tag, {
      type: "teal",
      size: "sm"
    }, "Gold")), /*#__PURE__*/React.createElement("p", {
      style: {
        color: 'var(--cds-text-secondary)',
        fontSize: '.875rem',
        margin: '0 0 20px'
      }
    }, sel.source, " \xB7 ", sel.rows, " rows \xB7 used by ", sel.usedBy, " dashboards \xB7 owner ", sel.owner), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 1,
        marginBottom: 20
      }
    }, /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "sm",
      icon: "renew",
      onClick: () => notify && notify({
        kind: 'success',
        title: 'Refresh queued.'
      })
    }, "Refresh now"), /*#__PURE__*/React.createElement(Button, {
      kind: "tertiary",
      size: "sm",
      icon: "edit"
    }, "Edit definition"), /*#__PURE__*/React.createElement(Button, {
      kind: "tertiary",
      size: "sm",
      icon: "chart--bar"
    }, "Create chart")), /*#__PURE__*/React.createElement(Tabs, {
      tabs: [{
        label: 'Schema',
        content: /*#__PURE__*/React.createElement("div", {
          style: {
            marginTop: 8
          }
        }, /*#__PURE__*/React.createElement(WireTable, {
          columns: schemaCols,
          rows: schema,
          footer: false,
          renderCell: (r, k) => r[k]
        }))
      }, {
        label: 'Definition',
        content: /*#__PURE__*/React.createElement("div", {
          style: {
            marginTop: 8
          }
        }, /*#__PURE__*/React.createElement("div", {
          className: "an-sql"
        }, /*#__PURE__*/React.createElement(SqlBlock, null)))
      }, {
        label: 'Refresh schedule',
        content: /*#__PURE__*/React.createElement("div", {
          style: {
            marginTop: 8,
            maxWidth: 480,
            display: 'flex',
            flexDirection: 'column',
            gap: 16
          }
        }, /*#__PURE__*/React.createElement(TextInput, {
          label: "Schedule (cron)",
          defaultValue: "*/30 * * * *",
          helperText: "Every 30 minutes."
        }), /*#__PURE__*/React.createElement(Toggle, {
          size: "sm",
          label: "Incremental refresh",
          defaultChecked: true
        }))
      }, {
        label: 'Lineage',
        content: /*#__PURE__*/React.createElement("div", {
          style: {
            marginTop: 8
          }
        }, /*#__PURE__*/React.createElement(Placeholder, {
          label: "upstream tables \u2192 this dataset \u2192 dashboards",
          icon: "data--base",
          height: 240
        }))
      }]
    }));
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search datasets",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setOpen(true)
    }, "Create dataset"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: DATASETS,
    onRowClick: setSel,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => {
          e.preventDefault();
          setSel(r);
        }
      }, r.name);
      if (k === 'usedBy') return /*#__PURE__*/React.createElement(Tag, {
        type: "cool-gray",
        size: "sm"
      }, r.usedBy);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Datasets",
    title: "Create dataset",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Dataset created.'
        });
      }
    }, "Create"))
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Dataset name",
    placeholder: "yield_by_line_daily"
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Build from",
    items: ['Saved query', 'Catalog table', 'SQL'],
    value: "Catalog table",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Source",
    items: ['gold.fact_production', 'silver.orders', 'gold.dim_product'],
    value: "gold.fact_production",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Refresh schedule (cron)",
    defaultValue: "*/30 * * * *",
    helperText: "Leave blank for on-demand only."
  })));
}
function Analytics({
  notify,
  lang
}) {
  const [sub, setSub] = React.useState('gallery');
  if (sub === 'editor') {
    // full-bleed editor
    return /*#__PURE__*/React.createElement(DashboardEditor, {
      onExit: () => setSub('gallery')
    });
  }
  const TITLES = {
    gallery: ['Dashboard gallery', 'Browse, open, and create self-service dashboards.'],
    query: ['Ad-hoc query', 'Explore data with a visual builder or SQL — results auto-route across engines.'],
    datasets: ['Datasets', 'Saved, governed query results reused across dashboards and reports.'],
    reports: ['Report subscription & distribution', 'Schedule and deliver reports to people and channels.']
  };
  const [title, subtitle] = TITLES[sub];
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Self-Service Analytics', title].map(c => tr(lang, c)),
    title: tr(lang, title),
    sub: tr(lang, subtitle)
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, ANALYTICS_SUBS),
    value: sub,
    onChange: setSub
  }), sub === 'gallery' && /*#__PURE__*/React.createElement(DashboardGallery, {
    onOpenEditor: () => setSub('editor')
  }), sub === 'query' && /*#__PURE__*/React.createElement(AdHocQuery, null), sub === 'datasets' && /*#__PURE__*/React.createElement(Datasets, {
    notify: notify
  }), sub === 'reports' && /*#__PURE__*/React.createElement(ReportSubscriptions, {
    notify: notify
  }));
}
Object.assign(window, {
  Analytics
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Analytics.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/DevConfig.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, StatusDot, ToolBtn, Stepper, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown,
  Toggle,
  Checkbox,
  Tabs
} = window.CarbonDesignSystem_280d33;
const DEV_CSS = `
.dv-dag { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.dv-runstrip { display:flex; align-items:center; gap:10px; padding:8px 12px; border-bottom:1px solid var(--wire-border); background:var(--cds-layer-01); font-size:.75rem; color:var(--cds-text-secondary); }
.dv-runstrip .bars { display:flex; gap:2px; }
.dv-runstrip .bars i { width:8px; height:20px; }
.dv-dagbody { display:flex; flex:1; min-height:0; }
.dv-canvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.dv-layer-labels { display:flex; position:absolute; top:0; left:0; right:0; pointer-events:none; }
.dv-layer-labels .ll { width:170px; padding:8px 0; text-align:center; font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-helper); border-right:1px dashed var(--wire-border); }
.dv-node { position:absolute; width:140px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); cursor:pointer; }
.dv-node.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.dv-node__h { display:flex; align-items:center; gap:6px; padding:8px 10px; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); }
.dv-node__h .st { margin-left:auto; width:8px; height:8px; border-radius:50%; }
.dv-node__m { padding:0 10px 8px; font-size:.625rem; font-family:var(--cds-font-mono); color:var(--cds-text-secondary); }
.dv-side { width:300px; flex:0 0 300px; background:var(--cds-layer-02); border-left:1px solid var(--wire-border); display:flex; flex-direction:column; }
.dv-side__h { height:40px; display:flex; align-items:center; padding:0 16px; font-size:.75rem; font-weight:600; border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.dv-side__body { padding:16px; overflow:auto; flex:1; display:flex; flex-direction:column; gap:16px; }
.dv-kv { display:flex; flex-direction:column; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.dv-kv__r { display:flex; justify-content:space-between; gap:12px; background:var(--cds-layer-02); padding:8px 10px; font-size:.75rem; }
.dv-kv__r .k { color:var(--cds-text-secondary); } .dv-kv__r .v { color:var(--cds-text-primary); font-weight:500; font-family:var(--cds-font-mono); }
.dv-lag { display:inline-flex; align-items:center; gap:6px; font-family:var(--cds-font-mono); font-size:.75rem; }
`;
(function () {
  if (!document.getElementById('ipas-dev-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-dev-styles';
    e.textContent = DEV_CSS;
    document.head.appendChild(e);
  }
})();
const SOURCES = [{
  id: 1,
  name: 'erp-oracle-prod',
  type: 'Oracle',
  host: 'erp-db.ipas.internal:1521',
  status: 'Connected',
  tested: '2 min ago'
}, {
  id: 2,
  name: 'mes-mysql',
  type: 'MySQL',
  host: 'mes.ipas.internal:3306',
  status: 'Connected',
  tested: '5 min ago'
}, {
  id: 3,
  name: 'crm-sqlserver',
  type: 'SQL Server',
  host: 'crm-sql.ipas.internal:1433',
  status: 'Error',
  tested: '1 hour ago'
}, {
  id: 4,
  name: 'lake-iceberg',
  type: 'Iceberg',
  host: 's3://ipas-lakehouse/warehouse',
  status: 'Connected',
  tested: '12 min ago'
}, {
  id: 5,
  name: 'analytics-clickhouse',
  type: 'ClickHouse',
  host: 'ch.ipas.internal:8123',
  status: 'Connected',
  tested: '1 min ago'
}, {
  id: 6,
  name: 'events-kafka',
  type: 'Kafka',
  host: 'kafka-0.ipas.internal:9092',
  status: 'Degraded',
  tested: '8 min ago'
}];
function DataSources({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const [tested, setTested] = React.useState(false);
  const cols = [{
    key: 'name',
    label: 'Connection',
    cellClass: 'name'
  }, {
    key: 'type',
    label: 'Type'
  }, {
    key: 'host',
    label: 'Host',
    cellClass: 'mono'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'tested',
    label: 'Last tested'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search connections",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => {
        setOpen(true);
        setTested(false);
      }
    }, "Add data source"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: SOURCES,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault()
      }, r.name);
      if (k === 'type') return /*#__PURE__*/React.createElement(Tag, {
        type: "cool-gray",
        size: "sm"
      }, r.type);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status
      }, r.status);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Connections",
    title: "Add data source",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Data source added.'
        });
      }
    }, "Add source"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Type",
    items: ['Oracle', 'MySQL', 'SQL Server', 'Iceberg', 'ClickHouse', 'Kafka'],
    value: "Oracle",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Connection name",
    placeholder: "erp-oracle-prod"
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Host",
    placeholder: "db.ipas.internal"
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Port",
    defaultValue: "1521"
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Database / service",
    placeholder: "ORCLPDB1"
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Username",
    placeholder: "svc_ipas"
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Password",
    type: "password",
    defaultValue: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "md",
    icon: "renew",
    onClick: () => {
      setTested(true);
    }
  }, "Test connection"), tested && /*#__PURE__*/React.createElement(StatusDot, {
    kind: "connected"
  }, "Connection successful \xB7 38ms"))));
}

/* ---- ETL DAG ---- */
const DAG_LAYERS = ['RAW', 'Bronze', 'Silver', 'Gold', 'ClickHouse'];
const DAG_NODES = [{
  id: 'n1',
  layer: 0,
  y: 60,
  label: 'ingest_erp',
  status: 'success',
  sub: 'extract · 2m'
}, {
  id: 'n2',
  layer: 0,
  y: 220,
  label: 'ingest_mes',
  status: 'success',
  sub: 'extract · 1m'
}, {
  id: 'n3',
  layer: 1,
  y: 60,
  label: 'clean_erp',
  status: 'success',
  sub: 'dbt · 3m'
}, {
  id: 'n4',
  layer: 1,
  y: 220,
  label: 'clean_mes',
  status: 'running',
  sub: 'dbt · running'
}, {
  id: 'n5',
  layer: 2,
  y: 140,
  label: 'conform_dims',
  status: 'success',
  sub: 'spark · 4m'
}, {
  id: 'n6',
  layer: 3,
  y: 60,
  label: 'fact_production',
  status: 'queued',
  sub: 'dbt · queued'
}, {
  id: 'n7',
  layer: 3,
  y: 220,
  label: 'agg_yield',
  status: 'queued',
  sub: 'dbt · queued'
}, {
  id: 'n8',
  layer: 4,
  y: 140,
  label: 'load_ch',
  status: 'queued',
  sub: 'sync · queued'
}];
const DAG_EDGES = [['n1', 'n3'], ['n2', 'n4'], ['n3', 'n5'], ['n4', 'n5'], ['n5', 'n6'], ['n5', 'n7'], ['n6', 'n8'], ['n7', 'n8']];
const DAG_STATUS_COLOR = {
  success: 'var(--cds-support-success)',
  running: 'var(--cds-blue-60)',
  queued: 'var(--cds-text-placeholder)',
  failed: 'var(--cds-support-error)'
};
const COLW = 170,
  NODEX = l => l * COLW + 15,
  NODEW = 140;
function EtlDag() {
  const [sel, setSel] = React.useState('n6');
  const pos = {};
  DAG_NODES.forEach(n => {
    pos[n.id] = {
      x: NODEX(n.layer),
      y: n.y,
      cx: NODEX(n.layer) + NODEW,
      cy: n.y + 26
    };
  });
  const sn = DAG_NODES.find(n => n.id === sel);
  return /*#__PURE__*/React.createElement("div", {
    className: "dv-dag"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-etoolbar"
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "sm",
    icon: "play",
    style: {
      marginRight: 4
    }
  }, "Run"), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "pause",
    label: "Pause"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "renew",
    label: "Backfill"
  }), /*#__PURE__*/React.createElement("span", {
    className: "gap"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "time",
    label: "Schedule: 0 */2 * * *"
  }), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--out",
    label: "",
    title: "Zoom out"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--in",
    label: "",
    title: "Zoom in"
  })), /*#__PURE__*/React.createElement("div", {
    className: "dv-runstrip"
  }, /*#__PURE__*/React.createElement("span", null, "Recent runs"), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, ['success', 'success', 'failed', 'success', 'success', 'success', 'running'].map((s, i) => /*#__PURE__*/React.createElement("i", {
    key: i,
    style: {
      background: DAG_STATUS_COLOR[s]
    },
    title: s
  }))), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto'
    }
  }, "Last run 14m ago \xB7 avg 11m \xB7 success rate 92%")), /*#__PURE__*/React.createElement("div", {
    className: "dv-dagbody"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-canvas"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-layer-labels"
  }, DAG_LAYERS.map(l => /*#__PURE__*/React.createElement("div", {
    key: l,
    className: "ll"
  }, l))), /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: 460,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("marker", {
    id: "arr",
    markerWidth: "8",
    markerHeight: "8",
    refX: "7",
    refY: "4",
    orient: "auto"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0,0 L8,4 L0,8 z",
    fill: "var(--cds-border-strong-01)"
  }))), DAG_EDGES.map(([a, b], i) => {
    const p = pos[a],
      q = pos[b];
    const mx = (p.cx + q.x) / 2;
    return /*#__PURE__*/React.createElement("path", {
      key: i,
      d: `M ${p.cx} ${p.cy} C ${mx} ${p.cy}, ${mx} ${q.y + 26}, ${q.x} ${q.y + 26}`,
      stroke: "var(--cds-border-strong-01)",
      strokeWidth: "1.5",
      fill: "none",
      markerEnd: "url(#arr)"
    });
  })), DAG_NODES.map(n => /*#__PURE__*/React.createElement("div", {
    key: n.id,
    className: `dv-node ${sel === n.id ? 'sel' : ''}`,
    style: {
      left: pos[n.id].x,
      top: n.y
    },
    onClick: () => setSel(n.id)
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-node__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), n.label, /*#__PURE__*/React.createElement("span", {
    className: "st",
    style: {
      background: DAG_STATUS_COLOR[n.status]
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "dv-node__m"
  }, n.sub)))), /*#__PURE__*/React.createElement("aside", {
    className: "dv-side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-side__h"
  }, "Task \xB7 ", sn.label), /*#__PURE__*/React.createElement("div", {
    className: "dv-side__body"
  }, /*#__PURE__*/React.createElement(StatusDot, {
    kind: sn.status
  }, sn.status[0].toUpperCase() + sn.status.slice(1)), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Parameters"), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "operator"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "dbt_run")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "model"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, sn.label)), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "pool"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "transform")))), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Schedule",
    items: ['Inherit from DAG', '0 */2 * * *', '@daily'],
    value: "Inherit from DAG",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Retries",
    defaultValue: "3"
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Retry delay",
    defaultValue: "5m"
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Upstream dependencies"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "conform_dims"))), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    icon: "document"
  }, "View logs (ELK)")))));
}

/* ---- CDC ---- */
const CONNECTORS = [{
  id: 1,
  name: 'erp-cdc',
  src: 'erp-oracle-prod',
  topic: 'cdc.erp.',
  status: 'Running',
  lag: '120 ms',
  lagKind: 'green'
}, {
  id: 2,
  name: 'mes-cdc',
  src: 'mes-mysql',
  topic: 'cdc.mes.',
  status: 'Running',
  lag: '1.4 s',
  lagKind: 'amber'
}, {
  id: 3,
  name: 'crm-cdc',
  src: 'crm-sqlserver',
  topic: 'cdc.crm.',
  status: 'Failed',
  lag: '— ',
  lagKind: 'red'
}, {
  id: 4,
  name: 'inventory-cdc',
  src: 'erp-oracle-prod',
  topic: 'cdc.inv.',
  status: 'Running',
  lag: '85 ms',
  lagKind: 'green'
}];
function Cdc() {
  const [sel, setSel] = React.useState(CONNECTORS[0]);
  const cols = [{
    key: 'name',
    label: 'Connector',
    cellClass: 'name'
  }, {
    key: 'src',
    label: 'Source DB'
  }, {
    key: 'topic',
    label: 'Topic prefix',
    cellClass: 'mono'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'lag',
    label: 'Watermark lag'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 16,
      alignItems: 'start'
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search connectors",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add"
    }, "New connector")
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: CONNECTORS,
    footer: false,
    onRowClick: setSel,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault()
      }, r.name);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status
      }, r.status);
      if (k === 'lag') return /*#__PURE__*/React.createElement("span", {
        className: "dv-lag"
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          width: 8,
          height: 8,
          borderRadius: '50%',
          background: `var(--cds-support-${r.lagKind === 'green' ? 'success' : r.lagKind === 'amber' ? 'warning' : 'error'})`
        }
      }), r.lag);
      return r[k];
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap",
    style: {
      padding: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-side__h",
    style: {
      borderBottom: '1px solid var(--wire-border)'
    }
  }, "Connector \xB7 ", sel.name), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement(StatusDot, {
    kind: sel.status
  }, sel.status, " \xB7 Debezium 2.5"), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Tables synced (4)"), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv"
  }, ['ORDERS', 'ORDER_LINES', 'CUSTOMERS', 'SHIPMENTS'].map(t => /*#__PURE__*/React.createElement("div", {
    key: t,
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, t), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "snapshot \u2713"))))), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Schema-change retention"), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['7 days', '30 days', '90 days'],
    value: "30 days",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(Toggle, {
    size: "sm",
    label: "Auto-evolve downstream schema",
    defaultChecked: true
  }))));
}

/* ---- Data Quality ---- */
const DQ_RULES = [{
  id: 1,
  target: 'gold.fact_production.yield_pct',
  type: 'Range (0–1)',
  sev: 'High',
  result: 'Pass',
  n: '0 failed'
}, {
  id: 2,
  target: 'silver.orders.order_id',
  type: 'Uniqueness',
  sev: 'High',
  result: 'Pass',
  n: '0 failed'
}, {
  id: 3,
  target: 'silver.orders.customer_id',
  type: 'Not null',
  sev: 'High',
  result: 'Fail',
  n: '142 failed'
}, {
  id: 4,
  target: 'gold.dim_product.sku',
  type: 'Not null',
  sev: 'Medium',
  result: 'Pass',
  n: '0 failed'
}, {
  id: 5,
  target: 'silver.shipments.delivered_at',
  type: 'Custom assertion',
  sev: 'Low',
  result: 'Warn',
  n: '8 stale'
}];
function DataQuality({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const cols = [{
    key: 'target',
    label: 'Target table / field',
    cellClass: 'mono'
  }, {
    key: 'type',
    label: 'Rule type'
  }, {
    key: 'sev',
    label: 'Severity'
  }, {
    key: 'result',
    label: 'Last result'
  }, {
    key: 'n',
    label: 'Rows'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search rules",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setOpen(true)
    }, "Add rule"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: DQ_RULES,
    renderCell: (r, k) => {
      if (k === 'sev') return /*#__PURE__*/React.createElement(Tag, {
        type: r.sev === 'High' ? 'red' : r.sev === 'Medium' ? 'purple' : 'cool-gray',
        size: "sm"
      }, r.sev);
      if (k === 'result') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.result === 'Pass' ? 'success' : r.result === 'Fail' ? 'failed' : 'warning'
      }, r.result);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Data quality",
    title: "Add rule",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Rule added and scheduled.'
        });
      }
    }, "Add rule"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Target table",
    items: ['gold.fact_production', 'silver.orders', 'gold.dim_product'],
    value: "gold.fact_production",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Field",
    items: ['yield_pct', 'units_produced', 'defect_count'],
    value: "yield_pct",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Rule type",
    items: ['Not null', 'Range', 'Uniqueness', 'Custom assertion'],
    value: "Range",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Severity",
    items: ['High', 'Medium', 'Low'],
    value: "High",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Assertion (SQL)"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.8125rem',
      background: 'var(--cds-gray-100)',
      color: '#f4f4f4',
      padding: 12,
      minHeight: 56,
      whiteSpace: 'pre'
    }
  }, 'yield_pct BETWEEN 0 AND 1')), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Alert"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    label: "Notify #data-quality on failure",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Block downstream pipeline on High severity",
    defaultChecked: true
  })))));
}
const PIPELINES = [{
  id: 1,
  name: 'erp_to_gold',
  source: 'erp-oracle-prod',
  target: 'Gold',
  schedule: '0 */2 * * *',
  last: 'Success',
  next: 'in 1h 12m',
  owner: 'L. Marsh'
}, {
  id: 2,
  name: 'mes_stream',
  source: 'events-kafka',
  target: 'Silver',
  schedule: 'streaming',
  last: 'Running',
  next: '—',
  owner: 'M. Díaz'
}, {
  id: 3,
  name: 'crm_sync',
  source: 'crm-sqlserver',
  target: 'Bronze',
  schedule: '*/15 * * * *',
  last: 'Failed',
  next: 'in 4m',
  owner: 'A. Okafor'
}, {
  id: 4,
  name: 'finance_daily',
  source: 'erp-oracle-prod',
  target: 'Gold',
  schedule: '0 6 * * *',
  last: 'Success',
  next: 'in 18h',
  owner: 'A. Okafor'
}, {
  id: 5,
  name: 'logistics_etl',
  source: 'mes-mysql',
  target: 'Gold',
  schedule: '0 */4 * * *',
  last: 'Success',
  next: 'in 2h',
  owner: 'R. Vance'
}];
const WIZ_STEPS = [{
  t: 'Source',
  s: 'Connection'
}, {
  t: 'Tables',
  s: 'Select'
}, {
  t: 'Target',
  s: 'Layer & format'
}, {
  t: 'Schedule',
  s: 'Cron / interval'
}, {
  t: 'Transform',
  s: 'CDC / batch'
}, {
  t: 'Review',
  s: 'Create'
}];
function PipelineWizard({
  onClose,
  notify
}) {
  const [step, setStep] = React.useState(0);
  const last = step === WIZ_STEPS.length - 1;
  return /*#__PURE__*/React.createElement(Modal, {
    sup: "Pipelines",
    title: "Create pipeline",
    size: "lg",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: step === 0 ? onClose : () => setStep(step - 1)
    }, step === 0 ? 'Cancel' : 'Back'), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: last ? 'checkmark' : 'arrow--right',
      onClick: last ? () => {
        onClose();
        notify && notify({
          kind: 'success',
          title: 'Pipeline created.',
          subtitle: 'First run scheduled.'
        });
      } : () => setStep(step + 1)
    }, last ? 'Create pipeline' : 'Next'))
  }, /*#__PURE__*/React.createElement(Stepper, {
    steps: WIZ_STEPS,
    current: step,
    onStep: setStep
  }), step === 0 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Source connection",
    items: ['erp-oracle-prod', 'mes-mysql', 'crm-sqlserver', 'events-kafka'],
    value: "erp-oracle-prod",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Pipeline name",
    placeholder: "erp_to_gold"
  })), step === 1 && /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Tables to ingest"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, ['ORDERS', 'ORDER_LINES', 'CUSTOMERS', 'SHIPMENTS', 'PRODUCTS'].map((tb, i) => /*#__PURE__*/React.createElement(Checkbox, {
    key: tb,
    label: tb,
    defaultChecked: i < 3
  })))), step === 2 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Target layer",
    items: ['RAW', 'Bronze', 'Silver', 'Gold'],
    value: "Gold",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Format",
    items: ['Iceberg', 'Delta', 'Parquet'],
    value: "Iceberg",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Target namespace",
    defaultValue: "gold.manufacturing"
  })), step === 3 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Trigger",
    items: ['Cron schedule', 'Fixed interval', 'On source change (CDC)'],
    value: "Cron schedule",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Cron expression",
    defaultValue: "0 */2 * * *",
    helperText: "Every 2 hours."
  })), step === 4 && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Load mode",
    items: ['CDC (incremental)', 'Full batch', 'Append only'],
    value: "CDC (incremental)",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Deduplicate on primary key",
    defaultChecked: true
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Run data quality rules after load",
    defaultChecked: true
  })), step === 5 && /*#__PURE__*/React.createElement("div", {
    className: "dv-kv"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Name"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "erp_to_gold")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Source"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "erp-oracle-prod")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Tables"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "3 selected")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Target"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "gold.manufacturing \xB7 Iceberg")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Schedule"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "0 */2 * * *")), /*#__PURE__*/React.createElement("div", {
    className: "dv-kv__r"
  }, /*#__PURE__*/React.createElement("span", {
    className: "k"
  }, "Mode"), /*#__PURE__*/React.createElement("span", {
    className: "v"
  }, "CDC (incremental)"))));
}
function PipelineDetail({
  pipe,
  onBack,
  notify
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "sm",
    icon: "arrow--left",
    onClick: onBack,
    style: {
      marginBottom: 12
    }
  }, "Back to pipelines"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-start',
      gap: 16,
      marginBottom: 20,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: '1.5rem',
      fontWeight: 400,
      margin: 0,
      fontFamily: 'var(--cds-font-mono)'
    }
  }, pipe.name), /*#__PURE__*/React.createElement(StatusDot, {
    kind: pipe.last
  }, pipe.last)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cds-text-secondary)',
      fontSize: '.875rem',
      margin: '8px 0 0'
    }
  }, pipe.source, " \u2192 ", pipe.target, " \xB7 ", pipe.schedule, " \xB7 owner ", pipe.owner)), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 1
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "md",
    icon: "play",
    onClick: () => notify && notify({
      kind: 'success',
      title: 'Run started.',
      subtitle: pipe.name
    })
  }, "Run now"), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "md",
    icon: "pause"
  }, "Pause"), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "md",
    icon: "calendar"
  }, "Backfill"), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "md",
    icon: "stop"
  }, "Stop"))), /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      label: 'Overview',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement("div", {
        className: "dv-kv",
        style: {
          maxWidth: 520
        }
      }, /*#__PURE__*/React.createElement("div", {
        className: "dv-kv__r"
      }, /*#__PURE__*/React.createElement("span", {
        className: "k"
      }, "Status"), /*#__PURE__*/React.createElement("span", {
        className: "v"
      }, pipe.last)), /*#__PURE__*/React.createElement("div", {
        className: "dv-kv__r"
      }, /*#__PURE__*/React.createElement("span", {
        className: "k"
      }, "Next run"), /*#__PURE__*/React.createElement("span", {
        className: "v"
      }, pipe.next)), /*#__PURE__*/React.createElement("div", {
        className: "dv-kv__r"
      }, /*#__PURE__*/React.createElement("span", {
        className: "k"
      }, "Avg duration"), /*#__PURE__*/React.createElement("span", {
        className: "v"
      }, "11m 04s")), /*#__PURE__*/React.createElement("div", {
        className: "dv-kv__r"
      }, /*#__PURE__*/React.createElement("span", {
        className: "k"
      }, "Success rate (30d)"), /*#__PURE__*/React.createElement("span", {
        className: "v"
      }, "92%"))))
    }, {
      label: 'DAG',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(EtlDag, null))
    }, {
      label: 'Run history',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        },
        className: "w-tblwrap"
      }, /*#__PURE__*/React.createElement(WireTable, {
        footer: false,
        columns: [{
          key: 'start',
          label: 'Started'
        }, {
          key: 'dur',
          label: 'Duration'
        }, {
          key: 'status',
          label: 'Status'
        }, {
          key: 'by',
          label: 'Triggered by'
        }, {
          key: 'act',
          label: '',
          sortable: false,
          width: 48
        }],
        rows: [{
          start: 'Today 14:32',
          dur: '11m 04s',
          status: 'Success',
          by: 'schedule'
        }, {
          start: 'Today 12:30',
          dur: '10m 51s',
          status: 'Success',
          by: 'schedule'
        }, {
          start: 'Today 10:30',
          dur: '1m 02s',
          status: 'Failed',
          by: 'schedule'
        }, {
          start: 'Today 08:30',
          dur: '12m 18s',
          status: 'Success',
          by: 'L. Marsh'
        }],
        renderCell: (r, k) => k === 'status' ? /*#__PURE__*/React.createElement(StatusDot, {
          kind: r.status
        }, r.status) : k === 'act' ? /*#__PURE__*/React.createElement(Overflow, null) : r[k]
      }))
    }, {
      label: 'Config',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8,
          maxWidth: 520,
          display: 'flex',
          flexDirection: 'column',
          gap: 16
        }
      }, /*#__PURE__*/React.createElement(TextInput, {
        label: "Schedule (cron)",
        defaultValue: pipe.schedule
      }), /*#__PURE__*/React.createElement(Dropdown, {
        label: "Load mode",
        items: ['CDC (incremental)', 'Full batch'],
        value: "CDC (incremental)",
        onChange: () => {}
      }), /*#__PURE__*/React.createElement(Toggle, {
        size: "sm",
        label: "Run data quality after load",
        defaultChecked: true
      }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
        kind: "primary",
        icon: "save",
        onClick: () => notify && notify({
          kind: 'success',
          title: 'Config saved.'
        })
      }, "Save config")))
    }, {
      label: 'Lineage',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(Placeholder, {
        label: "end-to-end lineage RAW \u2192 Gold \u2192 ClickHouse",
        icon: "data--base",
        height: 260
      }))
    }]
  }));
}
function Pipelines({
  notify
}) {
  const [wiz, setWiz] = React.useState(false);
  const [sel, setSel] = React.useState(null);
  const cols = [{
    key: 'name',
    label: 'Pipeline',
    cellClass: 'name'
  }, {
    key: 'source',
    label: 'Source'
  }, {
    key: 'target',
    label: 'Target layer'
  }, {
    key: 'schedule',
    label: 'Schedule',
    cellClass: 'mono'
  }, {
    key: 'last',
    label: 'Last run'
  }, {
    key: 'next',
    label: 'Next run'
  }, {
    key: 'owner',
    label: 'Owner'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  if (sel) return /*#__PURE__*/React.createElement(PipelineDetail, {
    pipe: sel,
    onBack: () => setSel(null),
    notify: notify
  });
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search pipelines",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setWiz(true)
    }, "Create pipeline"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: PIPELINES,
    onRowClick: setSel,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => {
          e.preventDefault();
          setSel(r);
        }
      }, r.name);
      if (k === 'target') return /*#__PURE__*/React.createElement(Tag, {
        type: r.target === 'Gold' ? 'teal' : r.target === 'Silver' ? 'cyan' : 'cool-gray',
        size: "sm"
      }, r.target);
      if (k === 'last') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.last
      }, r.last);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), wiz && /*#__PURE__*/React.createElement(PipelineWizard, {
    onClose: () => setWiz(false),
    notify: notify
  }));
}
const DEV_SUBS = [{
  id: 'pipelines',
  label: 'Pipelines'
}, {
  id: 'sources',
  label: 'Data sources'
}, {
  id: 'etl',
  label: 'ETL / DAG'
}, {
  id: 'cdc',
  label: 'CDC / sync'
}, {
  id: 'quality',
  label: 'Data quality'
}];
const DEV_TITLES = {
  pipelines: ['Pipelines', 'Unified ingest-to-serve data pipelines across all layers.'],
  sources: ['Data source management', 'Registered database, lakehouse, and streaming connections.'],
  etl: ['ETL pipeline orchestration', 'Layered RAW → Bronze → Silver → Gold → ClickHouse DAG.'],
  cdc: ['CDC / sync configuration', 'Debezium change-data-capture connectors and watermarks.'],
  quality: ['Data quality rules', 'Assertions on tables and fields with severity and alerting.']
};
function DevConfig({
  notify,
  lang
}) {
  const [sub, setSub] = React.useState('pipelines');
  const [t, s] = DEV_TITLES[sub];
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Data Development / Config', t].map(c => tr(lang, c)),
    title: tr(lang, t),
    sub: tr(lang, s)
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, DEV_SUBS),
    value: sub,
    onChange: setSub
  }), sub === 'pipelines' && /*#__PURE__*/React.createElement(Pipelines, {
    notify: notify
  }), sub === 'sources' && /*#__PURE__*/React.createElement(DataSources, {
    notify: notify
  }), sub === 'etl' && /*#__PURE__*/React.createElement(EtlDag, null), sub === 'cdc' && /*#__PURE__*/React.createElement(Cdc, null), sub === 'quality' && /*#__PURE__*/React.createElement(DataQuality, {
    notify: notify
  }));
}
Object.assign(window, {
  DevConfig
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/DevConfig.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Governance.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, SidePanel, Placeholder, StatusDot, ToolBtn, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown,
  Checkbox,
  Tabs
} = window.CarbonDesignSystem_280d33;
const GOV_CSS = `
.gv-catalog { display:grid; grid-template-columns:240px 1fr; gap:16px; align-items:start; }
.gv-facets { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.gv-facets__grp { padding:12px 16px; border-bottom:1px solid var(--wire-border); }
.gv-facets__grp:last-child { border-bottom:none; }
.gv-facets__grp h4 { font-size:.75rem; font-weight:600; margin:0 0 10px; color:var(--cds-text-primary); display:flex; align-items:center; }
.gv-facets__grp h4 .c { margin-left:auto; font-weight:400; color:var(--cds-text-secondary); }
.gv-facets__opt { display:flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-secondary); padding:4px 0; }
.gv-score { display:inline-flex; align-items:center; gap:6px; font-size:.8125rem; }
.gv-score .track { width:48px; height:6px; background:var(--cds-layer-01); position:relative; }
.gv-score .track i { position:absolute; left:0; top:0; bottom:0; }
.gv-layerchip { font-family:var(--cds-font-mono); font-size:.6875rem; }

/* asset detail */
.gv-detail__top { display:flex; align-items:flex-start; gap:24px; margin-bottom:24px; }
.gv-detail__stats { display:flex; gap:32px; margin-left:auto; }
.gv-detail__stats .s .v { font-size:1.5rem; font-weight:300; color:var(--cds-text-primary); }
.gv-detail__stats .s .k { font-size:.75rem; color:var(--cds-text-secondary); }

/* lineage */
.gv-lin { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.gv-lincanvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.gv-linnode { position:absolute; width:150px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); cursor:pointer; }
.gv-linnode.sel { border:1px solid var(--cds-border-interactive); box-shadow:0 0 0 1px var(--cds-border-interactive); }
.gv-linnode__h { display:flex; align-items:center; gap:6px; padding:8px 10px; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); border-bottom:1px solid var(--wire-border); }
.gv-linnode__f { padding:4px 10px; font-size:.6875rem; font-family:var(--cds-font-mono); color:var(--cds-text-secondary); border-bottom:1px solid var(--wire-border); display:flex; align-items:center; gap:6px; }
.gv-linnode__f:last-child { border-bottom:none; }
.gv-linnode__f .exp { margin-left:auto; color:var(--cds-link-primary); cursor:pointer; }

/* access matrix */
.gv-matrix { width:100%; border-collapse:collapse; font-family:var(--cds-font-sans); border:1px solid var(--wire-border); }
.gv-matrix th, .gv-matrix td { border:1px solid var(--wire-border); padding:8px 12px; font-size:.8125rem; text-align:center; }
.gv-matrix th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.gv-matrix td:first-child, .gv-matrix th:first-child { text-align:left; }
.gv-matrix td.col { color:var(--cds-text-primary); font-weight:500; }
.gv-iam { display:inline-flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-secondary); background:var(--cds-layer-01); border:1px solid var(--wire-border); padding:6px 12px; }
`;
(function () {
  if (!document.getElementById('ipas-gov-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-gov-styles';
    e.textContent = GOV_CSS;
    document.head.appendChild(e);
  }
})();
const ASSETS = [{
  id: 1,
  name: 'fact_production',
  layer: 'Gold',
  desc: 'Production events by line, shift, and product',
  owner: 'L. Marsh',
  score: 96,
  sens: 'Internal'
}, {
  id: 2,
  name: 'orders',
  layer: 'Silver',
  desc: 'Cleaned customer orders from ERP',
  owner: 'A. Okafor',
  score: 88,
  sens: 'Confidential'
}, {
  id: 3,
  name: 'customers',
  layer: 'Silver',
  desc: 'Customer master with contact details',
  owner: 'A. Okafor',
  score: 74,
  sens: 'PII'
}, {
  id: 4,
  name: 'raw_mes_events',
  layer: 'RAW',
  desc: 'Unprocessed MES machine telemetry',
  owner: 'M. Díaz',
  score: 61,
  sens: 'Internal'
}, {
  id: 5,
  name: 'dim_product',
  layer: 'Gold',
  desc: 'Conformed product dimension',
  owner: 'L. Marsh',
  score: 93,
  sens: 'Public'
}, {
  id: 6,
  name: 'agg_yield_daily',
  layer: 'Gold',
  desc: 'Daily yield aggregates for dashboards',
  owner: 'R. Vance',
  score: 90,
  sens: 'Internal'
}];
const LAYER_TAG = {
  RAW: 'cool-gray',
  Bronze: 'cool-gray',
  Silver: 'cyan',
  Gold: 'teal'
};
const SENS_TAG = {
  PII: 'red',
  Confidential: 'purple',
  Internal: 'blue',
  Public: 'green'
};
function ScoreBar({
  v
}) {
  const color = v >= 90 ? 'var(--cds-support-success)' : v >= 75 ? 'var(--cds-support-warning)' : 'var(--cds-support-error)';
  return /*#__PURE__*/React.createElement("span", {
    className: "gv-score"
  }, /*#__PURE__*/React.createElement("span", {
    className: "track"
  }, /*#__PURE__*/React.createElement("i", {
    style: {
      width: v + '%',
      background: color
    }
  })), v);
}
function Facet({
  title,
  count,
  opts
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "gv-facets__grp"
  }, /*#__PURE__*/React.createElement("h4", null, title, /*#__PURE__*/React.createElement("span", {
    className: "c"
  }, count)), opts.map(o => /*#__PURE__*/React.createElement("label", {
    key: o.l,
    className: "gv-facets__opt"
  }, /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: o.on,
    label: ""
  }), o.l, /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: 'var(--cds-text-placeholder)',
      fontSize: '.6875rem'
    }
  }, o.n))));
}
function Catalog({
  onOpen
}) {
  const cols = [{
    key: 'name',
    label: 'Asset',
    cellClass: 'name'
  }, {
    key: 'layer',
    label: 'Layer'
  }, {
    key: 'desc',
    label: 'Description'
  }, {
    key: 'owner',
    label: 'Owner'
  }, {
    key: 'score',
    label: 'Quality'
  }, {
    key: 'sens',
    label: 'Sensitivity'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "gv-catalog"
  }, /*#__PURE__*/React.createElement("aside", {
    className: "gv-facets"
  }, /*#__PURE__*/React.createElement(Facet, {
    title: "Domain",
    count: "",
    opts: [{
      l: 'Manufacturing',
      n: 42,
      on: true
    }, {
      l: 'Finance',
      n: 18
    }, {
      l: 'Logistics',
      n: 23
    }, {
      l: 'Customer',
      n: 11
    }]
  }), /*#__PURE__*/React.createElement(Facet, {
    title: "Source layer",
    count: "",
    opts: [{
      l: 'RAW',
      n: 64
    }, {
      l: 'Bronze',
      n: 52
    }, {
      l: 'Silver',
      n: 38,
      on: true
    }, {
      l: 'Gold',
      n: 26,
      on: true
    }]
  }), /*#__PURE__*/React.createElement(Facet, {
    title: "Sensitivity",
    count: "",
    opts: [{
      l: 'Public',
      n: 12
    }, {
      l: 'Internal',
      n: 88
    }, {
      l: 'Confidential',
      n: 21
    }, {
      l: 'PII',
      n: 9
    }]
  }), /*#__PURE__*/React.createElement(Facet, {
    title: "Owner",
    count: "",
    opts: [{
      l: 'L. Marsh',
      n: 14
    }, {
      l: 'A. Okafor',
      n: 9
    }, {
      l: 'R. Vance',
      n: 7
    }]
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Search, {
    size: "lg",
    placeholder: "Search the catalog \u2014 tables, fields, descriptions"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm",
    filter: true,
    onClose: () => {}
  }, "layer: Silver"), /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm",
    filter: true,
    onClose: () => {}
  }, "layer: Gold"), /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm",
    filter: true,
    onClose: () => {}
  }, "domain: Manufacturing"), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)'
    }
  }, "186 assets")), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: ASSETS,
    total: 186,
    onRowClick: onOpen,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => {
          e.preventDefault();
        }
      }, r.name);
      if (k === 'layer') return /*#__PURE__*/React.createElement(Tag, {
        type: LAYER_TAG[r.layer],
        size: "sm"
      }, /*#__PURE__*/React.createElement("span", {
        className: "gv-layerchip"
      }, r.layer));
      if (k === 'desc') return /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'block',
          maxWidth: 260,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }
      }, r.desc);
      if (k === 'score') return /*#__PURE__*/React.createElement(ScoreBar, {
        v: r.score
      });
      if (k === 'sens') return /*#__PURE__*/React.createElement(Tag, {
        type: SENS_TAG[r.sens],
        size: "sm"
      }, r.sens);
      return r[k];
    }
  })));
}
function AssetDetail({
  asset,
  onBack
}) {
  const schemaCols = [{
    key: 'col',
    label: 'Column',
    cellClass: 'mono'
  }, {
    key: 'type',
    label: 'Type'
  }, {
    key: 'desc',
    label: 'Description'
  }, {
    key: 'sens',
    label: 'Sensitivity',
    sortable: false
  }];
  const schema = [{
    col: 'line_id',
    type: 'varchar',
    desc: 'Production line identifier',
    sens: 'Internal'
  }, {
    col: 'shift',
    type: 'varchar',
    desc: 'Shift name (Day/Night)',
    sens: 'Internal'
  }, {
    col: 'units_produced',
    type: 'bigint',
    desc: 'Units produced in window',
    sens: 'Internal'
  }, {
    col: 'defect_count',
    type: 'bigint',
    desc: 'Defective units',
    sens: 'Internal'
  }, {
    col: 'yield_pct',
    type: 'double',
    desc: 'First-pass yield',
    sens: 'Internal'
  }];
  const sampleCols = schema.slice(0, 4).map(s => ({
    key: s.col,
    label: s.col,
    sortable: false
  }));
  const sample = [{
    line_id: 'LINE-04',
    shift: 'Day',
    units_produced: '12,480',
    defect_count: '142'
  }, {
    line_id: 'LINE-02',
    shift: 'Night',
    units_produced: '9,310',
    defect_count: '88'
  }, {
    line_id: 'LINE-05',
    shift: 'Day',
    units_produced: '11,002',
    defect_count: '203'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "sm",
    icon: "arrow--left",
    onClick: onBack,
    style: {
      marginBottom: 12
    }
  }, "Back to catalog"), /*#__PURE__*/React.createElement("div", {
    className: "gv-detail__top"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: '1.75rem',
      fontWeight: 400,
      margin: 0,
      fontFamily: 'var(--cds-font-mono)'
    }
  }, asset.name), /*#__PURE__*/React.createElement(Tag, {
    type: LAYER_TAG[asset.layer],
    size: "md"
  }, asset.layer), /*#__PURE__*/React.createElement(Tag, {
    type: SENS_TAG[asset.sens],
    size: "md"
  }, asset.sens)), /*#__PURE__*/React.createElement("p", {
    style: {
      color: 'var(--cds-text-secondary)',
      fontSize: '.875rem',
      margin: '8px 0 0'
    }
  }, asset.desc, " \xB7 Owner ", asset.owner)), /*#__PURE__*/React.createElement("div", {
    className: "gv-detail__stats"
  }, /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, asset.score), /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, "Quality score")), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, "38"), /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, "Downstream")), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, "1.2k"), /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, "Queries / wk")))), /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      label: 'Schema',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(WireTable, {
        columns: schemaCols,
        rows: schema,
        footer: false,
        renderCell: (r, k) => k === 'sens' ? /*#__PURE__*/React.createElement(Tag, {
          type: "blue",
          size: "sm"
        }, r.sens) : r[k]
      }))
    }, {
      label: 'Sample data',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(WireTable, {
        columns: sampleCols,
        rows: sample,
        footer: false,
        renderCell: (r, k) => /*#__PURE__*/React.createElement("span", {
          style: {
            fontFamily: 'var(--cds-font-mono)',
            fontSize: '.8125rem'
          }
        }, r[k])
      }))
    }, {
      label: 'Lineage',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(Placeholder, {
        label: "upstream / downstream lineage graph",
        icon: "data--base",
        height: 280
      }))
    }, {
      label: 'Usage',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(Placeholder, {
        label: "queries over time \xB7 top consumers",
        icon: "analytics",
        height: 280
      }))
    }]
  }));
}

/* ---- Lineage graph ---- */
const LIN_LAYERS = ['RAW', 'Bronze', 'Silver', 'Gold', 'ClickHouse'];
const LIN_NODES = [{
  id: 'l1',
  layer: 0,
  y: 120,
  label: 'raw_mes_events',
  fields: ['event_ts', 'machine_id', 'payload']
}, {
  id: 'l2',
  layer: 1,
  y: 120,
  label: 'mes_clean',
  fields: ['ts', 'line_id', 'metric']
}, {
  id: 'l3',
  layer: 2,
  y: 60,
  label: 'orders',
  fields: ['order_id', 'customer_id']
}, {
  id: 'l4',
  layer: 2,
  y: 240,
  label: 'production',
  fields: ['line_id', 'units', 'defects']
}, {
  id: 'l5',
  layer: 3,
  y: 150,
  label: 'fact_production',
  fields: ['line_id', 'yield_pct', 'units_produced']
}, {
  id: 'l6',
  layer: 4,
  y: 150,
  label: 'ch.agg_yield',
  fields: ['line_id', 'avg_yield']
}];
const LIN_EDGES = [['l1', 'l2'], ['l2', 'l4'], ['l3', 'l5'], ['l4', 'l5'], ['l5', 'l6']];
const LINW = 150,
  LINCOLW = 200,
  LINX = l => l * LINCOLW + 24;
function LineageGraph() {
  const [sel, setSel] = React.useState('l5');
  const pos = {};
  LIN_NODES.forEach(n => {
    pos[n.id] = {
      x: LINX(n.layer),
      y: n.y,
      cx: LINX(n.layer) + LINW,
      cyc: n.y + 20
    };
  });
  const sn = LIN_NODES.find(n => n.id === sel);
  const [drawer, setDrawer] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    className: "gv-lin"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-etoolbar"
  }, /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "search",
    label: "Find asset"
  }), /*#__PURE__*/React.createElement("span", {
    className: "gap"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "add",
    label: "Expand all fields"
  }), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--out",
    label: "",
    title: "Zoom out"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--in",
    label: "",
    title: "Zoom in"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "maximize",
    label: "",
    title: "Fit"
  })), /*#__PURE__*/React.createElement("div", {
    className: "gv-lincanvas"
  }, /*#__PURE__*/React.createElement("div", {
    className: "dv-layer-labels"
  }, LIN_LAYERS.map(l => /*#__PURE__*/React.createElement("div", {
    key: l,
    className: "ll",
    style: {
      width: LINCOLW
    }
  }, l))), /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: 460,
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("marker", {
    id: "larr",
    markerWidth: "8",
    markerHeight: "8",
    refX: "7",
    refY: "4",
    orient: "auto"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M0,0 L8,4 L0,8 z",
    fill: "var(--cds-blue-60)"
  }))), LIN_EDGES.map(([a, b], i) => {
    const p = pos[a],
      q = pos[b];
    const mx = (p.cx + q.x) / 2;
    return /*#__PURE__*/React.createElement("path", {
      key: i,
      d: `M ${p.cx} ${p.cyc} C ${mx} ${p.cyc}, ${mx} ${q.cyc}, ${q.x} ${q.cyc}`,
      stroke: "var(--cds-blue-60)",
      strokeWidth: "1.5",
      fill: "none",
      markerEnd: "url(#larr)"
    });
  })), LIN_NODES.map(n => /*#__PURE__*/React.createElement("div", {
    key: n.id,
    className: `gv-linnode ${sel === n.id ? 'sel' : ''}`,
    style: {
      left: pos[n.id].x,
      top: n.y
    },
    onClick: () => {
      setSel(n.id);
      setDrawer(true);
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "gv-linnode__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), n.label), n.fields.map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    className: "gv-linnode__f"
  }, f, /*#__PURE__*/React.createElement("span", {
    className: "exp"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--right",
    size: 16
  }))))))), drawer && /*#__PURE__*/React.createElement(SidePanel, {
    sup: "Lineage",
    title: sn.label,
    width: 360,
    onClose: () => setDrawer(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setDrawer(false)
    }, "Close"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "launch"
    }, "Open asset"))
  }, /*#__PURE__*/React.createElement(StatusDot, {
    kind: "success"
  }, "Fresh \xB7 updated 14m ago"), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Fields (", sn.fields.length, ")"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, sn.fields.map(f => /*#__PURE__*/React.createElement("div", {
    key: f,
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.75rem',
      color: 'var(--cds-text-primary)',
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--right",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }), f)))), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Upstream"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "orders"), /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "production"))), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Downstream"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "ch.agg_yield"), /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "3 dashboards")))));
}

/* ---- Access Control (RBAC + ABAC) ---- */
const MASK_PREVIEW = {
  deny: 'NULL',
  full: '••••••••',
  partial: 'WF••••1234',
  hash: 'a3f9c2e1b7'
};
const MASK_DESC = {
  deny: 'Column-level — value returned as NULL',
  full: 'Field-level — fully masked',
  partial: 'Field-level — show first/last N characters',
  hash: 'Field-level — deterministic hash'
};
function RoleModal({
  onClose,
  notify
}) {
  const modules = ['Analytics', 'Modeling', 'Pipelines', 'Catalog', 'Governance', 'Monitoring', 'Admin'];
  const actions = ['View', 'Create', 'Edit', 'Delete', 'Admin'];
  return /*#__PURE__*/React.createElement(Modal, {
    sup: "RBAC",
    title: "Create role",
    size: "lg",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        onClose();
        notify && notify({
          kind: 'success',
          title: 'Role created.'
        });
      }
    }, "Create role"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Role name",
    placeholder: "Factory Analyst"
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Mapped Keycloak group",
    items: ['/ipas/analysts', '/ipas/engineers', '/ipas/stewards', '/ipas/viewers'],
    value: "/ipas/analysts",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Feature-permission matrix"), /*#__PURE__*/React.createElement("table", {
    className: "w-permgrid"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Module"), actions.map(a => /*#__PURE__*/React.createElement("th", {
    key: a
  }, a)))), /*#__PURE__*/React.createElement("tbody", null, modules.map((m, mi) => /*#__PURE__*/React.createElement("tr", {
    key: m
  }, /*#__PURE__*/React.createElement("td", null, m), actions.map((a, ai) => /*#__PURE__*/React.createElement("td", {
    key: a
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: ai === 0 || ai === 1 && mi < 4
  })))))))), /*#__PURE__*/React.createElement(TextInput, {
    label: "Description",
    placeholder: "What this role is for"
  }));
}
function RowPolicyModal({
  onClose,
  notify
}) {
  return /*#__PURE__*/React.createElement(Modal, {
    sup: "ABAC \xB7 Row-level",
    title: "Create row policy",
    size: "lg",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        onClose();
        notify && notify({
          kind: 'success',
          title: 'Row policy saved & enabled.'
        });
      }
    }, "Save policy"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Subject (role / group)",
    items: ['Factory Analyst', 'Analyst', 'Viewer', 'Steward'],
    value: "Factory Analyst",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Catalog",
    items: ['gold', 'silver', 'bronze'],
    value: "gold",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Schema",
    items: ['manufacturing', 'sales', 'logistics'],
    value: "manufacturing",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Table",
    items: ['spc_xbar_r_chart', 'fact_production', 'agg_yield'],
    value: "spc_xbar_r_chart",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Row filter \u2014 condition builder"), /*#__PURE__*/React.createElement(ConditionBuilder, {
    fields: ['process_id', 'plant', 'shift', 'region']
  })));
}
function MaskModal({
  onClose,
  notify
}) {
  const [mask, setMask] = React.useState('partial');
  return /*#__PURE__*/React.createElement(Modal, {
    sup: "ABAC \xB7 Masking",
    title: "Create masking policy",
    size: "lg",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: onClose
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        onClose();
        notify && notify({
          kind: 'success',
          title: 'Masking policy saved.'
        });
      }
    }, "Save policy"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Subject (role / group)",
    items: ['Viewer', 'Analyst', 'Factory Analyst'],
    value: "Viewer",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Table",
    items: ['silver.customers', 'silver.orders', 'gold.fact_production'],
    value: "silver.customers",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Column",
    items: ['wafer_id', 'email', 'ssn', 'phone'],
    value: "wafer_id",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Mask type",
    items: ['deny', 'full', 'partial', 'hash'],
    value: mask,
    onChange: setMask
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)'
    }
  }, MASK_DESC[mask]), mask === 'partial' && /*#__PURE__*/React.createElement(TextInput, {
    label: "Show expression template",
    defaultValue: "WF****1234",
    helperText: "Use * for masked positions."
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Live preview"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.6875rem',
      color: 'var(--cds-text-secondary)',
      marginBottom: 4
    }
  }, "Original"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.8125rem',
      background: 'var(--cds-layer-01)',
      border: '1px solid var(--wire-border)',
      padding: '8px 12px'
    }
  }, "WF00481234")), /*#__PURE__*/React.createElement(Icon, {
    name: "arrow--right",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.6875rem',
      color: 'var(--cds-text-secondary)',
      marginBottom: 4
    }
  }, "Masked as seen by subject"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.8125rem',
      background: 'var(--cds-gray-100)',
      color: '#f4f4f4',
      padding: '8px 12px'
    }
  }, MASK_PREVIEW[mask])))));
}
function PreviewAsUser({
  onClose
}) {
  const [ran, setRan] = React.useState(false);
  const cols = [{
    key: 'process_id',
    label: 'process_id'
  }, {
    key: 'wafer_id',
    label: 'wafer_id'
  }, {
    key: 'yield',
    label: 'yield_pct'
  }, {
    key: 'region',
    label: 'region'
  }];
  const original = [{
    process_id: 'P1',
    wafer_id: 'WF00481234',
    yield: '0.962',
    region: 'APAC'
  }, {
    process_id: 'P2',
    wafer_id: 'WF00485511',
    yield: '0.948',
    region: 'APAC'
  }, {
    process_id: 'P3',
    wafer_id: 'WF00490027',
    yield: '0.911',
    region: 'EMEA'
  }, {
    process_id: 'P5',
    wafer_id: 'WF00492210',
    yield: '0.933',
    region: 'AMER'
  }];
  // effective for "Factory Analyst": row filter process_id IN (P1,P2) + wafer_id partial mask
  const effective = original.filter(r => ['P1', 'P2'].includes(r.process_id)).map(r => ({
    ...r,
    wafer_id: 'WF****' + r.wafer_id.slice(-4)
  }));
  return /*#__PURE__*/React.createElement(Modal, {
    sup: "Policy simulation",
    title: "Preview as user",
    size: "lg",
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: onClose
    }, "Close")
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Preview as",
    items: ['Factory Analyst (role)', 'Ade Okafor (Analyst)', 'Mara Díaz (Viewer)'],
    value: "Factory Analyst (role)",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Table",
    items: ['gold.spc_xbar_r_chart', 'silver.customers'],
    value: "gold.spc_xbar_r_chart",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "md",
    icon: "play",
    onClick: () => setRan(true)
  }, "Run sample query"), ran && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)'
    }
  }, "Applied: row filter ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: 'var(--cds-font-mono)'
    }
  }, "process_id IN ('P1','P2')"), " \xB7 partial mask on ", /*#__PURE__*/React.createElement("code", {
    style: {
      fontFamily: 'var(--cds-font-mono)'
    }
  }, "wafer_id")), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Original result (", original.length, " rows)"), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: original,
    footer: false,
    renderCell: (r, k) => /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--cds-font-mono)',
        fontSize: '.8125rem'
      }
    }, r[k])
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Effective result for subject (", effective.length, " rows)"), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: effective,
    footer: false,
    renderCell: (r, k) => /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--cds-font-mono)',
        fontSize: '.8125rem',
        color: k === 'wafer_id' ? 'var(--cds-text-placeholder)' : 'inherit'
      }
    }, r[k])
  }))));
}
function AccessControl({
  notify
}) {
  const [modal, setModal] = React.useState(null); // role | rowpolicy | mask | preview
  const roleCols = [{
    key: 'role',
    label: 'Role',
    cellClass: 'name'
  }, {
    key: 'group',
    label: 'Keycloak group',
    cellClass: 'mono'
  }, {
    key: 'members',
    label: 'Members'
  }, {
    key: 'perms',
    label: 'Page permissions'
  }, {
    key: 'model',
    label: 'Model'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  const roles = [{
    role: 'Data Engineer',
    group: '/ipas/engineers',
    members: '12',
    perms: 'All modules · write Bronze→Gold',
    model: 'RBAC'
  }, {
    role: 'Factory Analyst',
    group: '/ipas/analysts',
    members: '34',
    perms: 'Analytics, Catalog · read Gold',
    model: 'ABAC'
  }, {
    role: 'Steward',
    group: '/ipas/stewards',
    members: '6',
    perms: 'Catalog, Governance · policies',
    model: 'ABAC'
  }, {
    role: 'Viewer',
    group: '/ipas/viewers',
    members: '88',
    perms: 'Dashboards · read only',
    model: 'RBAC'
  }];
  const rowPolicies = [{
    subject: 'Factory Analyst',
    table: 'gold.spc_xbar_r_chart',
    filter: "process_id IN ('P1','P2')",
    enabled: true
  }, {
    subject: 'Analyst',
    table: 'silver.orders',
    filter: 'region = user.region',
    enabled: true
  }, {
    subject: 'Viewer',
    table: 'gold.fact_production',
    filter: 'aggregated rows only',
    enabled: false
  }];
  const masks = [{
    subject: 'Viewer',
    table: 'silver.customers',
    col: 'wafer_id',
    type: 'partial',
    status: 'Active'
  }, {
    subject: 'Analyst',
    table: 'silver.customers',
    col: 'ssn',
    type: 'full',
    status: 'Active'
  }, {
    subject: 'Analyst',
    table: 'silver.orders',
    col: 'customer_id',
    type: 'hash',
    status: 'Active'
  }, {
    subject: 'Viewer',
    table: 'silver.orders',
    col: 'amount',
    type: 'deny',
    status: 'Active'
  }];
  const requests = [{
    id: 1,
    who: 'Ade Okafor',
    what: 'Analyst role',
    on: 'gold.fact_production',
    when: '2 min ago'
  }, {
    id: 2,
    who: 'Mara Díaz',
    what: 'Read access',
    on: 'silver.shipments',
    when: '1 hour ago'
  }];
  const [reqs, setReqs] = React.useState(requests);
  const act = (id, decision) => {
    setReqs(rs => rs.filter(r => r.id !== id));
    notify && notify({
      kind: decision === 'approve' ? 'success' : 'info',
      title: decision === 'approve' ? 'Request approved' : 'Request denied'
    });
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "gv-iam"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "locked",
    size: 16
  }), "Identity from Keycloak (Unified SSO via AD/LDAP) \xB7 Authorization managed here"), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "md",
    icon: "play--outline",
    style: {
      marginLeft: 'auto'
    },
    onClick: () => setModal('preview')
  }, "Preview as user")), /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      label: 'Roles',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        },
        className: "w-tblwrap"
      }, /*#__PURE__*/React.createElement(TableToolbar, {
        placeholder: "Search roles",
        search: "",
        onSearch: () => {},
        actions: /*#__PURE__*/React.createElement(Button, {
          kind: "primary",
          size: "lg",
          icon: "add",
          onClick: () => setModal('role')
        }, "Create role")
      }), /*#__PURE__*/React.createElement(WireTable, {
        columns: roleCols,
        rows: roles,
        footer: false,
        renderCell: (r, k) => {
          if (k === 'model') return /*#__PURE__*/React.createElement(Tag, {
            type: r.model === 'ABAC' ? 'purple' : 'blue',
            size: "sm"
          }, r.model);
          if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
          return r[k];
        }
      }))
    }, {
      label: 'Row-level policies',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        },
        className: "w-tblwrap"
      }, /*#__PURE__*/React.createElement(TableToolbar, {
        placeholder: "Search policies",
        search: "",
        onSearch: () => {},
        actions: /*#__PURE__*/React.createElement(Button, {
          kind: "primary",
          size: "lg",
          icon: "add",
          onClick: () => setModal('rowpolicy')
        }, "Create row policy")
      }), /*#__PURE__*/React.createElement(WireTable, {
        footer: false,
        columns: [{
          key: 'subject',
          label: 'Subject',
          cellClass: 'name'
        }, {
          key: 'table',
          label: 'Table',
          cellClass: 'mono'
        }, {
          key: 'filter',
          label: 'Filter expression',
          cellClass: 'mono'
        }, {
          key: 'enabled',
          label: 'Enabled'
        }, {
          key: 'ofw',
          label: '',
          sortable: false,
          width: 48
        }],
        rows: rowPolicies,
        renderCell: (r, k) => {
          if (k === 'enabled') return /*#__PURE__*/React.createElement(Toggle, {
            size: "sm",
            defaultToggled: r.enabled,
            hideLabel: true,
            label: ""
          });
          if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
          return r[k];
        }
      }))
    }, {
      label: 'Column & field masking',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        },
        className: "w-tblwrap"
      }, /*#__PURE__*/React.createElement(TableToolbar, {
        placeholder: "Search masking policies",
        search: "",
        onSearch: () => {},
        actions: /*#__PURE__*/React.createElement(Button, {
          kind: "primary",
          size: "lg",
          icon: "add",
          onClick: () => setModal('mask')
        }, "Create masking policy")
      }), /*#__PURE__*/React.createElement(WireTable, {
        footer: false,
        columns: [{
          key: 'subject',
          label: 'Subject',
          cellClass: 'name'
        }, {
          key: 'table',
          label: 'Table',
          cellClass: 'mono'
        }, {
          key: 'col',
          label: 'Column',
          cellClass: 'mono'
        }, {
          key: 'type',
          label: 'Mask type'
        }, {
          key: 'status',
          label: 'Status'
        }, {
          key: 'ofw',
          label: '',
          sortable: false,
          width: 48
        }],
        rows: masks,
        renderCell: (r, k) => {
          if (k === 'type') return /*#__PURE__*/React.createElement(Tag, {
            type: r.type === 'deny' ? 'red' : r.type === 'full' ? 'purple' : r.type === 'partial' ? 'blue' : 'cool-gray',
            size: "sm"
          }, r.type);
          if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
            kind: "active"
          }, r.status);
          if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
          return r[k];
        }
      }))
    }, {
      label: `Access requests (${reqs.length})`,
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, reqs.length === 0 ? /*#__PURE__*/React.createElement("div", {
        className: "w-empty"
      }, /*#__PURE__*/React.createElement("div", {
        className: "ic"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "checkmark--outline",
        size: 32
      })), /*#__PURE__*/React.createElement("h3", null, "No pending requests"), /*#__PURE__*/React.createElement("p", null, "Access requests will appear here for approval.")) : /*#__PURE__*/React.createElement("div", {
        className: "w-tblwrap"
      }, reqs.map(r => /*#__PURE__*/React.createElement("div", {
        key: r.id,
        className: "ov-req",
        style: {
          display: 'flex',
          alignItems: 'center',
          gap: 16
        }
      }, /*#__PURE__*/React.createElement("div", {
        style: {
          flex: 1
        }
      }, /*#__PURE__*/React.createElement("div", {
        className: "t"
      }, /*#__PURE__*/React.createElement("b", null, r.who), " requested ", /*#__PURE__*/React.createElement("b", null, r.what)), /*#__PURE__*/React.createElement("div", {
        className: "s",
        style: {
          marginBottom: 0
        }
      }, r.on, " \xB7 ", r.when)), /*#__PURE__*/React.createElement(Button, {
        kind: "ghost",
        size: "sm",
        icon: "chat"
      }, "Comment"), /*#__PURE__*/React.createElement(Button, {
        kind: "primary",
        size: "sm",
        onClick: () => act(r.id, 'approve')
      }, "Approve"), /*#__PURE__*/React.createElement(Button, {
        kind: "tertiary",
        size: "sm",
        onClick: () => act(r.id, 'deny')
      }, "Deny")))), /*#__PURE__*/React.createElement("h3", {
        style: {
          fontSize: '.875rem',
          color: 'var(--cds-text-primary)',
          margin: '24px 0 8px'
        }
      }, "Request history"), /*#__PURE__*/React.createElement("div", {
        className: "w-tblwrap"
      }, /*#__PURE__*/React.createElement(WireTable, {
        footer: false,
        columns: [{
          key: 'who',
          label: 'Requester'
        }, {
          key: 'what',
          label: 'Requested'
        }, {
          key: 'on',
          label: 'Resource',
          cellClass: 'mono'
        }, {
          key: 'res',
          label: 'Decision'
        }, {
          key: 'by',
          label: 'By'
        }],
        rows: [{
          who: 'J. Singh',
          what: 'Editor role',
          on: 'gold.fact_sales',
          res: 'Approved',
          by: 'L. Marsh'
        }, {
          who: 'R. Vance',
          what: 'Write access',
          on: 'silver.shipments',
          res: 'Denied',
          by: 'L. Marsh'
        }],
        renderCell: (r, k) => k === 'res' ? /*#__PURE__*/React.createElement(StatusDot, {
          kind: r.res === 'Approved' ? 'success' : 'failed'
        }, r.res) : r[k]
      })))
    }]
  }), modal === 'role' && /*#__PURE__*/React.createElement(RoleModal, {
    onClose: () => setModal(null),
    notify: notify
  }), modal === 'rowpolicy' && /*#__PURE__*/React.createElement(RowPolicyModal, {
    onClose: () => setModal(null),
    notify: notify
  }), modal === 'mask' && /*#__PURE__*/React.createElement(MaskModal, {
    onClose: () => setModal(null),
    notify: notify
  }), modal === 'preview' && /*#__PURE__*/React.createElement(PreviewAsUser, {
    onClose: () => setModal(null)
  }));
}

/* ---- Data Classification ---- */
function Classification({
  notify
}) {
  const levels = [{
    lvl: 'Public',
    desc: 'No restriction',
    tag: 'green',
    n: 12
  }, {
    lvl: 'Internal',
    desc: 'Employees only',
    tag: 'blue',
    n: 88
  }, {
    lvl: 'Confidential',
    desc: 'Need-to-know',
    tag: 'purple',
    n: 21
  }, {
    lvl: 'Restricted',
    desc: 'PII / regulated',
    tag: 'red',
    n: 9
  }];
  const cols = [{
    key: 'asset',
    label: 'Asset',
    cellClass: 'name'
  }, {
    key: 'level',
    label: 'Sensitivity'
  }, {
    key: 'tags',
    label: 'Compliance tags',
    sortable: false
  }, {
    key: 'by',
    label: 'Classified by'
  }, {
    key: 'auto',
    label: 'Source'
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  const rows = [{
    asset: 'silver.customers',
    level: 'Restricted',
    tags: ['PII', 'GDPR'],
    by: 'auto-rule',
    auto: 'Auto'
  }, {
    asset: 'silver.orders',
    level: 'Confidential',
    tags: ['SOX'],
    by: 'R. Vance',
    auto: 'Manual'
  }, {
    asset: 'gold.fact_production',
    level: 'Internal',
    tags: [],
    by: 'L. Marsh',
    auto: 'Manual'
  }, {
    asset: 'gold.dim_product',
    level: 'Public',
    tags: [],
    by: 'auto-rule',
    auto: 'Auto'
  }];
  const LVL_TAG = {
    Public: 'green',
    Internal: 'blue',
    Confidential: 'purple',
    Restricted: 'red'
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-stats",
    style: {
      marginBottom: 24
    }
  }, levels.map(l => /*#__PURE__*/React.createElement("div", {
    key: l.lvl,
    className: "s"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      background: `var(--cds-${l.tag === 'green' ? 'support-success' : l.tag === 'red' ? 'support-error' : l.tag === 'purple' ? 'purple-60,#8a3ffc' : 'blue-60'})`
    }
  }), l.lvl), /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, l.n), /*#__PURE__*/React.createElement("div", {
    className: "d"
  }, l.desc)))), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search classified assets",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "tag",
      iconOnly: true,
      title: "Bulk tag"
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => notify && notify({
        kind: 'info',
        title: 'Auto-classification rule builder'
      })
    }, "New rule"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: rows,
    footer: false,
    renderCell: (r, k) => {
      if (k === 'level') return /*#__PURE__*/React.createElement(Tag, {
        type: LVL_TAG[r.level],
        size: "sm"
      }, r.level);
      if (k === 'tags') return /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'flex',
          gap: 4,
          flexWrap: 'wrap'
        }
      }, r.tags.length ? r.tags.map(t => /*#__PURE__*/React.createElement(Tag, {
        key: t,
        type: "cool-gray",
        size: "sm"
      }, t)) : /*#__PURE__*/React.createElement("span", {
        style: {
          color: 'var(--cds-text-placeholder)'
        }
      }, "\u2014"));
      if (k === 'auto') return /*#__PURE__*/React.createElement(Tag, {
        type: r.auto === 'Auto' ? 'teal' : 'cool-gray',
        size: "sm"
      }, r.auto);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })));
}
const GOV_SUBS = [{
  id: 'catalog',
  label: 'Data catalog'
}, {
  id: 'lineage',
  label: 'Lineage graph'
}, {
  id: 'access',
  label: 'Access control'
}, {
  id: 'classification',
  label: 'Data classification'
}];
function Governance({
  notify,
  lang
}) {
  const [sub, setSub] = React.useState('catalog');
  const [asset, setAsset] = React.useState(null);
  if (sub === 'catalog' && asset) {
    return /*#__PURE__*/React.createElement("div", {
      className: "w-page"
    }, /*#__PURE__*/React.createElement("div", {
      className: "w-crumb"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => e.preventDefault()
    }, "Data Assets & Governance"), /*#__PURE__*/React.createElement("span", {
      className: "sep"
    }, "/"), /*#__PURE__*/React.createElement("a", {
      href: "#",
      onClick: e => e.preventDefault()
    }, "Data catalog"), /*#__PURE__*/React.createElement("span", {
      className: "sep"
    }, "/"), /*#__PURE__*/React.createElement("span", null, asset.name)), /*#__PURE__*/React.createElement(AssetDetail, {
      asset: asset,
      onBack: () => setAsset(null)
    }));
  }
  const TITLES = {
    catalog: ['Data catalog', 'Search and explore every table and field across the platform.'],
    lineage: ['Lineage graph', 'Trace data flow RAW → Bronze → Silver → Gold → ClickHouse, down to field level.'],
    access: ['Access control', 'Manage users, roles, and row/column-level policies (RBAC / ABAC).'],
    classification: ['Data classification', 'Sensitivity levels, compliance tags, and auto-classification rules.']
  };
  const [t, s] = TITLES[sub];
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Data Assets & Governance', t].map(c => tr(lang, c)),
    title: tr(lang, t),
    sub: tr(lang, s)
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, GOV_SUBS),
    value: sub,
    onChange: v => {
      setSub(v);
      setAsset(null);
    }
  }), sub === 'catalog' && /*#__PURE__*/React.createElement(Catalog, {
    onOpen: setAsset
  }), sub === 'lineage' && /*#__PURE__*/React.createElement(LineageGraph, null), sub === 'access' && /*#__PURE__*/React.createElement(AccessControl, {
    notify: notify
  }), sub === 'classification' && /*#__PURE__*/React.createElement(Classification, {
    notify: notify
  }));
}
Object.assign(window, {
  Governance
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Governance.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/IpOverview.jsx
try { (() => {
/* global React, PageHead, WireTable, StatusDot, BarChart, Overflow, tr */
const {
  Icon,
  Tag,
  Button
} = window.CarbonDesignSystem_280d33;
const OV_CSS = `
.ov-greet { display:flex; align-items:flex-end; justify-content:space-between; gap:24px; margin-bottom:24px; flex-wrap:wrap; }
.ov-greet h1 { font-size:1.75rem; font-weight:300; margin:0; color:var(--cds-text-primary); }
.ov-greet h1 b { font-weight:600; }
.ov-greet .badges { display:flex; gap:8px; align-items:center; }
.ov-kpis { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.ov-kpi { background:var(--cds-layer-02); padding:20px; }
.ov-kpi .k { font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.ov-kpi .v { font-size:2.5rem; font-weight:300; line-height:1; margin-top:12px; color:var(--cds-text-primary); }
.ov-kpi .v.ok { color:var(--cds-support-success); } .ov-kpi .v.fail { color:var(--cds-support-error); } .ov-kpi .v.warn { color:var(--cds-support-warning); }
.ov-kpi .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:8px; display:flex; align-items:center; gap:4px; }
.ov-grid { display:grid; grid-template-columns:1.6fr 1fr; gap:16px; align-items:start; }
.ov-block { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.ov-block__h { display:flex; align-items:center; gap:8px; height:48px; padding:0 16px; border-bottom:1px solid var(--wire-border); font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.ov-block__h .more { margin-left:auto; }
.ov-quick { display:grid; grid-template-columns:repeat(3,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.ov-qa { background:var(--cds-layer-02); border:none; padding:18px 16px; display:flex; align-items:center; gap:12px; cursor:pointer; font-family:var(--cds-font-sans); text-align:left; }
.ov-qa:hover { background:var(--cds-layer-hover-01); }
.ov-qa .ic { width:36px; height:36px; flex:0 0 36px; background:rgba(15,98,254,.08); color:var(--cds-blue-60); display:flex; align-items:center; justify-content:center; }
.ov-qa .t { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.ov-qa .s { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; }
.ov-req { padding:14px 16px; border-bottom:1px solid var(--wire-border); }
.ov-req:last-child { border-bottom:none; }
.ov-req .t { font-size:.8125rem; color:var(--cds-text-primary); }
.ov-req .s { font-size:.75rem; color:var(--cds-text-secondary); margin:2px 0 10px; }
.ov-req .acts { display:flex; gap:8px; }
.ov-fav { display:flex; align-items:center; gap:10px; padding:12px 16px; border-bottom:1px solid var(--wire-border); cursor:pointer; }
.ov-fav:last-child { border-bottom:none; }
.ov-fav:hover { background:var(--cds-layer-hover-01); }
.ov-fav .ic { color:var(--cds-blue-60); display:flex; }
.ov-fav .nm { font-size:.8125rem; color:var(--cds-text-primary); font-weight:500; }
.ov-fav .mt { font-size:.6875rem; color:var(--cds-text-secondary); }
`;
(function () {
  if (!document.getElementById('ipas-ov-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-ov-styles';
    e.textContent = OV_CSS;
    document.head.appendChild(e);
  }
})();
const OV_RUNS = [{
  id: 1,
  pipe: 'erp_to_gold',
  status: 'Success',
  dur: '11m 04s',
  when: '14:32'
}, {
  id: 2,
  pipe: 'mes_stream',
  status: 'Running',
  dur: '—',
  when: '14:30'
}, {
  id: 3,
  pipe: 'crm_sync',
  status: 'Failed',
  dur: '1m 02s',
  when: '14:18'
}, {
  id: 4,
  pipe: 'finance_daily',
  status: 'Success',
  dur: '3m 30s',
  when: '13:55'
}, {
  id: 5,
  pipe: 'logistics_etl',
  status: 'Success',
  dur: '5m 01s',
  when: '13:40'
}];
const OV_FAVS = [{
  name: 'Production Yield Overview',
  mt: 'Edited 2 hours ago'
}, {
  name: 'SPC Control — Line 4',
  mt: 'Viewed yesterday'
}, {
  name: 'Daily Revenue & Margin',
  mt: 'Viewed 3 days ago'
}];
function IpOverview({
  notify,
  lang,
  onNavigate
}) {
  const h = new Date().getHours();
  const greetEn = h < 12 ? 'Good morning' : h < 18 ? 'Good afternoon' : 'Good evening';
  const greet = lang === 'zh' ? h < 12 ? '早上好' : h < 18 ? '下午好' : '晚上好' : greetEn;
  const runCols = [{
    key: 'pipe',
    label: tr(lang, 'Pipeline'),
    cellClass: 'mono'
  }, {
    key: 'status',
    label: tr(lang, 'Status')
  }, {
    key: 'dur',
    label: tr(lang, 'Duration')
  }, {
    key: 'when',
    label: tr(lang, 'Started')
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-greet"
  }, /*#__PURE__*/React.createElement("h1", null, greet, ", ", /*#__PURE__*/React.createElement("b", null, "Lena"), "."), /*#__PURE__*/React.createElement("div", {
    className: "badges"
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "md"
  }, "Manufacturing"), /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "md"
  }, tr(lang, 'Data Engineer')))), /*#__PURE__*/React.createElement("div", {
    className: "ov-kpis"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "checkmark--filled",
    size: 16
  }), tr(lang, 'Healthy pipelines')), /*#__PURE__*/React.createElement("div", {
    className: "v ok"
  }, "38"), /*#__PURE__*/React.createElement("div", {
    className: "d"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow--up",
    size: 14
  }), "2 since yesterday")), /*#__PURE__*/React.createElement("div", {
    className: "ov-kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "error--filled",
    size: 16
  }), tr(lang, 'Failed (24h)')), /*#__PURE__*/React.createElement("div", {
    className: "v fail"
  }, "7"), /*#__PURE__*/React.createElement("div", {
    className: "d"
  }, "3 awaiting retry")), /*#__PURE__*/React.createElement("div", {
    className: "ov-kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), tr(lang, 'Catalog assets')), /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, "186"), /*#__PURE__*/React.createElement("div", {
    className: "d"
  }, "12 certified this week")), /*#__PURE__*/React.createElement("div", {
    className: "ov-kpi"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "warning--filled",
    size: 16
  }), tr(lang, 'Open alerts')), /*#__PURE__*/React.createElement("div", {
    className: "v warn"
  }, "4"), /*#__PURE__*/React.createElement("div", {
    className: "d"
  }, "1 SLA breach"))), /*#__PURE__*/React.createElement("div", {
    className: "ov-quick"
  }, /*#__PURE__*/React.createElement("button", {
    className: "ov-qa",
    onClick: () => onNavigate('devconfig')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "flow",
    size: 20
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, tr(lang, 'New pipeline')), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, tr(lang, 'Ingest a source to a layer')))), /*#__PURE__*/React.createElement("button", {
    className: "ov-qa",
    onClick: () => onNavigate('analytics')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "dashboard",
    size: 20
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, tr(lang, 'New dashboard')), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, tr(lang, 'Build on the canvas')))), /*#__PURE__*/React.createElement("button", {
    className: "ov-qa",
    onClick: () => onNavigate('analytics')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "terminal",
    size: 20
  })), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, tr(lang, 'Run a query')), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, tr(lang, 'Visual builder or SQL'))))), /*#__PURE__*/React.createElement("div", {
    className: "ov-grid"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-block__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "flow",
    size: 16
  }), tr(lang, 'Recent pipelines'), /*#__PURE__*/React.createElement(Button, {
    className: "more",
    kind: "ghost",
    size: "sm",
    onClick: () => onNavigate('monitoring')
  }, tr(lang, 'View all'))), /*#__PURE__*/React.createElement(WireTable, {
    columns: runCols,
    rows: OV_RUNS,
    footer: false,
    onRowClick: () => onNavigate('monitoring'),
    renderCell: (r, k) => k === 'status' ? /*#__PURE__*/React.createElement(StatusDot, {
      kind: r.status
    }, r.status) : r[k]
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-block__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "user--follow",
    size: 16
  }), tr(lang, 'Pending access requests'), /*#__PURE__*/React.createElement(Tag, {
    type: "red",
    size: "sm",
    style: {
      marginLeft: 'auto'
    }
  }, "2")), /*#__PURE__*/React.createElement("div", {
    className: "ov-req"
  }, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "Ade Okafor \u2192 ", /*#__PURE__*/React.createElement("b", null, "Analyst")), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, "gold.fact_production \xB7 requested 2 min ago"), /*#__PURE__*/React.createElement("div", {
    className: "acts"
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "sm",
    onClick: () => notify({
      kind: 'success',
      title: 'Access approved'
    })
  }, tr(lang, 'Approve')), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    onClick: () => notify({
      kind: 'info',
      title: 'Access denied'
    })
  }, tr(lang, 'Deny')))), /*#__PURE__*/React.createElement("div", {
    className: "ov-req"
  }, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "Mara D\xEDaz \u2192 ", /*#__PURE__*/React.createElement("b", null, "dataset access")), /*#__PURE__*/React.createElement("div", {
    className: "s"
  }, "silver.shipments \xB7 requested 1 hour ago"), /*#__PURE__*/React.createElement("div", {
    className: "acts"
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "sm",
    onClick: () => notify({
      kind: 'success',
      title: 'Access approved'
    })
  }, tr(lang, 'Approve')), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    size: "sm",
    onClick: () => notify({
      kind: 'info',
      title: 'Access denied'
    })
  }, tr(lang, 'Deny'))))), /*#__PURE__*/React.createElement("div", {
    className: "ov-block"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ov-block__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "dashboard",
    size: 16
  }), tr(lang, 'My dashboards')), OV_FAVS.map(f => /*#__PURE__*/React.createElement("div", {
    key: f.name,
    className: "ov-fav",
    onClick: () => onNavigate('analytics')
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "star--filled",
    size: 16
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "nm"
  }, f.name), /*#__PURE__*/React.createElement("div", {
    className: "mt"
  }, f.mt)), /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--right",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  })))))));
}
Object.assign(window, {
  IpOverview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/IpOverview.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/IpasApp.jsx
try { (() => {
/* global React, IpSideNav, Welcome, IpOverview, Profile, Analytics, Modeling, DevConfig, Governance, Monitoring, Admin, NotificationsPanel, SEED_NOTIFS, tr */
const {
  InlineNotification
} = window.CarbonDesignSystem_280d33;
const IPAS_APP_CSS = `
.ip-toaststack { position:fixed; top:16px; right:16px; z-index:80; width:360px; display:flex; flex-direction:column; gap:8px; }
`;
(function () {
  if (!document.getElementById('ipas-app-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-app-styles';
    e.textContent = IPAS_APP_CSS;
    document.head.appendChild(e);
  }
})();
function IpasApp() {
  const [nav, setNav] = React.useState(null);
  const [profileTab, setProfileTab] = React.useState(null); // when set, render Profile
  const [collapsed, setCollapsed] = React.useState(false);
  const [lang, setLang] = React.useState('en');
  const [toasts, setToasts] = React.useState([]);
  const [notifs, setNotifs] = React.useState(SEED_NOTIFS);
  const [notifOpen, setNotifOpen] = React.useState(false);
  const notify = React.useCallback(t => {
    const id = Math.random().toString(36).slice(2);
    setToasts(ts => [...ts, {
      ...t,
      id
    }]);
    setTimeout(() => setToasts(ts => ts.filter(x => x.id !== id)), 4500);
  }, []);

  // live pipeline toast demo — a run completes shortly after first load
  React.useEffect(() => {
    const t = setTimeout(() => notify({
      kind: 'success',
      title: 'Pipeline qms-cdc completed',
      subtitle: 'Loaded 3 layers in 2m 41s.'
    }), 6000);
    return () => clearTimeout(t);
  }, [notify]);
  const unread = notifs.filter(n => n.unread).length;
  const markRead = id => setNotifs(ns => ns.map(n => n.id === id ? {
    ...n,
    unread: false
  } : n));
  const markAll = () => setNotifs(ns => ns.map(n => ({
    ...n,
    unread: false
  })));
  const actRequest = (id, decision) => {
    setNotifs(ns => ns.filter(n => n.id !== id));
    notify({
      kind: decision === 'approve' ? 'success' : 'info',
      title: decision === 'approve' ? 'Access approved' : 'Access denied',
      subtitle: 'Ade Okafor · Analyst role'
    });
  };
  const goProfile = tab => {
    setProfileTab(tab);
    setNav('__profile');
  };
  const selectNav = id => {
    setProfileTab(null);
    setNav(id);
  };
  const SECTIONS = {
    overview: IpOverview,
    analytics: Analytics,
    modeling: Modeling,
    devconfig: DevConfig,
    governance: Governance,
    monitoring: Monitoring,
    admin: Admin
  };
  let content;
  if (nav === '__profile') content = /*#__PURE__*/React.createElement(Profile, {
    key: "profile",
    tab: profileTab,
    lang: lang,
    notify: notify,
    onNavigate: selectNav
  });else if (nav && SECTIONS[nav]) {
    const S = SECTIONS[nav];
    content = /*#__PURE__*/React.createElement(S, {
      key: nav,
      notify: notify,
      lang: lang,
      onNavigate: selectNav
    });
  } else content = /*#__PURE__*/React.createElement(Welcome, {
    onNavigate: selectNav,
    lang: lang
  });
  return /*#__PURE__*/React.createElement("div", {
    className: "ip-shell"
  }, /*#__PURE__*/React.createElement(IpSideNav, {
    current: nav,
    onSelect: selectNav,
    collapsed: collapsed,
    onToggle: () => setCollapsed(c => !c),
    onHome: () => selectNav(null),
    lang: lang,
    onLang: setLang,
    unread: unread,
    onNotifications: () => setNotifOpen(true),
    onProfile: goProfile,
    onAppearance: () => notify({
      kind: 'info',
      title: tr(lang, 'Appearance'),
      subtitle: 'Light / Dark / High-contrast — set in Preferences.'
    })
  }), /*#__PURE__*/React.createElement("main", {
    className: "ip-main"
  }, content), notifOpen && /*#__PURE__*/React.createElement(NotificationsPanel, {
    lang: lang,
    notifs: notifs,
    onClose: () => setNotifOpen(false),
    onMarkAll: markAll,
    onAct: actRequest,
    onRead: markRead
  }), toasts.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "ip-toaststack"
  }, toasts.map(t => /*#__PURE__*/React.createElement(InlineNotification, {
    key: t.id,
    kind: t.kind,
    title: t.title,
    subtitle: t.subtitle,
    onClose: () => setToasts(ts => ts.filter(x => x.id !== t.id))
  }))));
}
Object.assign(window, {
  IpasApp
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/IpasApp.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Modeling.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, StatusDot, ToolBtn, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown
} = window.CarbonDesignSystem_280d33;
const MODELING_CSS = `
.md-editor { display:flex; flex-direction:column; height:600px; border:1px solid var(--wire-border); }
.md-body { display:flex; flex:1; min-height:0; }
.md-canvas { flex:1; position:relative; overflow:auto;
  background:linear-gradient(var(--cds-layer-01) 1px,transparent 1px) 0 0/100% 24px, linear-gradient(90deg,var(--cds-layer-01) 1px,transparent 1px) 0 0/24px 100%, var(--cds-layer-02); }
.md-tablebox { position:absolute; width:200px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:0 1px 3px rgba(0,0,0,.1); }
.md-tablebox.fact { border:2px solid var(--cds-border-interactive); }
.md-tablebox.sel { box-shadow:0 0 0 2px var(--cds-border-interactive); }
.md-tablebox__h { display:flex; align-items:center; gap:8px; height:32px; padding:0 10px; background:var(--cds-gray-100); color:#fff; font-size:.75rem; font-weight:600; cursor:move; }
.md-tablebox.fact .md-tablebox__h { background:var(--cds-blue-60); }
.md-tablebox__row { display:flex; align-items:center; gap:8px; padding:5px 10px; font-size:.75rem; color:var(--cds-text-secondary); border-bottom:1px solid var(--wire-border); }
.md-tablebox__row:last-child { border-bottom:none; }
.md-tablebox__row .key { color:var(--cds-blue-60); }
.md-tablebox__row.pk { color:var(--cds-text-primary); font-weight:500; }
.md-side { width:300px; flex:0 0 300px; background:var(--cds-layer-02); border-left:1px solid var(--wire-border); display:flex; flex-direction:column; }
.md-side__h { height:40px; display:flex; align-items:center; padding:0 16px; font-size:.75rem; font-weight:600; border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.md-side__body { padding:16px; overflow:auto; flex:1; display:flex; flex-direction:column; gap:16px; }
.md-map { display:flex; flex-direction:column; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.md-map__row { background:var(--cds-layer-02); padding:8px 10px; display:flex; flex-direction:column; gap:2px; }
.md-map__row .phys { font-family:var(--cds-font-mono); font-size:.6875rem; color:var(--cds-text-secondary); }
.md-map__row .biz { font-size:.8125rem; color:var(--cds-text-primary); display:flex; align-items:center; gap:6px; }
.md-lineage { display:flex; align-items:center; gap:6px; font-size:.75rem; color:var(--cds-link-primary); cursor:pointer; }
.md-lineage:hover { text-decoration:underline; }
`;
(function () {
  if (!document.getElementById('ipas-modeling-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-modeling-styles';
    e.textContent = MODELING_CSS;
    document.head.appendChild(e);
  }
})();
const METRICS = [{
  id: 1,
  name: 'First-pass yield',
  def: 'Units passing QC on first attempt ÷ total units started',
  formula: '1 - (defects / units_started)',
  owner: 'L. Marsh',
  status: 'Certified',
  unit: '%'
}, {
  id: 2,
  name: 'Gross margin',
  def: 'Revenue minus COGS, as a share of revenue',
  formula: '(revenue - cogs) / revenue',
  owner: 'A. Okafor',
  status: 'Certified',
  unit: '%'
}, {
  id: 3,
  name: 'On-time delivery',
  def: 'Orders delivered by promised date ÷ total orders',
  formula: 'on_time_orders / total_orders',
  owner: 'R. Vance',
  status: 'Draft',
  unit: '%'
}, {
  id: 4,
  name: 'Mean cycle time',
  def: 'Average elapsed time per production run',
  formula: 'avg(end_ts - start_ts)',
  owner: 'L. Marsh',
  status: 'Certified',
  unit: 'min'
}, {
  id: 5,
  name: 'Scrap cost',
  def: 'Total cost of scrapped material per period',
  formula: 'sum(scrap_qty * unit_cost)',
  owner: 'M. Díaz',
  status: 'Review',
  unit: 'USD'
}, {
  id: 6,
  name: 'Net revenue retention',
  def: 'Recurring revenue retained + expansion ÷ starting',
  formula: '(start + expansion - churn) / start',
  owner: 'J. Singh',
  status: 'Draft',
  unit: '%'
}];
function MetricsStore({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const cols = [{
    key: 'name',
    label: 'Metric',
    cellClass: 'name'
  }, {
    key: 'def',
    label: 'Business definition'
  }, {
    key: 'formula',
    label: 'Formula',
    cellClass: 'mono'
  }, {
    key: 'owner',
    label: 'Owner'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'lineage',
    label: 'Lineage',
    sortable: false
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search metrics",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "filter",
      iconOnly: true
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setOpen(true)
    }, "Define metric"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: METRICS,
    total: 48,
    renderCell: (r, k) => {
      if (k === 'name') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault()
      }, r.name);
      if (k === 'def') return /*#__PURE__*/React.createElement("span", {
        style: {
          display: 'block',
          maxWidth: 280,
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }
      }, r.def);
      if (k === 'status') return /*#__PURE__*/React.createElement(Tag, {
        type: r.status === 'Certified' ? 'green' : r.status === 'Review' ? 'purple' : 'gray',
        size: "sm"
      }, r.status);
      if (k === 'lineage') return /*#__PURE__*/React.createElement("span", {
        className: "md-lineage"
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "data--base",
        size: 16
      }), "View");
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Metrics store",
    title: "Define metric",
    size: "lg",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Metric submitted for review.'
        });
      }
    }, "Save metric"))
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Metric name",
    placeholder: "First-pass yield"
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Unit",
    items: ['%', 'USD', 'min', 'count', 'ratio'],
    value: "%",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement(TextInput, {
    label: "Caliber / business definition",
    placeholder: "Plain-language definition of what this measures",
    helperText: "Shown to every consumer of the metric."
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Expression"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.8125rem',
      background: 'var(--cds-gray-100)',
      color: '#f4f4f4',
      padding: 12,
      minHeight: 72,
      whiteSpace: 'pre'
    }
  }, '1 - (sum(defects) / sum(units_started))')), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Dimensions"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, ['plant', 'line_id', 'shift', 'product_sku', 'date'].map(d => /*#__PURE__*/React.createElement(Tag, {
    key: d,
    type: "cool-gray",
    size: "sm"
  }, d)), /*#__PURE__*/React.createElement(Tag, {
    type: "outline",
    size: "sm",
    icon: "add"
  }, "Add dimension")))));
}
function TableBox({
  id,
  x,
  y,
  fact,
  title,
  rows,
  sel,
  onSelect
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: `md-tablebox ${fact ? 'fact' : ''} ${sel ? 'sel' : ''}`,
    style: {
      left: x,
      top: y
    },
    onClick: () => onSelect(id)
  }, /*#__PURE__*/React.createElement("div", {
    className: "md-tablebox__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), title), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `md-tablebox__row ${r.pk ? 'pk' : ''}`
  }, r.key && /*#__PURE__*/React.createElement(Icon, {
    name: "locked",
    size: 16,
    className: "key"
  }), r.name, /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.625rem',
      color: 'var(--cds-text-placeholder)'
    }
  }, r.type))));
}
function SemanticModeler() {
  const [sel, setSel] = React.useState('fact');
  return /*#__PURE__*/React.createElement("div", {
    className: "md-editor"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-etoolbar"
  }, /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "save",
    label: "Save model"
  }), /*#__PURE__*/React.createElement("span", {
    className: "gap"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "add",
    label: "Add table"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "share",
    label: "Add join"
  }), /*#__PURE__*/React.createElement("span", {
    className: "spacer"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--out",
    label: "",
    title: "Zoom out"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "zoom--in",
    label: "",
    title: "Zoom in"
  }), /*#__PURE__*/React.createElement(ToolBtn, {
    icon: "view",
    label: "Validate"
  })), /*#__PURE__*/React.createElement("div", {
    className: "md-body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "md-canvas"
  }, /*#__PURE__*/React.createElement("svg", {
    style: {
      position: 'absolute',
      inset: 0,
      width: '100%',
      height: '100%',
      pointerEvents: 'none'
    }
  }, /*#__PURE__*/React.createElement("g", {
    stroke: "var(--cds-border-strong-01)",
    strokeWidth: "1.5",
    fill: "none"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M 340 160 L 230 90"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 340 180 L 230 300"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 540 160 L 650 90"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M 540 200 L 650 320"
  })), /*#__PURE__*/React.createElement("g", {
    fill: "var(--cds-blue-60)"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "340",
    cy: "160",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "340",
    cy: "180",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "540",
    cy: "160",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "540",
    cy: "200",
    r: "4"
  }))), /*#__PURE__*/React.createElement(TableBox, {
    id: "dim_product",
    x: 40,
    y: 40,
    title: "dim_product",
    sel: sel === 'dim_product',
    onSelect: setSel,
    rows: [{
      name: 'product_key',
      key: true,
      pk: true,
      type: 'PK'
    }, {
      name: 'sku',
      type: 'str'
    }, {
      name: 'category',
      type: 'str'
    }]
  }), /*#__PURE__*/React.createElement(TableBox, {
    id: "dim_plant",
    x: 40,
    y: 280,
    title: "dim_plant",
    sel: sel === 'dim_plant',
    onSelect: setSel,
    rows: [{
      name: 'plant_key',
      key: true,
      pk: true,
      type: 'PK'
    }, {
      name: 'region',
      type: 'str'
    }]
  }), /*#__PURE__*/React.createElement(TableBox, {
    id: "fact",
    x: 340,
    y: 120,
    fact: true,
    title: "fact_production",
    sel: sel === 'fact',
    onSelect: setSel,
    rows: [{
      name: 'product_key',
      key: true,
      type: 'FK'
    }, {
      name: 'plant_key',
      key: true,
      type: 'FK'
    }, {
      name: 'date_key',
      key: true,
      type: 'FK'
    }, {
      name: 'units_produced',
      type: 'num'
    }, {
      name: 'defect_count',
      type: 'num'
    }]
  }), /*#__PURE__*/React.createElement(TableBox, {
    id: "dim_date",
    x: 650,
    y: 40,
    title: "dim_date",
    sel: sel === 'dim_date',
    onSelect: setSel,
    rows: [{
      name: 'date_key',
      key: true,
      pk: true,
      type: 'PK'
    }, {
      name: 'week',
      type: 'int'
    }, {
      name: 'quarter',
      type: 'str'
    }]
  }), /*#__PURE__*/React.createElement(TableBox, {
    id: "dim_shift",
    x: 650,
    y: 280,
    title: "dim_shift",
    sel: sel === 'dim_shift',
    onSelect: setSel,
    rows: [{
      name: 'shift_key',
      key: true,
      pk: true,
      type: 'PK'
    }, {
      name: 'shift_name',
      type: 'str'
    }]
  })), /*#__PURE__*/React.createElement("aside", {
    className: "md-side"
  }, /*#__PURE__*/React.createElement("div", {
    className: "md-side__h"
  }, "fact_production \xB7 field mapping"), /*#__PURE__*/React.createElement("div", {
    className: "md-side__body"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Physical \u2192 business names"), /*#__PURE__*/React.createElement("div", {
    className: "md-map"
  }, /*#__PURE__*/React.createElement("div", {
    className: "md-map__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phys"
  }, "units_produced"), /*#__PURE__*/React.createElement("span", {
    className: "biz"
  }, "Units produced ", /*#__PURE__*/React.createElement(Icon, {
    name: "edit",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "md-map__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phys"
  }, "defect_count"), /*#__PURE__*/React.createElement("span", {
    className: "biz"
  }, "Defects ", /*#__PURE__*/React.createElement(Icon, {
    name: "edit",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "md-map__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "phys"
  }, "cycle_time_s"), /*#__PURE__*/React.createElement("span", {
    className: "biz"
  }, "Cycle time (sec) ", /*#__PURE__*/React.createElement(Icon, {
    name: "edit",
    size: 16,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }))))), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Hierarchies"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8125rem',
      color: 'var(--cds-text-primary)',
      border: '1px solid var(--wire-border)',
      padding: 10
    }
  }, "Plant \u2192 Line \u2192 Workstation")), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Measures"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm"
  }, "SUM units"), /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm"
  }, "AVG yield"), /*#__PURE__*/React.createElement(Tag, {
    type: "outline",
    size: "sm",
    icon: "add"
  }, "Add"))), /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, "Field-level lineage"), /*#__PURE__*/React.createElement("span", {
    className: "md-lineage"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "launch",
    size: 16
  }), "Open in DataHub"))))));
}
const MODELING_SUBS = [{
  id: 'metrics',
  label: 'Metrics store'
}, {
  id: 'semantic',
  label: 'Semantic model editor'
}];
function Modeling({
  notify,
  lang
}) {
  const [sub, setSub] = React.useState('metrics');
  if (sub === 'semantic') {
    return /*#__PURE__*/React.createElement("div", {
      className: "w-page"
    }, /*#__PURE__*/React.createElement(PageHead, {
      crumb: ['Data Modeling & Semantics', 'Semantic model editor'].map(c => tr(lang, c)),
      title: tr(lang, 'Semantic model editor'),
      sub: tr(lang, 'Model star schemas, map physical tables to business names, and link field lineage.')
    }), /*#__PURE__*/React.createElement(SubSwitch, {
      items: trList(lang, MODELING_SUBS),
      value: sub,
      onChange: setSub
    }), /*#__PURE__*/React.createElement(SemanticModeler, null));
  }
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Data Modeling & Semantics', 'Metrics store'].map(c => tr(lang, c)),
    title: tr(lang, 'Metrics store'),
    sub: tr(lang, 'A governed catalog of business metrics — definitions, formulas, and ownership.')
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, MODELING_SUBS),
    value: sub,
    onChange: setSub
  }), /*#__PURE__*/React.createElement(MetricsStore, {
    notify: notify
  }));
}
Object.assign(window, {
  Modeling
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Modeling.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Monitoring.jsx
try { (() => {
/* global React, PageHead, SubSwitch, WireTable, TableToolbar, Overflow, Modal, Placeholder, BarChart, StatusDot, ToolBtn, tr, trList */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown
} = window.CarbonDesignSystem_280d33;
const MON_CSS = `
.mn-cards { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); margin-bottom:24px; }
.mn-card { background:var(--cds-layer-02); padding:20px; }
.mn-card .k { font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.mn-card .v { font-size:2.5rem; font-weight:300; line-height:1; margin-top:12px; color:var(--cds-text-primary); }
.mn-card .v.run { color:var(--cds-blue-60); } .mn-card .v.ok { color:var(--cds-support-success); } .mn-card .v.fail { color:var(--cds-support-error); } .mn-card .v.retry { color:var(--cds-support-warning); }
.mn-grafana { display:grid; grid-template-columns:repeat(2,1fr); gap:16px; margin-bottom:24px; }
.mn-panel { background:var(--cds-layer-02); border:1px solid var(--wire-border); }
.mn-panel__h { display:flex; align-items:center; gap:8px; padding:10px 16px; border-bottom:1px solid var(--wire-border); font-size:.8125rem; font-weight:600; color:var(--cds-text-primary); }
.mn-panel__h .badge { margin-left:auto; font-size:.6875rem; font-weight:400; color:var(--cds-text-secondary); display:flex; align-items:center; gap:6px; }
.mn-panel__b { padding:16px; }
.mn-sla { width:100%; border-collapse:collapse; }
.mn-sla th { text-align:left; font-size:.75rem; font-weight:600; padding:10px 16px; background:var(--cds-layer-01); border-bottom:1px solid var(--wire-border); color:var(--cds-text-primary); }
.mn-sla td { font-size:.8125rem; padding:0 16px; height:48px; border-bottom:1px solid var(--wire-border); color:var(--cds-text-secondary); }
.mn-sla .pipe { color:var(--cds-text-primary); font-weight:500; font-family:var(--cds-font-mono); font-size:.8125rem; }
.mn-rag { display:inline-flex; align-items:center; gap:6px; }
.mn-rag .sq { width:12px; height:12px; }
.mn-log { font-family:var(--cds-font-mono); font-size:.75rem; border:1px solid var(--wire-border); background:var(--cds-gray-100); color:#f4f4f4; max-height:520px; overflow:auto; }
.mn-log__bar { display:flex; align-items:center; gap:8px; padding:8px; background:var(--cds-layer-02); border-bottom:1px solid var(--wire-border); }
.mn-log__row { display:flex; gap:12px; padding:5px 12px; border-bottom:1px solid rgba(255,255,255,.05); white-space:nowrap; }
.mn-log__row:hover { background:rgba(255,255,255,.04); }
.mn-log__ts { color:#8d8d8d; flex:0 0 auto; }
.mn-log__lvl { flex:0 0 56px; font-weight:600; }
.mn-log__lvl.info { color:#78a9ff; } .mn-log__lvl.warn { color:#f1c21b; } .mn-log__lvl.error { color:#ff8389; }
.mn-log__src { color:#3ddbd9; flex:0 0 130px; }
.mn-log__msg { color:#e0e0e0; white-space:pre; }
`;
(function () {
  if (!document.getElementById('ipas-mon-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-mon-styles';
    e.textContent = MON_CSS;
    document.head.appendChild(e);
  }
})();
const RUNS = [{
  id: 1,
  dag: 'erp_to_gold',
  task: 'fact_production',
  start: '14:32',
  dur: '4m 12s',
  status: 'Success'
}, {
  id: 2,
  dag: 'mes_stream',
  task: 'clean_mes',
  start: '14:30',
  dur: 'running',
  status: 'Running'
}, {
  id: 3,
  dag: 'crm_sync',
  task: 'load_customers',
  start: '14:18',
  dur: '1m 02s',
  status: 'Failed'
}, {
  id: 4,
  dag: 'erp_to_gold',
  task: 'agg_yield',
  start: '14:10',
  dur: '2m 48s',
  status: 'Retrying'
}, {
  id: 5,
  dag: 'finance_daily',
  task: 'gross_margin',
  start: '13:55',
  dur: '3m 30s',
  status: 'Success'
}, {
  id: 6,
  dag: 'logistics_etl',
  task: 'on_time_delivery',
  start: '13:40',
  dur: '5m 01s',
  status: 'Success'
}];
function TaskMonitoring() {
  const cols = [{
    key: 'dag',
    label: 'DAG',
    cellClass: 'mono'
  }, {
    key: 'task',
    label: 'Task',
    cellClass: 'mono'
  }, {
    key: 'start',
    label: 'Started'
  }, {
    key: 'dur',
    label: 'Duration'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'logs',
    label: 'Logs',
    sortable: false
  }, {
    key: 'act',
    label: '',
    sortable: false,
    width: 96
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "mn-cards"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "renew",
    size: 16
  }), "Running"), /*#__PURE__*/React.createElement("div", {
    className: "v run"
  }, "3")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "checkmark--filled",
    size: 16
  }), "Success (24h)"), /*#__PURE__*/React.createElement("div", {
    className: "v ok"
  }, "412")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "error--filled",
    size: 16
  }), "Failed (24h)"), /*#__PURE__*/React.createElement("div", {
    className: "v fail"
  }, "7")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "warning--filled",
    size: 16
  }), "Retrying"), /*#__PURE__*/React.createElement("div", {
    className: "v retry"
  }, "2"))), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search runs by DAG or task",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dropdown, {
      items: ['All status', 'Running', 'Failed', 'Retrying'],
      value: "All status",
      onChange: () => {}
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "ghost",
      size: "lg",
      icon: "renew",
      iconOnly: true
    }))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: RUNS,
    total: 421,
    renderCell: (r, k) => {
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status
      }, r.status);
      if (k === 'logs') return /*#__PURE__*/React.createElement("a", {
        href: "#",
        onClick: e => e.preventDefault(),
        style: {
          color: 'var(--cds-link-primary)',
          textDecoration: 'none',
          display: 'inline-flex',
          alignItems: 'center',
          gap: 4
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "document",
        size: 16
      }), "ELK");
      if (k === 'act') return r.status === 'Failed' || r.status === 'Retrying' ? /*#__PURE__*/React.createElement(Button, {
        kind: "ghost",
        size: "sm",
        icon: "renew"
      }, "Retry") : /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })));
}
const SLA = [{
  pipe: 'erp_to_gold',
  fresh: 'g',
  freshT: '14m ago',
  time: 'g',
  timeT: 'on time',
  lat: 'g',
  latT: '4m avg'
}, {
  pipe: 'mes_stream',
  fresh: 'a',
  freshT: '32m ago',
  time: 'a',
  timeT: '+8m',
  lat: 'g',
  latT: '1.4s'
}, {
  pipe: 'crm_sync',
  fresh: 'r',
  freshT: '3h ago',
  time: 'r',
  timeT: 'breached',
  lat: 'r',
  latT: 'failed'
}, {
  pipe: 'finance_daily',
  fresh: 'g',
  freshT: '6h ago',
  time: 'g',
  timeT: 'on time',
  lat: 'g',
  latT: '3m avg'
}, {
  pipe: 'logistics_etl',
  fresh: 'g',
  freshT: '20m ago',
  time: 'g',
  timeT: 'on time',
  lat: 'a',
  latT: '6m avg'
}];
const RAG = {
  g: 'var(--cds-support-success)',
  a: 'var(--cds-support-warning)',
  r: 'var(--cds-support-error)'
};
function Rag({
  s,
  t
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "mn-rag"
  }, /*#__PURE__*/React.createElement("span", {
    className: "sq",
    style: {
      background: RAG[s]
    }
  }), t);
}
function ResourceSla() {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "mn-grafana"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "dashboard",
    size: 16
  }), "Cluster health", /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--cds-support-success)'
    }
  }), "Grafana")), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__b"
  }, /*#__PURE__*/React.createElement(BarChart, {
    data: [55, 62, 48, 70, 65, 72, 60, 58, 66],
    height: 120
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)',
      marginTop: 8
    }
  }, "CPU 58% \xB7 Mem 64% \xB7 12 nodes healthy"))), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "watson",
    size: 16
  }), "Spark executors", /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--cds-support-success)'
    }
  }), "Grafana")), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__b"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "executor cores / shuffle read",
    icon: "chart--line",
    height: 120
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)',
      marginTop: 8
    }
  }, "48 cores \xB7 0 failed stages"))), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "data--base",
    size: 16
  }), "ClickHouse latency", /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--cds-support-warning)'
    }
  }), "Grafana")), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__b"
  }, /*#__PURE__*/React.createElement(Placeholder, {
    label: "p95 query latency (ms)",
    icon: "chart--line",
    height: 120
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)',
      marginTop: 8
    }
  }, "p95 312ms \xB7 QPS 1.2k"))), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chart--bar",
    size: 16
  }), "Ingestion throughput", /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: 'var(--cds-support-success)'
    }
  }), "Grafana")), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__b"
  }, /*#__PURE__*/React.createElement(BarChart, {
    data: [40, 55, 60, 72, 68, 80, 76],
    height: 120
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)',
      marginTop: 8
    }
  }, "1.8M events/min")))), /*#__PURE__*/React.createElement("div", {
    className: "mn-panel"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-panel__h"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "time",
    size: 16
  }), "Data SLA board"), /*#__PURE__*/React.createElement("table", {
    className: "mn-sla"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, "Pipeline"), /*#__PURE__*/React.createElement("th", null, "Freshness"), /*#__PURE__*/React.createElement("th", null, "Timeliness"), /*#__PURE__*/React.createElement("th", null, "Latency"), /*#__PURE__*/React.createElement("th", null, "SLA"))), /*#__PURE__*/React.createElement("tbody", null, SLA.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.pipe
  }, /*#__PURE__*/React.createElement("td", {
    className: "pipe"
  }, r.pipe), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Rag, {
    s: r.fresh,
    t: r.freshT
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Rag, {
    s: r.time,
    t: r.timeT
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Rag, {
    s: r.lat,
    t: r.latT
  })), /*#__PURE__*/React.createElement("td", null, r.fresh === 'r' || r.time === 'r' || r.lat === 'r' ? /*#__PURE__*/React.createElement(Tag, {
    type: "red",
    size: "sm"
  }, "Breached") : r.fresh === 'a' || r.time === 'a' || r.lat === 'a' ? /*#__PURE__*/React.createElement(Tag, {
    type: "purple",
    size: "sm"
  }, "At risk") : /*#__PURE__*/React.createElement(Tag, {
    type: "green",
    size: "sm"
  }, "Met"))))))));
}
const ALERTS = [{
  id: 1,
  name: 'CRM sync freshness',
  cond: 'freshness > 30m',
  sev: 'Critical',
  status: 'Firing',
  at: '18m ago',
  target: '#data-sla'
}, {
  id: 2,
  name: 'ClickHouse p95 latency',
  cond: 'p95 > 500ms for 5m',
  sev: 'Warning',
  status: 'Firing',
  at: '42m ago',
  target: 'pager:data-oncall'
}, {
  id: 3,
  name: 'Kafka consumer lag',
  cond: 'lag > 100k',
  sev: 'Warning',
  status: 'Resolved',
  at: '2h ago',
  target: '#data-eng'
}, {
  id: 4,
  name: 'Pipeline failure rate',
  cond: 'failures > 5 / 1h',
  sev: 'Critical',
  status: 'Resolved',
  at: '5h ago',
  target: 'pager:data-oncall'
}, {
  id: 5,
  name: 'Disk usage — lakehouse',
  cond: 'usage > 85%',
  sev: 'Info',
  status: 'Resolved',
  at: 'Yesterday',
  target: '#infra'
}];
function Alerts({
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const cols = [{
    key: 'name',
    label: 'Alert',
    cellClass: 'name'
  }, {
    key: 'cond',
    label: 'Condition',
    cellClass: 'mono'
  }, {
    key: 'sev',
    label: 'Severity'
  }, {
    key: 'status',
    label: 'Status'
  }, {
    key: 'at',
    label: 'Triggered'
  }, {
    key: 'target',
    label: 'Route to',
    cellClass: 'mono'
  }, {
    key: 'act',
    label: '',
    sortable: false,
    width: 96
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "mn-cards"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "warning--filled",
    size: 16
  }), "Firing"), /*#__PURE__*/React.createElement("div", {
    className: "v fail"
  }, "2")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "warning--alt--filled",
    size: 16
  }), "Warning"), /*#__PURE__*/React.createElement("div", {
    className: "v retry"
  }, "1")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "checkmark--filled",
    size: 16
  }), "Resolved (24h)"), /*#__PURE__*/React.createElement("div", {
    className: "v ok"
  }, "14")), /*#__PURE__*/React.createElement("div", {
    className: "mn-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "notification--off",
    size: 16
  }), "Silenced"), /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, "1"))), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: "Search alert rules",
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Dropdown, {
      items: ['All severity', 'Critical', 'Warning', 'Info'],
      value: "All severity",
      onChange: () => {}
    }), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => setOpen(true)
    }, "New alert rule"))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: ALERTS,
    renderCell: (r, k) => {
      if (k === 'sev') return /*#__PURE__*/React.createElement(Tag, {
        type: r.sev === 'Critical' ? 'red' : r.sev === 'Warning' ? 'purple' : 'cool-gray',
        size: "sm"
      }, r.sev);
      if (k === 'status') return /*#__PURE__*/React.createElement(StatusDot, {
        kind: r.status === 'Firing' ? 'failed' : 'success'
      }, r.status);
      if (k === 'act') return r.status === 'Firing' ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
        kind: "ghost",
        size: "sm",
        onClick: () => notify && notify({
          kind: 'info',
          title: 'Alert acknowledged'
        })
      }, "Ack"), /*#__PURE__*/React.createElement(Button, {
        kind: "ghost",
        size: "sm",
        icon: "notification--off",
        iconOnly: true,
        title: "Silence"
      })) : /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: "Alerts",
    title: "New alert rule",
    onClose: () => setOpen(false),
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "checkmark",
      onClick: () => {
        setOpen(false);
        notify && notify({
          kind: 'success',
          title: 'Alert rule created.'
        });
      }
    }, "Create rule"))
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Rule name",
    placeholder: "ClickHouse p95 latency"
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Metric",
    items: ['p95 latency', 'freshness', 'consumer lag', 'failure rate', 'disk usage'],
    value: "p95 latency",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Severity",
    items: ['Critical', 'Warning', 'Info'],
    value: "Warning",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: "Operator",
    items: ['>', '<', '>=', '<='],
    value: ">",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(TextInput, {
    label: "Threshold",
    defaultValue: "500ms"
  })), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Notification channel",
    items: ['#data-sla', '#data-eng', 'pager:data-oncall', '#infra'],
    value: "#data-sla",
    onChange: () => {}
  })));
}
const LOG_ROWS = [{
  ts: '14:32:08.421',
  lvl: 'info',
  src: 'airflow',
  msg: 'DAG erp_to_gold run 4821 succeeded in 11m04s'
}, {
  ts: '14:31:55.882',
  lvl: 'info',
  src: 'spark',
  msg: 'Stage 7 (conform_dims) completed — 48 tasks'
}, {
  ts: '14:30:12.004',
  lvl: 'warn',
  src: 'clickhouse',
  msg: 'Query 0x9f3a exceeded p95 latency target (612ms)'
}, {
  ts: '14:28:41.317',
  lvl: 'error',
  src: 'debezium',
  msg: 'crm-cdc connector RESTART_FAILED: cannot reach crm-sqlserver:1433'
}, {
  ts: '14:27:03.559',
  lvl: 'info',
  src: 'iceberg',
  msg: 'Committed snapshot 7741200933 to gold.fact_production'
}, {
  ts: '14:25:48.230',
  lvl: 'warn',
  src: 'dq-engine',
  msg: 'Rule silver.orders.customer_id NOT NULL — 142 failing rows'
}, {
  ts: '14:24:19.901',
  lvl: 'info',
  src: 'trino',
  msg: 'Federated query routed to ClickHouse (cost-based)'
}, {
  ts: '14:22:55.118',
  lvl: 'error',
  src: 'airflow',
  msg: 'Task crm_sync.load_customers failed (attempt 3/3) — see Sentry IPAS-2291'
}, {
  ts: '14:21:30.447',
  lvl: 'info',
  src: 'keycloak',
  msg: 'Token issued for lmarsh@ipas (group /ipas/engineers)'
}];
function Logs() {
  const [lvl, setLvl] = React.useState('All levels');
  const rows = LOG_ROWS.filter(r => lvl === 'All levels' || r.lvl === lvl.toLowerCase());
  return /*#__PURE__*/React.createElement("div", {
    className: "mn-log"
  }, /*#__PURE__*/React.createElement("div", {
    className: "mn-log__bar"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement(Search, {
    size: "md",
    placeholder: "Filter logs \u2014 query, source, trace id\u2026"
  })), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['All levels', 'Info', 'Warn', 'Error'],
    value: lvl,
    onChange: setLvl
  }), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['All sources', 'airflow', 'spark', 'clickhouse', 'debezium', 'trino'],
    value: "All sources",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    items: ['Last 15m', 'Last 1h', 'Last 24h'],
    value: "Last 1h",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "sm",
    icon: "renew",
    iconOnly: true,
    title: "Refresh"
  })), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "mn-log__row"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mn-log__ts"
  }, r.ts), /*#__PURE__*/React.createElement("span", {
    className: `mn-log__lvl ${r.lvl}`
  }, r.lvl.toUpperCase()), /*#__PURE__*/React.createElement("span", {
    className: "mn-log__src"
  }, r.src), /*#__PURE__*/React.createElement("span", {
    className: "mn-log__msg"
  }, r.msg, r.lvl === 'error' && /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault(),
    style: {
      color: '#ff8389',
      marginLeft: 8
    }
  }, "\u2192 Sentry")))));
}
const MON_SUBS = [{
  id: 'tasks',
  label: 'Task monitoring'
}, {
  id: 'sla',
  label: 'Resource & SLA'
}, {
  id: 'alerts',
  label: 'Alerts'
}, {
  id: 'logs',
  label: 'Logs'
}];
function Monitoring({
  notify,
  lang
}) {
  const [sub, setSub] = React.useState('tasks');
  const TITLES = {
    tasks: ['Task monitoring', 'Live ETL run status with logs and failure recovery.'],
    sla: ['Resource & SLA monitoring', 'Cluster, Spark, and ClickHouse health plus per-pipeline data SLAs.'],
    alerts: ['Alerts', 'Threshold and condition-based alert rules with severity and routing.'],
    logs: ['Log explorer', 'Search platform logs across services, levels, and time ranges.']
  };
  const [t, s] = TITLES[sub];
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: ['Monitoring & Ops', t].map(c => tr(lang, c)),
    title: tr(lang, t),
    sub: tr(lang, s)
  }), /*#__PURE__*/React.createElement(SubSwitch, {
    items: trList(lang, MON_SUBS),
    value: sub,
    onChange: setSub
  }), sub === 'tasks' && /*#__PURE__*/React.createElement(TaskMonitoring, null), sub === 'sla' && /*#__PURE__*/React.createElement(ResourceSla, null), sub === 'alerts' && /*#__PURE__*/React.createElement(Alerts, {
    notify: notify
  }), sub === 'logs' && /*#__PURE__*/React.createElement(Logs, null));
}
Object.assign(window, {
  Monitoring
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Monitoring.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Notifications.jsx
try { (() => {
/* global React, SidePanel, StatusDot, tr */
const {
  Icon,
  Button,
  Tag
} = window.CarbonDesignSystem_280d33;

/* ---- notification model ---- */
const NOTIF_META = {
  'pipeline-success': {
    icon: 'checkmark--filled',
    color: 'var(--cds-support-success)'
  },
  'pipeline-fail': {
    icon: 'error--filled',
    color: 'var(--cds-support-error)'
  },
  'pipeline-running': {
    icon: 'renew',
    color: 'var(--cds-blue-60)'
  },
  'quality': {
    icon: 'warning--alt--filled',
    color: 'var(--cds-support-warning)'
  },
  'sla': {
    icon: 'warning--filled',
    color: 'var(--cds-support-error)'
  },
  'access': {
    icon: 'user--follow',
    color: 'var(--cds-blue-60)'
  },
  'system': {
    icon: 'information--filled',
    color: 'var(--cds-text-secondary)'
  },
  'mention': {
    icon: 'chat',
    color: 'var(--cds-purple-60,#8a3ffc)'
  }
};
const SEED_NOTIFS = [{
  id: 'n1',
  type: 'access',
  title: 'Access request',
  desc: 'Ade Okafor requested the Analyst role on gold.fact_production.',
  ts: '2 min ago',
  unread: true,
  request: true
}, {
  id: 'n2',
  type: 'pipeline-fail',
  title: 'Pipeline failed',
  desc: 'crm_sync · load_customers failed after 3 retries.',
  ts: '14 min ago',
  unread: true
}, {
  id: 'n3',
  type: 'sla',
  title: 'SLA breach',
  desc: 'crm_sync freshness SLA breached (3h vs 30m target).',
  ts: '18 min ago',
  unread: true
}, {
  id: 'n4',
  type: 'quality',
  title: 'Data quality alert',
  desc: 'silver.orders.customer_id — 142 null rows (High).',
  ts: '32 min ago',
  unread: true
}, {
  id: 'n5',
  type: 'mention',
  title: 'Mentioned you',
  desc: 'R. Vance: “@lmarsh can you certify this metric?”',
  ts: '1 hour ago',
  unread: true,
  mention: true
}, {
  id: 'n6',
  type: 'pipeline-success',
  title: 'Pipeline completed',
  desc: 'erp_to_gold finished in 11m 04s.',
  ts: '1 hour ago',
  unread: false
}, {
  id: 'n7',
  type: 'system',
  title: 'Platform update',
  desc: 'ClickHouse upgraded to 24.3 · maintenance window closed.',
  ts: 'Yesterday',
  unread: false
}];
function NotificationsPanel({
  lang,
  notifs,
  onClose,
  onMarkAll,
  onAct,
  onDismiss,
  onRead
}) {
  const [tab, setTab] = React.useState('all');
  const list = notifs.filter(n => tab === 'all' ? true : tab === 'unread' ? n.unread : n.mention);
  return /*#__PURE__*/React.createElement(SidePanel, {
    sup: tr(lang, 'Notifications'),
    title: tr(lang, 'Notifications'),
    width: 400,
    onClose: onClose,
    footer: /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: onMarkAll
    }, tr(lang, 'Mark all as read')), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "settings"
    }, tr(lang, 'Settings')))
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      margin: '-20px -24px 0',
      display: 'flex',
      flexDirection: 'column',
      flex: 1,
      minHeight: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-notif__tabs"
  }, [['all', 'All'], ['unread', 'Unread'], ['mentions', 'Mentions']].map(([id, lbl]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    className: tab === id ? 'on' : '',
    onClick: () => setTab(id)
  }, tr(lang, lbl), id === 'unread' && notifs.some(n => n.unread) ? ` (${notifs.filter(n => n.unread).length})` : ''))), /*#__PURE__*/React.createElement("div", {
    style: {
      overflow: 'auto',
      flex: 1
    }
  }, list.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 48,
      textAlign: 'center',
      color: 'var(--cds-text-secondary)',
      fontSize: '.875rem'
    }
  }, tr(lang, 'Nothing here.')) : list.map(n => {
    const m = NOTIF_META[n.type] || NOTIF_META.system;
    return /*#__PURE__*/React.createElement("div", {
      key: n.id,
      className: `w-notif ${n.unread ? 'unread' : ''}`,
      onClick: () => onRead(n.id)
    }, /*#__PURE__*/React.createElement("span", {
      className: "w-notif__ic",
      style: {
        color: m.color
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: m.icon,
      size: 20
    })), /*#__PURE__*/React.createElement("div", {
      className: "w-notif__bd"
    }, /*#__PURE__*/React.createElement("div", {
      className: "t"
    }, n.title), /*#__PURE__*/React.createElement("div", {
      className: "d"
    }, n.desc), /*#__PURE__*/React.createElement("div", {
      className: "ts"
    }, n.ts), n.request && /*#__PURE__*/React.createElement("div", {
      className: "w-notif__req"
    }, /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "sm",
      onClick: e => {
        e.stopPropagation();
        onAct(n.id, 'approve');
      }
    }, tr(lang, 'Approve')), /*#__PURE__*/React.createElement(Button, {
      kind: "tertiary",
      size: "sm",
      onClick: e => {
        e.stopPropagation();
        onAct(n.id, 'deny');
      }
    }, tr(lang, 'Deny')))), n.unread && /*#__PURE__*/React.createElement("span", {
      className: "w-notif__dot"
    }));
  }))));
}
Object.assign(window, {
  NotificationsPanel,
  SEED_NOTIFS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Notifications.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Profile.jsx
try { (() => {
/* global React, PageHead, WireTable, TableToolbar, Overflow, StatusDot, Modal, tr */
const {
  Icon,
  Tag,
  Button,
  TextInput,
  Dropdown,
  Toggle,
  Checkbox,
  Tabs
} = window.CarbonDesignSystem_280d33;
const PR_CSS = `
.pr-card { background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:24px; max-width:760px; }
.pr-id { display:flex; align-items:center; gap:20px; margin-bottom:24px; }
.pr-id .av { width:72px; height:72px; border-radius:50%; background:var(--cds-blue-60); color:#fff; display:flex; align-items:center; justify-content:center; font-size:1.5rem; font-weight:600; flex:0 0 72px; }
.pr-id .nm { font-size:1.25rem; font-weight:600; color:var(--cds-text-primary); }
.pr-id .em { font-size:.875rem; color:var(--cds-text-secondary); font-family:var(--cds-font-mono); }
.pr-id .badges { display:flex; gap:6px; margin-top:8px; }
.pr-ro { display:inline-flex; align-items:center; gap:6px; font-size:.6875rem; color:var(--cds-text-secondary); background:var(--cds-layer-01); border:1px solid var(--wire-border); padding:3px 8px; }
.pr-matrix { width:100%; border-collapse:collapse; border:1px solid var(--wire-border); font-size:.8125rem; }
.pr-matrix th, .pr-matrix td { border:1px solid var(--wire-border); padding:8px 12px; text-align:center; }
.pr-matrix th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.pr-matrix td:first-child, .pr-matrix th:first-child { text-align:left; color:var(--cds-text-primary); font-weight:500; }
.pr-matrix input { accent-color:var(--cds-blue-60); width:16px; height:16px; }
.pr-grp { margin-bottom:28px; }
.pr-grp h3 { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); margin:0 0 4px; }
.pr-grp p.h { font-size:.75rem; color:var(--cds-text-secondary); margin:0 0 14px; }
`;
(function () {
  if (!document.getElementById('ipas-pr-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-pr-styles';
    e.textContent = PR_CSS;
    document.head.appendChild(e);
  }
})();
function MyProfile({
  lang
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pr-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pr-id"
  }, /*#__PURE__*/React.createElement("span", {
    className: "av"
  }, "LM"), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "nm"
  }, "Lena Marsh"), /*#__PURE__*/React.createElement("div", {
    className: "em"
  }, "lmarsh@ipas"), /*#__PURE__*/React.createElement("div", {
    className: "badges"
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm"
  }, tr(lang, 'Data Engineer')), /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "Manufacturing")))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "pr-ro"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "locked",
    size: 14
  }), tr(lang, 'Identity fields are managed in corporate IAM (read-only).'))), /*#__PURE__*/React.createElement("div", {
    className: "w-dl"
  }, /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Full name')), /*#__PURE__*/React.createElement("dd", null, "Lena Marsh"), /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Email')), /*#__PURE__*/React.createElement("dd", null, "lmarsh@ipas"), /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Department')), /*#__PURE__*/React.createElement("dd", null, "Manufacturing Analytics"), /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Identity source')), /*#__PURE__*/React.createElement("dd", null, "Active Directory \xB7 SCIM"), /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Member since')), /*#__PURE__*/React.createElement("dd", null, "Mar 2024"), /*#__PURE__*/React.createElement("dt", null, tr(lang, 'Roles')), /*#__PURE__*/React.createElement("dd", null, "Data Engineer, Steward")));
}
function Preferences({
  lang,
  notify
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pr-card"
  }, /*#__PURE__*/React.createElement("div", {
    className: "pr-grp"
  }, /*#__PURE__*/React.createElement("h3", null, tr(lang, 'Appearance')), /*#__PURE__*/React.createElement("p", {
    className: "h"
  }, tr(lang, 'Choose how the platform looks.')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, ['Light', 'Dark', 'High contrast'].map((m, i) => /*#__PURE__*/React.createElement(Button, {
    key: m,
    kind: i === 0 ? 'primary' : 'tertiary',
    size: "md"
  }, tr(lang, m))))), /*#__PURE__*/React.createElement("div", {
    className: "pr-grp"
  }, /*#__PURE__*/React.createElement("h3", null, tr(lang, 'Localization & defaults')), /*#__PURE__*/React.createElement("div", {
    className: "w-row",
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Language'),
    items: ['English', '中文'],
    value: lang === 'zh' ? '中文' : 'English',
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Timezone'),
    items: ['UTC', 'America/New_York', 'Asia/Shanghai'],
    value: "Asia/Shanghai",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row",
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Default landing page'),
    items: ['Home / Overview', 'Dashboards', 'Pipelines'],
    value: "Home / Overview",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Default query engine'),
    items: ['Auto', 'ClickHouse', 'Trino'],
    value: "Auto",
    onChange: () => {}
  })), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Table page size'),
    items: ['10', '25', '50'],
    value: "25",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Date format'),
    items: ['YYYY-MM-DD', 'DD/MM/YYYY', 'MM/DD/YYYY'],
    value: "YYYY-MM-DD",
    onChange: () => {}
  }))), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    icon: "save",
    onClick: () => notify && notify({
      kind: 'success',
      title: tr(lang, 'Preferences saved.')
    })
  }, tr(lang, 'Save preferences')));
}
const NOTIF_EVENTS = ['Pipeline success', 'Pipeline failure', 'Quality alert', 'SLA breach', 'Access request', 'Mentions', 'Announcements'];
function NotificationSettings({
  lang,
  notify
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "pr-card",
    style: {
      maxWidth: 680
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pr-grp",
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h3", null, tr(lang, 'Notification channels')), /*#__PURE__*/React.createElement("p", {
    className: "h"
  }, tr(lang, 'Pick how you are notified for each event type.'))), /*#__PURE__*/React.createElement("table", {
    className: "pr-matrix"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, tr(lang, 'Event')), /*#__PURE__*/React.createElement("th", null, tr(lang, 'In-app')), /*#__PURE__*/React.createElement("th", null, tr(lang, 'Email')), /*#__PURE__*/React.createElement("th", null, "IM"))), /*#__PURE__*/React.createElement("tbody", null, NOTIF_EVENTS.map((e, i) => /*#__PURE__*/React.createElement("tr", {
    key: e
  }, /*#__PURE__*/React.createElement("td", null, tr(lang, e)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: true
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: i < 4
  })), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    defaultChecked: i === 1 || i === 3
  })))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 24,
      margin: '20px 0',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Toggle, {
    size: "sm",
    label: tr(lang, 'Daily digest instead of per-event email')
  }), /*#__PURE__*/React.createElement(Toggle, {
    size: "sm",
    label: tr(lang, 'Mute 22:00–07:00'),
    defaultChecked: true
  })), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    icon: "save",
    onClick: () => notify && notify({
      kind: 'success',
      title: tr(lang, 'Notification settings saved.')
    })
  }, tr(lang, 'Save settings')));
}
function MyPermissions({
  lang
}) {
  const cols = [{
    key: 'asset',
    label: tr(lang, 'Asset'),
    cellClass: 'mono'
  }, {
    key: 'access',
    label: tr(lang, 'Access')
  }, {
    key: 'masking',
    label: tr(lang, 'Masking applied')
  }];
  const rows = [{
    asset: 'gold.fact_production',
    access: 'Read / Write',
    masking: 'None'
  }, {
    asset: 'gold.dim_product',
    access: 'Read',
    masking: 'None'
  }, {
    asset: 'silver.orders',
    access: 'Read',
    masking: 'customer_id → hash'
  }, {
    asset: 'silver.customers',
    access: 'Read',
    masking: 'email → partial, ssn → full'
  }, {
    asset: 'gold.spc_xbar_r_chart',
    access: 'Read',
    masking: 'row filter: process_id IN (P1,P2)'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 16,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "pr-ro"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "security",
    size: 14
  }), tr(lang, 'Effective access — computed from your roles & policies'))), /*#__PURE__*/React.createElement("div", {
    className: "pr-grp",
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("h3", null, tr(lang, 'My roles')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "md"
  }, "Data Engineer"), /*#__PURE__*/React.createElement(Tag, {
    type: "purple",
    size: "md"
  }, "Steward"))), /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap",
    style: {
      maxWidth: 920
    }
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: tr(lang, 'Search assets I can access'),
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add"
    }, tr(lang, 'Request access'))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: rows,
    footer: false,
    renderCell: (r, k) => k === 'masking' ? r.masking === 'None' ? /*#__PURE__*/React.createElement(Tag, {
      type: "green",
      size: "sm"
    }, "None") : /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: 'var(--cds-font-mono)',
        fontSize: '.75rem'
      }
    }, r.masking) : r[k]
  })));
}
function MyApiKeys({
  lang,
  notify
}) {
  const [open, setOpen] = React.useState(false);
  const [created, setCreated] = React.useState(false);
  const cols = [{
    key: 'name',
    label: tr(lang, 'Name'),
    cellClass: 'name'
  }, {
    key: 'prefix',
    label: tr(lang, 'Token'),
    cellClass: 'mono'
  }, {
    key: 'scope',
    label: tr(lang, 'Scopes')
  }, {
    key: 'used',
    label: tr(lang, 'Last used')
  }, {
    key: 'ofw',
    label: '',
    sortable: false,
    width: 48
  }];
  const rows = [{
    name: 'personal-cli',
    prefix: 'ipas_pat_4f9a…',
    scope: 'read:gold',
    used: '2 hours ago'
  }, {
    name: 'notebook-dev',
    prefix: 'ipas_pat_b21c…',
    scope: 'read:silver, read:gold',
    used: 'Yesterday'
  }];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap",
    style: {
      maxWidth: 920
    }
  }, /*#__PURE__*/React.createElement(TableToolbar, {
    placeholder: tr(lang, 'Search keys'),
    search: "",
    onSearch: () => {},
    actions: /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      size: "lg",
      icon: "add",
      onClick: () => {
        setOpen(true);
        setCreated(false);
      }
    }, tr(lang, 'Create API key'))
  }), /*#__PURE__*/React.createElement(WireTable, {
    columns: cols,
    rows: rows,
    footer: false,
    renderCell: (r, k) => {
      if (k === 'scope') return /*#__PURE__*/React.createElement(Tag, {
        type: "cool-gray",
        size: "sm"
      }, r.scope);
      if (k === 'ofw') return /*#__PURE__*/React.createElement(Overflow, null);
      return r[k];
    }
  })), open && /*#__PURE__*/React.createElement(Modal, {
    sup: tr(lang, 'Personal access token'),
    title: tr(lang, 'Create API key'),
    onClose: () => setOpen(false),
    footer: created ? /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      onClick: () => setOpen(false)
    }, tr(lang, 'Done')) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Button, {
      kind: "secondary",
      onClick: () => setOpen(false)
    }, tr(lang, 'Cancel')), /*#__PURE__*/React.createElement(Button, {
      kind: "primary",
      icon: "add",
      onClick: () => {
        setCreated(true);
      }
    }, tr(lang, 'Generate token')))
  }, created ? /*#__PURE__*/React.createElement("div", {
    className: "w-fld"
  }, /*#__PURE__*/React.createElement("label", null, tr(lang, 'Copy this token now — it will not be shown again.')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      fontFamily: 'var(--cds-font-mono)',
      fontSize: '.8125rem',
      background: 'var(--cds-gray-100)',
      color: '#f4f4f4',
      padding: '12px 14px',
      wordBreak: 'break-all'
    }
  }, "ipas_pat_9e2b7c41a8f0d3654b9012ee"), /*#__PURE__*/React.createElement(Button, {
    kind: "tertiary",
    icon: "copy",
    onClick: () => notify && notify({
      kind: 'info',
      title: tr(lang, 'Token copied.')
    })
  }, tr(lang, 'Copy')))) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(TextInput, {
    label: tr(lang, 'Key name'),
    placeholder: "personal-cli"
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Scope'),
    items: ['read:gold', 'read:silver', 'write:pipelines'],
    value: "read:gold",
    onChange: () => {}
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: tr(lang, 'Expiry'),
    items: ['30 days', '90 days', '1 year', 'No expiry'],
    value: "90 days",
    onChange: () => {}
  })))));
}
function Sessions({
  lang,
  notify
}) {
  const sessions = [{
    dev: 'MacBook Pro · Chrome',
    loc: 'Shanghai, CN',
    ip: '10.4.22.18',
    when: 'Active now',
    cur: true
  }, {
    dev: 'iPhone 15 · Safari',
    loc: 'Shanghai, CN',
    ip: '10.4.30.9',
    when: '3 hours ago'
  }, {
    dev: 'Windows · Edge',
    loc: 'Singapore, SG',
    ip: '52.187.11.4',
    when: '2 days ago'
  }];
  return /*#__PURE__*/React.createElement("div", {
    className: "pr-card",
    style: {
      maxWidth: 760
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "pr-grp",
    style: {
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("h3", null, tr(lang, 'Active sessions')), /*#__PURE__*/React.createElement("p", {
    className: "h"
  }, tr(lang, 'Your password is managed in corporate SSO (Keycloak).'))), sessions.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '12px 0',
      borderBottom: i < sessions.length - 1 ? '1px solid var(--wire-border)' : 'none'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: s.dev.includes('iPhone') ? 'mobile' : 'laptop',
    size: 20,
    style: {
      color: 'var(--cds-icon-secondary)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.8125rem',
      color: 'var(--cds-text-primary)',
      fontWeight: 500
    }
  }, s.dev, s.cur && /*#__PURE__*/React.createElement(Tag, {
    type: "green",
    size: "sm",
    style: {
      marginLeft: 8
    }
  }, tr(lang, 'This device'))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: '.75rem',
      color: 'var(--cds-text-secondary)',
      fontFamily: 'var(--cds-font-mono)'
    }
  }, s.loc, " \xB7 ", s.ip, " \xB7 ", s.when)), !s.cur && /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "sm",
    onClick: () => notify && notify({
      kind: 'info',
      title: tr(lang, 'Session signed out.')
    })
  }, tr(lang, 'Sign out')))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "danger",
    size: "md",
    icon: "logout",
    onClick: () => notify && notify({
      kind: 'info',
      title: tr(lang, 'Signed out of all other sessions.')
    })
  }, tr(lang, 'Sign out all other sessions'))));
}
const PR_TABS = [{
  id: 'profile',
  label: 'My profile'
}, {
  id: 'prefs',
  label: 'Preferences'
}, {
  id: 'notify',
  label: 'Notification settings'
}, {
  id: 'perms',
  label: 'My permissions'
}, {
  id: 'keys',
  label: 'API keys'
}, {
  id: 'sessions',
  label: 'Security & sessions'
}];
function Profile({
  tab,
  lang,
  notify,
  onNavigate
}) {
  const idx = Math.max(0, PR_TABS.findIndex(t => t.id === (tab || 'profile')));
  return /*#__PURE__*/React.createElement("div", {
    className: "w-page"
  }, /*#__PURE__*/React.createElement(PageHead, {
    crumb: [tr(lang, 'Personal center'), tr(lang, PR_TABS[idx].label)],
    title: tr(lang, 'Personal center'),
    sub: tr(lang, 'Your profile, preferences, permissions, and security.')
  }), /*#__PURE__*/React.createElement(Tabs, {
    selectedIndex: idx,
    tabs: PR_TABS.map(t => ({
      label: tr(lang, t.label),
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 16
        }
      }, t.id === 'profile' && /*#__PURE__*/React.createElement(MyProfile, {
        lang: lang
      }), t.id === 'prefs' && /*#__PURE__*/React.createElement(Preferences, {
        lang: lang,
        notify: notify
      }), t.id === 'notify' && /*#__PURE__*/React.createElement(NotificationSettings, {
        lang: lang,
        notify: notify
      }), t.id === 'perms' && /*#__PURE__*/React.createElement(MyPermissions, {
        lang: lang
      }), t.id === 'keys' && /*#__PURE__*/React.createElement(MyApiKeys, {
        lang: lang,
        notify: notify
      }), t.id === 'sessions' && /*#__PURE__*/React.createElement(Sessions, {
        lang: lang,
        notify: notify
      }))
    }))
  }));
}
Object.assign(window, {
  Profile
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Profile.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Shell.jsx
try { (() => {
/* global React, tr, Menu, MenuItem */
const {
  Icon,
  Search,
  Tag
} = window.CarbonDesignSystem_280d33;
const IPAS_SHELL_CSS = `
.ip-shell { min-height:100vh; background:var(--cds-background); font-family:var(--cds-font-sans); display:flex; }

/* ---- custom borderless sidebar (no divider with content) ---- */
.ip-sidenav { width:272px; flex:0 0 272px; box-sizing:border-box; background:var(--cds-background);
  display:flex; flex-direction:column; padding:28px 16px; position:sticky; top:0; align-self:flex-start; height:100vh;
  transition:width .11s, flex-basis .11s; }
.ip-sidenav.collapsed { width:72px; flex-basis:72px; padding:28px 12px; align-items:stretch; }

/* brand: SiPTORY InSight (InSight = filled Carbon-blue box, white semibold) */
.ip-brand { display:flex; align-items:center; gap:8px; padding:0 8px; min-height:32px; }
.ip-brand .word { font-size:1.0625rem; font-weight:600; color:var(--cds-text-primary); letter-spacing:.1px; }
.ip-brand .badge { font-size:1.0625rem; font-weight:600; color:#fff; background:var(--cds-blue-60); padding:2px 9px; letter-spacing:.1px; }
.ip-brand .mark { display:none; width:32px; height:32px; background:var(--cds-blue-60); color:#fff; font-weight:600; font-size:.875rem; align-items:center; justify-content:center; }
.ip-sidenav.collapsed .ip-brand { justify-content:center; padding:0; }
.ip-sidenav.collapsed .ip-brand .word, .ip-sidenav.collapsed .ip-brand .badge { display:none; }
.ip-sidenav.collapsed .ip-brand .mark { display:flex; }

/* sidebar global search */
.ip-search { margin-top:20px; padding:0 4px; }
.ip-sidenav.collapsed .ip-search { display:none; }

/* nav block — vertically centered in the remaining space */
.ip-nav { flex:1; display:flex; flex-direction:column; justify-content:center; gap:2px; }
.ip-navitem { display:flex; align-items:center; gap:14px; height:44px; padding:0 12px; font-size:.9375rem; color:var(--cds-text-secondary);
  cursor:pointer; border:none; background:transparent; width:100%; text-align:left; box-sizing:border-box; border-left:3px solid transparent; white-space:nowrap; }
.ip-navitem:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.ip-navitem.active { background:var(--cds-layer-selected-01); color:var(--cds-text-primary); font-weight:600; border-left-color:var(--cds-border-interactive); }
.ip-navitem .ic { flex:0 0 18px; display:flex; }
.ip-sidenav.collapsed .ip-navitem { justify-content:center; gap:0; padding:0; }
.ip-sidenav.collapsed .ip-navitem .t { display:none; }

/* footer operations (collapsed from the old header) */
.ip-foot { display:flex; flex-direction:column; gap:14px; }
.ip-utility { display:flex; align-items:center; gap:2px; padding:0 4px; }
.ip-sidenav.collapsed .ip-utility { flex-direction:column; }
.ip-ubtn { width:40px; height:40px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent;
  color:var(--cds-icon-secondary); cursor:pointer; position:relative; }
.ip-ubtn:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.ip-ubtn .ndot { position:absolute; top:9px; right:9px; width:7px; height:7px; border-radius:50%; background:var(--cds-blue-60); border:1px solid var(--cds-background); }
.ip-ubtn .ncount { position:absolute; top:4px; right:2px; min-width:16px; height:16px; padding:0 4px; box-sizing:border-box; border-radius:8px; background:var(--cds-support-error); color:#fff; font-size:.625rem; font-weight:600; display:flex; align-items:center; justify-content:center; border:1px solid var(--cds-background); }
.ip-ubtn.on { background:var(--cds-layer-selected-01); color:var(--cds-text-primary); }
.ip-lang { min-width:40px; height:40px; padding:0 8px; font-size:.8125rem; font-weight:600; letter-spacing:.16px; }
.ip-collapse { margin-left:auto; }
.ip-sidenav.collapsed .ip-collapse { margin-left:0; }
.ip-user { display:flex; align-items:center; gap:10px; padding:6px 6px; }
.ip-user .av { width:32px; height:32px; border-radius:50%; background:var(--cds-blue-60); color:#fff; display:flex; align-items:center; justify-content:center; font-size:.75rem; font-weight:600; flex:0 0 32px; }
.ip-user .nm { font-size:.8125rem; color:var(--cds-text-primary); font-weight:500; line-height:1.2; }
.ip-user .rl { font-size:.6875rem; color:var(--cds-text-secondary); line-height:1.3; }
.ip-sidenav.collapsed .ip-user { justify-content:center; padding:0; }
.ip-sidenav.collapsed .ip-user .meta { display:none; }

.ip-main { flex:1; min-width:0; background:var(--cds-background); }
`;
function injectIpShell() {
  if (typeof document === 'undefined' || document.getElementById('ipas-shell-styles')) return;
  const el = document.createElement('style');
  el.id = 'ipas-shell-styles';
  el.textContent = IPAS_SHELL_CSS;
  document.head.appendChild(el);
}
const IPAS_NAV = [{
  id: 'overview',
  label: 'Home / Overview',
  icon: 'home'
}, {
  id: 'analytics',
  label: 'Self-Service Analytics',
  icon: 'dashboard'
}, {
  id: 'modeling',
  label: 'Data Modeling & Semantics',
  icon: 'data--base'
}, {
  id: 'devconfig',
  label: 'Data Development / Config',
  icon: 'code'
}, {
  id: 'governance',
  label: 'Data Assets & Governance',
  icon: 'folder'
}, {
  id: 'monitoring',
  label: 'Monitoring & Ops',
  icon: 'chart--line'
}, {
  id: 'admin',
  label: 'Platform Admin',
  icon: 'settings'
}];
function IpSideNav({
  current,
  onSelect,
  collapsed,
  onToggle,
  onHome,
  lang,
  onLang,
  unread,
  onNotifications,
  onProfile,
  onAppearance
}) {
  injectIpShell();
  const [menu, setMenu] = React.useState(null); // 'user' | 'help'
  const [rect, setRect] = React.useState(null);
  const openMenu = (which, e) => {
    setRect(e.currentTarget.getBoundingClientRect());
    setMenu(which);
  };
  const go = fn => {
    setMenu(null);
    fn && fn();
  };
  return /*#__PURE__*/React.createElement("nav", {
    className: `ip-sidenav ${collapsed ? 'collapsed' : ''}`,
    "aria-label": "Product navigation"
  }, /*#__PURE__*/React.createElement("a", {
    className: "ip-brand",
    href: "#",
    onClick: e => {
      e.preventDefault();
      onHome && onHome();
    },
    "aria-label": "SiPTORY InSight \u2014 home"
  }, /*#__PURE__*/React.createElement("span", {
    className: "word"
  }, "SiPTORY"), /*#__PURE__*/React.createElement("span", {
    className: "badge"
  }, "InSight"), /*#__PURE__*/React.createElement("span", {
    className: "mark"
  }, "iS")), /*#__PURE__*/React.createElement("div", {
    className: "ip-search"
  }, /*#__PURE__*/React.createElement(Search, {
    size: "md",
    placeholder: tr(lang, 'Search platform')
  })), /*#__PURE__*/React.createElement("div", {
    className: "ip-nav"
  }, IPAS_NAV.map(n => /*#__PURE__*/React.createElement("button", {
    key: n.id,
    className: `ip-navitem ${current === n.id ? 'active' : ''}`,
    onClick: () => onSelect(n.id),
    title: tr(lang, n.label)
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon,
    size: 18
  })), /*#__PURE__*/React.createElement("span", {
    className: "t"
  }, tr(lang, n.label))))), /*#__PURE__*/React.createElement("div", {
    className: "ip-foot"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ip-utility"
  }, /*#__PURE__*/React.createElement("button", {
    className: "ip-ubtn ip-lang",
    "aria-label": "Switch language",
    title: "\u4E2D\u6587 / English",
    onClick: () => onLang(lang === 'zh' ? 'en' : 'zh')
  }, lang === 'zh' ? 'EN' : '中'), /*#__PURE__*/React.createElement("button", {
    className: "ip-ubtn",
    "aria-label": tr(lang, 'Notifications'),
    title: tr(lang, 'Notifications'),
    onClick: onNotifications
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "notification",
    size: 20
  }), unread > 0 && /*#__PURE__*/React.createElement("span", {
    className: "ncount"
  }, unread)), /*#__PURE__*/React.createElement("button", {
    className: `ip-ubtn ${menu === 'help' ? 'on' : ''}`,
    "aria-label": tr(lang, 'Help'),
    title: tr(lang, 'Help'),
    onClick: e => openMenu('help', e)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "help",
    size: 20
  })), /*#__PURE__*/React.createElement("button", {
    className: "ip-ubtn ip-collapse",
    "aria-label": "Collapse navigation",
    onClick: onToggle
  }, /*#__PURE__*/React.createElement(Icon, {
    name: collapsed ? 'chevron--right' : 'chevron--left',
    size: 20
  }))), /*#__PURE__*/React.createElement("button", {
    className: `ip-user ${menu === 'user' ? 'on' : ''}`,
    style: {
      border: 'none',
      background: menu === 'user' ? 'var(--cds-layer-selected-01)' : 'transparent',
      width: '100%',
      cursor: 'pointer',
      textAlign: 'left'
    },
    onClick: e => openMenu('user', e)
  }, /*#__PURE__*/React.createElement("span", {
    className: "av"
  }, "LM"), /*#__PURE__*/React.createElement("span", {
    className: "meta"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nm"
  }, "Lena Marsh"), /*#__PURE__*/React.createElement("div", {
    className: "rl"
  }, tr(lang, 'Data Engineer'))))), menu === 'help' && /*#__PURE__*/React.createElement(Menu, {
    anchorRect: rect,
    width: 240,
    onClose: () => setMenu(null)
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-menu__lbl"
  }, tr(lang, 'Help & resources')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "document",
    onClick: () => setMenu(null)
  }, tr(lang, 'Documentation')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "keyboard",
    meta: "\u2318 /",
    onClick: () => setMenu(null)
  }, tr(lang, 'Keyboard shortcuts')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "idea",
    onClick: () => setMenu(null)
  }, tr(lang, "What's new")), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "help-desk",
    onClick: () => setMenu(null)
  }, tr(lang, 'Support'))), menu === 'user' && /*#__PURE__*/React.createElement(Menu, {
    anchorRect: rect,
    width: 272,
    onClose: () => setMenu(null)
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-menu__hd"
  }, /*#__PURE__*/React.createElement("div", {
    className: "nm"
  }, "Lena Marsh"), /*#__PURE__*/React.createElement("div", {
    className: "sub"
  }, "lmarsh@ipas"), /*#__PURE__*/React.createElement("div", {
    className: "badges"
  }, /*#__PURE__*/React.createElement(Tag, {
    type: "blue",
    size: "sm"
  }, tr(lang, 'Data Engineer')), /*#__PURE__*/React.createElement(Tag, {
    type: "cool-gray",
    size: "sm"
  }, "Manufacturing"))), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "user",
    onClick: () => go(() => onProfile && onProfile('profile'))
  }, tr(lang, 'My profile')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "settings--adjust",
    onClick: () => go(() => onProfile && onProfile('prefs'))
  }, tr(lang, 'Preferences')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "security",
    onClick: () => go(() => onProfile && onProfile('perms'))
  }, tr(lang, 'My permissions')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "api",
    onClick: () => go(() => onProfile && onProfile('keys'))
  }, tr(lang, 'API keys')), /*#__PURE__*/React.createElement("div", {
    className: "w-menu__sep"
  }), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "enterprise",
    meta: "Manufacturing",
    onClick: () => setMenu(null)
  }, tr(lang, 'Switch organization')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "screen",
    meta: tr(lang, 'Light'),
    onClick: () => go(onAppearance)
  }, tr(lang, 'Appearance')), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "translate",
    meta: lang === 'zh' ? '中文' : 'English',
    onClick: () => go(() => onLang(lang === 'zh' ? 'en' : 'zh'))
  }, tr(lang, 'Language')), /*#__PURE__*/React.createElement("div", {
    className: "w-menu__sep"
  }), /*#__PURE__*/React.createElement(MenuItem, {
    icon: "logout",
    onClick: () => {
      setMenu(null);
      window.location.href = 'Login.html';
    }
  }, tr(lang, 'Sign out'))));
}
Object.assign(window, {
  IpSideNav,
  IPAS_NAV
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Shell.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/Welcome.jsx
try { (() => {
/* global React, tr */
const {
  Icon
} = window.CarbonDesignSystem_280d33;
const WELCOME_CSS = `
.wc { min-height:100vh; box-sizing:border-box; padding:56px 56px 64px; display:flex; flex-direction:column; justify-content:center; }
.wc-hero { display:flex; align-items:center; gap:40px; margin-bottom:48px; }
.wc-hero__text { flex:1; min-width:0; }
.wc-h1 { font-size:clamp(2rem,3.2vw,2.75rem); font-weight:300; line-height:1.16; color:var(--cds-text-primary); margin:0; letter-spacing:-.3px; }
.wc-sub { font-size:1.25rem; color:var(--cds-text-secondary); margin:18px 0 0; font-weight:400; }
.wc-hero__illus { flex:0 0 420px; }
.wc-hero__illus svg { width:100%; height:auto; display:block; }
.wc-actions { display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:16px; max-width:1000px; }
.wc-tile { position:relative; background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:20px; cursor:pointer; min-height:150px; display:flex; flex-direction:column; transition:box-shadow .11s, border-color .11s; text-align:left; }
.wc-tile:hover { box-shadow:0 2px 12px rgba(0,0,0,.12); border-color:var(--cds-border-strong-01); }
.wc-tile .ic { color:var(--cds-icon-primary); margin-bottom:18px; }
.wc-tile h3 { font-size:1rem; font-weight:600; margin:0 0 6px; color:var(--cds-text-primary); }
.wc-tile p { font-size:.875rem; color:var(--cds-text-secondary); margin:0; line-height:1.42; }
.wc-tile .go { position:absolute; right:16px; bottom:14px; color:var(--cds-link-primary); opacity:0; transition:opacity .11s; }
.wc-tile:hover .go { opacity:1; }
@media (max-width: 1080px) { .wc-hero { flex-direction:column-reverse; align-items:flex-start; } .wc-hero__illus { flex:0 0 auto; width:340px; } .wc-actions { grid-template-columns:repeat(2,1fr); } }
`;
(function () {
  if (!document.getElementById('ipas-welcome-styles')) {
    const e = document.createElement('style');
    e.id = 'ipas-welcome-styles';
    e.textContent = WELCOME_CSS;
    document.head.appendChild(e);
  }
})();
function Cloud({
  x,
  y,
  s = 1,
  fill
}) {
  return /*#__PURE__*/React.createElement("g", {
    transform: `translate(${x},${y}) scale(${s})`,
    fill: fill
  }, /*#__PURE__*/React.createElement("rect", {
    x: "6",
    y: "30",
    width: "84",
    height: "22",
    rx: "11"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "28",
    cy: "30",
    r: "18"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "56",
    cy: "23",
    r: "25"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "80",
    cy: "32",
    r: "16"
  }));
}
function WelcomeIllustration() {
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 440 380",
    role: "img",
    "aria-label": "SiPTORY InSight data flow illustration"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: "wcCloudA",
    x1: "0",
    y1: "0",
    x2: "0",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: "#4589ff"
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: "#0f62fe"
  })), /*#__PURE__*/React.createElement("marker", {
    id: "wcArr",
    markerWidth: "9",
    markerHeight: "9",
    refX: "4.5",
    refY: "4.5",
    orient: "auto"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1,1 L8,4.5 L1,8",
    fill: "none",
    stroke: "#8d8d8d",
    strokeWidth: "1.4"
  }))), /*#__PURE__*/React.createElement("path", {
    d: "M210 70 A140 140 0 0 1 350 210",
    fill: "none",
    stroke: "#c6c6c6",
    strokeWidth: "1.6",
    markerEnd: "url(#wcArr)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M350 210 A140 140 0 0 1 210 350",
    fill: "none",
    stroke: "#c6c6c6",
    strokeWidth: "1.6",
    markerEnd: "url(#wcArr)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M210 350 A140 140 0 0 1 86 286",
    fill: "none",
    stroke: "#c6c6c6",
    strokeWidth: "1.6",
    markerEnd: "url(#wcArr)"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M78 270 A140 140 0 0 1 150 92",
    fill: "none",
    stroke: "#c6c6c6",
    strokeWidth: "1.6"
  }), /*#__PURE__*/React.createElement(Cloud, {
    x: 300,
    y: 86,
    s: 1.15,
    fill: "url(#wcCloudA)"
  }), /*#__PURE__*/React.createElement(Cloud, {
    x: 250,
    y: 150,
    s: 0.7,
    fill: "#a6c8ff"
  }), /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("polygon", {
    points: "150,36 184,55 184,93 150,112 116,93 116,55",
    fill: "#d9fbfb",
    stroke: "#009d9a",
    strokeWidth: "1.6"
  }), /*#__PURE__*/React.createElement("g", {
    stroke: "#009d9a",
    strokeWidth: "1.3"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "150",
    y1: "74",
    x2: "133",
    y2: "60"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "150",
    y1: "74",
    x2: "167",
    y2: "62"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "150",
    y1: "74",
    x2: "136",
    y2: "90"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "150",
    y1: "74",
    x2: "166",
    y2: "88"
  })), /*#__PURE__*/React.createElement("g", {
    fill: "#009d9a"
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "150",
    cy: "74",
    r: "3.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "133",
    cy: "60",
    r: "2.6"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "167",
    cy: "62",
    r: "2.6"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "136",
    cy: "90",
    r: "2.6"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "166",
    cy: "88",
    r: "2.6"
  }))), /*#__PURE__*/React.createElement("circle", {
    cx: "210",
    cy: "70",
    r: "7",
    fill: "#0f62fe"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "210",
    cy: "350",
    r: "7",
    fill: "#0f62fe"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "78,260 78,290 104,275",
    fill: "#3ddbd9"
  }), /*#__PURE__*/React.createElement("g", null, /*#__PURE__*/React.createElement("rect", {
    x: "120",
    y: "196",
    width: "60",
    height: "78",
    fill: "#ffffff",
    stroke: "#e0e0e0",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "135",
    cy: "214",
    r: "5",
    fill: "none",
    stroke: "#161616",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "139",
    cy: "218",
    r: "2",
    fill: "#161616"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "128",
    y: "232",
    width: "44",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "128",
    y: "242",
    width: "36",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "128",
    y: "252",
    width: "40",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "190",
    y: "208",
    width: "60",
    height: "78",
    fill: "#ffffff",
    stroke: "#e0e0e0",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M205 222 h16 M213 222 v10 M209 228 l4 4 4 -4",
    fill: "none",
    stroke: "#161616",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "198",
    y: "244",
    width: "44",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "198",
    y: "254",
    width: "36",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "198",
    y: "264",
    width: "40",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "260",
    y: "200",
    width: "60",
    height: "78",
    fill: "#ffffff",
    stroke: "#e0e0e0",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("polygon", {
    points: "290,214 297,219 290,224 283,219",
    fill: "none",
    stroke: "#161616",
    strokeWidth: "1.4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "268",
    y: "236",
    width: "44",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "268",
    y: "246",
    width: "36",
    height: "4",
    fill: "#e0e0e0"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "268",
    y: "256",
    width: "40",
    height: "4",
    fill: "#e0e0e0"
  })));
}
const WC_ACTIONS = [{
  icon: 'dashboard',
  title: 'Build a dashboard',
  desc: 'Compose charts on a drag-and-drop canvas.',
  to: 'analytics'
}, {
  icon: 'data--base',
  title: 'Define a metric',
  desc: 'Add a governed metric to the metrics store.',
  to: 'modeling'
}, {
  icon: 'folder',
  title: 'Browse the catalog',
  desc: 'Search every table and field across layers.',
  to: 'governance'
}, {
  icon: 'chart--line',
  title: 'Check operations',
  desc: 'Monitor pipeline runs and data SLAs.',
  to: 'monitoring'
}];
function Welcome({
  onNavigate,
  lang
}) {
  const h = new Date().getHours();
  const greetEn = h < 12 ? 'Morning' : h < 18 ? 'Afternoon' : 'Evening';
  const greetZh = h < 12 ? '早上好' : h < 18 ? '下午好' : '晚上好';
  const line1 = lang === 'zh' ? `${greetZh}，Lena。` : `${greetEn}, Lena.`;
  return /*#__PURE__*/React.createElement("div", {
    className: "wc"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wc-hero"
  }, /*#__PURE__*/React.createElement("div", {
    className: "wc-hero__text"
  }, /*#__PURE__*/React.createElement("h1", {
    className: "wc-h1"
  }, line1, /*#__PURE__*/React.createElement("br", null), tr(lang, 'Welcome to SiPTORY InSight')), /*#__PURE__*/React.createElement("p", {
    className: "wc-sub"
  }, tr(lang, 'What do you want to do today?'))), /*#__PURE__*/React.createElement("div", {
    className: "wc-hero__illus"
  }, /*#__PURE__*/React.createElement(WelcomeIllustration, null))), /*#__PURE__*/React.createElement("div", {
    className: "wc-actions"
  }, WC_ACTIONS.map(a => /*#__PURE__*/React.createElement("button", {
    key: a.to,
    className: "wc-tile",
    onClick: () => onNavigate(a.to)
  }, /*#__PURE__*/React.createElement("span", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: a.icon,
    size: 24
  })), /*#__PURE__*/React.createElement("h3", null, tr(lang, a.title)), /*#__PURE__*/React.createElement("p", null, tr(lang, a.desc)), /*#__PURE__*/React.createElement("span", {
    className: "go"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow--right",
    size: 20
  }))))));
}
Object.assign(window, {
  Welcome
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/Welcome.jsx", error: String((e && e.message) || e) }); }

// IPAS-DataPlatform/wire.jsx
try { (() => {
/* global React */
const {
  Icon,
  Tag,
  Button,
  Search,
  TextInput,
  Dropdown,
  Checkbox,
  Toggle,
  Tabs,
  Tile,
  InlineNotification
} = window.CarbonDesignSystem_280d33;

/* ============================================================
   IPAS Data Platform — shared wireframe primitives
   Carbon language: square corners, 1px borders, flat surfaces,
   IBM Plex, blue #0f62fe interactive, structure-first wireframe.
   ============================================================ */
const WIRE_CSS = `
:root { --wire-border: #e0e0e0; }
.w-page { padding: 24px 32px 80px; }
.w-page--flush { padding: 0; }
.w-crumb { font-size: .75rem; color: var(--cds-text-secondary); margin-bottom: 12px; letter-spacing:.32px; display:flex; align-items:center; gap:6px; flex-wrap:wrap; }
.w-crumb a { color: var(--cds-link-primary); text-decoration: none; }
.w-crumb a:hover { text-decoration: underline; }
.w-crumb .sep { color: var(--cds-text-placeholder); }
.w-head { display:flex; align-items:flex-end; justify-content:space-between; gap:24px; margin-bottom:20px; }
.w-head h1 { font-size: 1.75rem; font-weight: 400; line-height: 1.25; margin:0; color: var(--cds-text-primary); }
.w-head p { margin: 6px 0 0; font-size: .875rem; color: var(--cds-text-secondary); max-width: 64ch; }
.w-head .acts { display:flex; gap:1px; flex:0 0 auto; }

/* sub-page switcher (content switcher) */
.w-switch { display:inline-flex; border:1px solid var(--cds-border-strong-01); margin-bottom:24px; max-width:100%; overflow:auto; }
.w-switch button { appearance:none; border:none; background:var(--cds-layer-02); color:var(--cds-text-secondary);
  font-family:var(--cds-font-sans); font-size:.875rem; padding:0 16px; height:40px; cursor:pointer; white-space:nowrap;
  border-right:1px solid var(--cds-border-strong-01); }
.w-switch button:last-child { border-right:none; }
.w-switch button:hover { background:var(--cds-layer-hover-01); color:var(--cds-text-primary); }
.w-switch button.active { background:var(--cds-gray-100); color:#fff; }

/* generic data table */
.w-tblwrap { background: var(--cds-layer-02); border:1px solid var(--wire-border); }
.w-toolbar { display:flex; align-items:stretch; height:48px; border-bottom:1px solid var(--wire-border); }
.w-toolbar .grow { flex:1; display:flex; align-items:center; min-width:0; }
.w-toolbar .grow .cds--search__input { background:var(--cds-layer-02); height:48px; }
.w-toolbar .chips { display:flex; align-items:center; gap:8px; padding:0 12px; flex-wrap:nowrap; overflow:hidden; }
.w-tbl { width:100%; border-collapse:collapse; font-family:var(--cds-font-sans); }
.w-tbl th { text-align:left; font-size:.75rem; font-weight:600; color:var(--cds-text-primary); background:var(--cds-layer-01);
  height:40px; padding:0 16px; white-space:nowrap; border-bottom:1px solid var(--wire-border); letter-spacing:.16px; }
.w-tbl th .sort { display:inline-flex; align-items:center; gap:4px; cursor:pointer; }
.w-tbl th .sort:hover { color:var(--cds-link-primary); }
.w-tbl td { font-size:.875rem; color:var(--cds-text-secondary); height:48px; padding:0 16px; border-bottom:1px solid var(--wire-border); vertical-align:middle; }
.w-tbl tr:last-child td { border-bottom:none; }
.w-tbl tbody tr { cursor:default; }
.w-tbl tbody tr.click { cursor:pointer; }
.w-tbl tbody tr:hover td { background:var(--cds-layer-hover-01); }
.w-tbl td.name { color:var(--cds-text-primary); font-weight:500; }
.w-tbl td.name a { color:var(--cds-link-primary); text-decoration:none; }
.w-tbl td.name a:hover { text-decoration:underline; }
.w-tbl td.mono { font-family:var(--cds-font-mono); font-size:.8125rem; color:var(--cds-text-secondary); }
.w-tbl .ofw { width:48px; text-align:center; }
.w-ofw-btn { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-ofw-btn:hover { background:var(--cds-layer-hover-01); }
.w-tblfoot { display:flex; align-items:center; justify-content:space-between; height:40px; padding:0 16px; border-top:1px solid var(--wire-border); font-size:.75rem; color:var(--cds-text-secondary); background:var(--cds-layer-02); }
.w-tblfoot .pg { display:flex; align-items:center; gap:2px; }
.w-pgbtn { width:28px; height:28px; display:inline-flex; align-items:center; justify-content:center; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-pgbtn:hover { background:var(--cds-layer-hover-01); }
.w-pgbtn.on { background:var(--cds-gray-100); color:#fff; }

/* status dot+label */
.w-status { display:inline-flex; align-items:center; gap:8px; font-size:.8125rem; color:var(--cds-text-primary); }
.w-status .dot { width:8px; height:8px; border-radius:50%; flex:0 0 auto; }

/* modal */
.w-scrim { position:fixed; inset:0; background:var(--cds-overlay); z-index:60; display:flex; align-items:flex-start; justify-content:center; padding:64px 16px; overflow:auto; }
.w-modal { background:var(--cds-layer-02); width:640px; max-width:100%; box-shadow:var(--cds-shadow-modal); display:flex; flex-direction:column; }
.w-modal--sm { width:480px; }
.w-modal--lg { width:840px; }
.w-modal__head { padding:20px 24px 8px; }
.w-modal__head .sup { font-size:.75rem; color:var(--cds-text-secondary); letter-spacing:.32px; }
.w-modal__head h2 { font-size:1.25rem; font-weight:400; margin:4px 0 0; color:var(--cds-text-primary); }
.w-modal__head .x { position:absolute; top:0; right:0; width:48px; height:48px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-modal__head .x:hover { background:var(--cds-layer-hover-01); }
.w-modal__wrap { position:relative; }
.w-modal__body { padding:16px 24px 32px; display:flex; flex-direction:column; gap:20px; max-height:60vh; overflow:auto; }
.w-modal__foot { display:flex; }
.w-modal__foot > * { flex:1; }

/* right slide-over panel */
.w-panel { position:fixed; top:0; right:0; bottom:0; background:var(--cds-layer-02); z-index:55; box-shadow:var(--cds-shadow-modal); display:flex; flex-direction:column; }
.w-panel__head { padding:20px 24px; border-bottom:1px solid var(--wire-border); position:relative; }
.w-panel__head .sup { font-size:.75rem; color:var(--cds-text-secondary); letter-spacing:.32px; }
.w-panel__head h2 { font-size:1.125rem; font-weight:600; margin:4px 0 0; color:var(--cds-text-primary); }
.w-panel__head .x { position:absolute; top:12px; right:12px; width:40px; height:40px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; }
.w-panel__head .x:hover { background:var(--cds-layer-hover-01); }
.w-panel__body { padding:20px 24px; display:flex; flex-direction:column; gap:20px; flex:1; overflow:auto; }
.w-panel__foot { display:flex; }
.w-panel__foot > * { flex:1; }

/* field group helpers */
.w-fld { display:flex; flex-direction:column; gap:6px; }
.w-fld > label { font-size:.75rem; color:var(--cds-text-secondary); }
.w-row { display:flex; gap:16px; }
.w-row > * { flex:1; }

/* chart / image placeholders */
.w-ph { position:relative; background:
    repeating-linear-gradient(135deg, var(--cds-layer-01) 0 10px, var(--cds-layer-02) 10px 20px);
  border:1px solid var(--wire-border); display:flex; align-items:center; justify-content:center; color:var(--cds-text-helper); }
.w-ph .lbl { font-family:var(--cds-font-mono); font-size:.6875rem; letter-spacing:.32px; color:var(--cds-text-secondary);
  background:var(--cds-layer-02); border:1px solid var(--wire-border); padding:4px 10px; display:inline-flex; align-items:center; gap:8px; }

/* mini bar chart (real, lightweight) */
.w-bars { display:flex; align-items:flex-end; gap:8px; width:100%; }
.w-bars .b { flex:1; background:var(--cds-blue-60); min-height:4px; }
.w-bars .b:nth-child(even){ background:var(--cds-blue-40); }

/* skeleton */
@keyframes wshimmer { 0%{opacity:.5} 50%{opacity:1} 100%{opacity:.5} }
.w-sk { background:var(--cds-layer-01); animation:wshimmer 1.2s ease-in-out infinite; }
.w-sk-line { height:12px; margin:8px 0; }

/* empty state */
.w-empty { border:1px dashed var(--cds-border-strong-01); background:var(--cds-layer-02); padding:48px 24px; text-align:center; color:var(--cds-text-secondary); }
.w-empty .ic { color:var(--cds-icon-secondary); margin-bottom:12px; display:flex; justify-content:center; }
.w-empty h3 { font-size:1rem; font-weight:600; color:var(--cds-text-primary); margin:0 0 6px; }
.w-empty p { font-size:.875rem; margin:0 0 20px; }

/* draggable affordance */
.w-grip { display:inline-grid; grid-template-columns:repeat(2,3px); gap:2px; cursor:grab; flex:0 0 auto; }
.w-grip i { width:3px; height:3px; background:var(--cds-icon-secondary); }
.w-chip { display:flex; align-items:center; gap:8px; padding:6px 10px; background:var(--cds-layer-02); border:1px solid var(--wire-border); font-size:.8125rem; color:var(--cds-text-primary); cursor:grab; }
.w-chip:hover { border-color:var(--cds-border-interactive); background:var(--cds-layer-hover-01); }
.w-chip .t { color:var(--cds-text-secondary); font-size:.6875rem; font-family:var(--cds-font-mono); margin-left:auto; }

/* generic card grid */
.w-grid { display:grid; gap:16px; }

/* panel / column shells for 3-pane editors */
.w-shellrow { display:flex; min-height: calc(100vh - 48px - 0px); }
.w-col { background:var(--cds-layer-02); border-right:1px solid var(--wire-border); display:flex; flex-direction:column; min-height:100%; }
.w-col__h { display:flex; align-items:center; gap:8px; height:40px; padding:0 12px 0 16px; border-bottom:1px solid var(--wire-border); font-size:.75rem; font-weight:600; color:var(--cds-text-primary); letter-spacing:.16px; }
.w-col__h .collapse { margin-left:auto; width:28px; height:28px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.w-col__h .collapse:hover { background:var(--cds-layer-hover-01); }
.w-col__body { padding:12px; overflow:auto; flex:1; }
.w-section-label { font-size:.6875rem; font-weight:600; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); margin:8px 4px; }

/* tree */
.w-tree { font-size:.8125rem; }
.w-treeitem { display:flex; align-items:center; gap:6px; padding:5px 4px; color:var(--cds-text-primary); cursor:pointer; }
.w-treeitem:hover { background:var(--cds-layer-hover-01); }
.w-treeitem.indent { padding-left:24px; color:var(--cds-text-secondary); cursor:grab; }
.w-treeitem.indent:hover { color:var(--cds-text-primary); }

/* toolbar above editor canvases */
.w-etoolbar { display:flex; align-items:center; gap:1px; height:48px; padding:0 8px; background:var(--cds-layer-02); border-bottom:1px solid var(--wire-border); }
.w-etoolbar .gap { width:1px; height:24px; background:var(--wire-border); margin:0 8px; }
.w-etoolbar .spacer { flex:1; }
.w-iconbtn { height:32px; min-width:32px; padding:0 8px; display:inline-flex; align-items:center; gap:6px; border:none; background:transparent; color:var(--cds-text-primary); font-family:var(--cds-font-sans); font-size:.8125rem; cursor:pointer; }
.w-iconbtn:hover { background:var(--cds-layer-hover-01); }

/* canvas */
.w-canvas { flex:1; position:relative; overflow:auto; background:
    linear-gradient(var(--cds-layer-01) 1px, transparent 1px) 0 0 / 100% 24px,
    linear-gradient(90deg, var(--cds-layer-01) 1px, transparent 1px) 0 0 / 24px 100%,
    var(--cds-layer-02); }

/* engine indicator */
.w-engine { position:absolute; right:16px; bottom:16px; display:flex; align-items:center; gap:8px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:var(--cds-shadow-overlay,0 2px 6px rgba(0,0,0,.12)); padding:8px 12px; font-size:.75rem; color:var(--cds-text-secondary); }
.w-engine b { color:var(--cds-text-primary); font-weight:600; }

/* stat tiles */
.w-stats { display:grid; grid-template-columns:repeat(4,1fr); gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.w-stats .s { background:var(--cds-layer-02); padding:20px; }
.w-stats .s .k { font-size:.75rem; letter-spacing:.16px; color:var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.w-stats .s .v { font-size:2.25rem; font-weight:300; line-height:1.1; margin-top:10px; color:var(--cds-text-primary); }
.w-stats .s .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:6px; }

/* multi-step wizard stepper */
.w-stepper { display:flex; gap:0; margin-bottom:24px; border:1px solid var(--wire-border); }
.w-step { flex:1; display:flex; align-items:center; gap:10px; padding:12px 16px; border-right:1px solid var(--wire-border); background:var(--cds-layer-02); cursor:pointer; min-width:0; }
.w-step:last-child { border-right:none; }
.w-step .n { width:24px; height:24px; flex:0 0 24px; border-radius:50%; border:1px solid var(--cds-border-strong-01); display:flex; align-items:center; justify-content:center; font-size:.75rem; color:var(--cds-text-secondary); background:var(--cds-layer-02); }
.w-step .tx { min-width:0; } .w-step .tx .t { font-size:.8125rem; font-weight:500; color:var(--cds-text-secondary); white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
.w-step .tx .s { font-size:.6875rem; color:var(--cds-text-placeholder); }
.w-step.active { background:var(--cds-layer-01); }
.w-step.active .n { border-color:var(--cds-border-interactive); color:#fff; background:var(--cds-blue-60); }
.w-step.active .tx .t { color:var(--cds-text-primary); }
.w-step.done .n { border-color:var(--cds-support-success); color:#fff; background:var(--cds-support-success); }
.w-step.done .tx .t { color:var(--cds-text-primary); }

/* visual condition builder */
.w-cond { border:1px solid var(--wire-border); background:var(--cds-layer-02); padding:12px; }
.w-cond__grp { border-left:2px solid var(--cds-border-interactive); padding:8px 0 8px 12px; margin-bottom:8px; display:flex; flex-direction:column; gap:8px; }
.w-cond__row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
.w-cond__row .x { width:32px; height:32px; border:none; background:transparent; color:var(--cds-icon-primary); cursor:pointer; display:inline-flex; align-items:center; justify-content:center; }
.w-cond__row .x:hover { background:var(--cds-layer-hover-01); }
.w-cond__join { display:inline-flex; align-items:center; gap:6px; align-self:flex-start; }
.w-cond__pill { font-size:.6875rem; font-weight:600; letter-spacing:.16px; padding:2px 8px; background:var(--cds-blue-60); color:#fff; }
.w-cond__sql { font-family:var(--cds-font-mono); font-size:.75rem; background:var(--cds-gray-100); color:#f4f4f4; padding:10px 12px; margin-top:8px; white-space:pre-wrap; }

/* floating menu / popover */
.w-menu { position:fixed; z-index:90; min-width:240px; background:var(--cds-layer-02); border:1px solid var(--wire-border); box-shadow:var(--cds-shadow-overlay,0 4px 16px rgba(0,0,0,.2)); display:flex; flex-direction:column; }
.w-menu__hd { padding:14px 16px; border-bottom:1px solid var(--wire-border); }
.w-menu__hd .nm { font-size:.875rem; font-weight:600; color:var(--cds-text-primary); }
.w-menu__hd .sub { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; font-family:var(--cds-font-mono); }
.w-menu__hd .badges { display:flex; gap:6px; margin-top:8px; flex-wrap:wrap; }
.w-menu__item { display:flex; align-items:center; gap:12px; padding:0 16px; height:40px; font-size:.875rem; color:var(--cds-text-primary); background:transparent; border:none; width:100%; text-align:left; cursor:pointer; }
.w-menu__item:hover { background:var(--cds-layer-hover-01); }
.w-menu__item .mr { margin-left:auto; font-size:.75rem; color:var(--cds-text-secondary); display:flex; align-items:center; gap:6px; }
.w-menu__sep { height:1px; background:var(--wire-border); margin:4px 0; }
.w-menu__lbl { font-size:.6875rem; letter-spacing:.32px; text-transform:uppercase; color:var(--cds-text-secondary); padding:10px 16px 4px; }
.w-menu__scrim { position:fixed; inset:0; z-index:89; }

/* notification items */
.w-notif { display:flex; gap:12px; padding:14px 16px; border-bottom:1px solid var(--wire-border); position:relative; cursor:pointer; }
.w-notif:hover { background:var(--cds-layer-hover-01); }
.w-notif.unread { background:var(--cds-layer-01); }
.w-notif.unread:hover { background:var(--cds-layer-hover-01); }
.w-notif__ic { width:32px; height:32px; flex:0 0 32px; display:flex; align-items:center; justify-content:center; }
.w-notif__bd { flex:1; min-width:0; }
.w-notif__bd .t { font-size:.8125rem; font-weight:600; color:var(--cds-text-primary); }
.w-notif__bd .d { font-size:.75rem; color:var(--cds-text-secondary); margin-top:2px; line-height:1.4; }
.w-notif__bd .ts { font-size:.6875rem; color:var(--cds-text-placeholder); margin-top:6px; }
.w-notif__bd .req { display:flex; gap:8px; margin-top:10px; }
.w-notif__dot { position:absolute; top:18px; right:14px; width:8px; height:8px; border-radius:50%; background:var(--cds-blue-60); }
.w-notif__tabs { display:flex; border-bottom:1px solid var(--wire-border); }
.w-notif__tabs button { flex:1; height:44px; border:none; background:transparent; font-family:var(--cds-font-sans); font-size:.8125rem; color:var(--cds-text-secondary); cursor:pointer; border-bottom:2px solid transparent; }
.w-notif__tabs button.on { color:var(--cds-text-primary); font-weight:600; border-bottom-color:var(--cds-border-interactive); }

/* simple key-value descriptive list */
.w-dl { display:grid; grid-template-columns:160px 1fr; gap:1px; background:var(--wire-border); border:1px solid var(--wire-border); }
.w-dl dt, .w-dl dd { background:var(--cds-layer-02); margin:0; padding:10px 14px; font-size:.8125rem; }
.w-dl dt { color:var(--cds-text-secondary); } .w-dl dd { color:var(--cds-text-primary); font-weight:500; }

/* segmented matrix checkbox grid */
.w-permgrid { width:100%; border-collapse:collapse; border:1px solid var(--wire-border); font-size:.8125rem; }
.w-permgrid th, .w-permgrid td { border:1px solid var(--wire-border); padding:8px 12px; text-align:center; }
.w-permgrid th { background:var(--cds-layer-01); font-weight:600; color:var(--cds-text-primary); }
.w-permgrid td:first-child, .w-permgrid th:first-child { text-align:left; color:var(--cds-text-primary); font-weight:500; }
.w-permgrid input { accent-color:var(--cds-blue-60); width:16px; height:16px; }
`;
function injectWire() {
  if (typeof document === 'undefined' || document.getElementById('ipas-wire-styles')) return;
  const el = document.createElement('style');
  el.id = 'ipas-wire-styles';
  el.textContent = WIRE_CSS;
  document.head.appendChild(el);
}
injectWire();

/* ---- status mapping ---- */
const STATUS_DOT = {
  green: 'var(--cds-support-success)',
  running: 'var(--cds-support-success)',
  connected: 'var(--cds-support-success)',
  success: 'var(--cds-support-success)',
  active: 'var(--cds-support-success)',
  healthy: 'var(--cds-support-success)',
  amber: 'var(--cds-support-warning)',
  warning: 'var(--cds-support-warning)',
  retrying: 'var(--cds-support-warning)',
  degraded: 'var(--cds-support-warning)',
  paused: 'var(--cds-support-warning)',
  red: 'var(--cds-support-error)',
  error: 'var(--cds-support-error)',
  failed: 'var(--cds-support-error)',
  blue: 'var(--cds-blue-60)',
  provisioning: 'var(--cds-blue-60)',
  syncing: 'var(--cds-blue-60)',
  running2: 'var(--cds-blue-60)',
  gray: 'var(--cds-text-placeholder)',
  stopped: 'var(--cds-text-placeholder)',
  draft: 'var(--cds-text-placeholder)',
  inactive: 'var(--cds-text-placeholder)'
};
function StatusDot({
  kind,
  children
}) {
  const color = STATUS_DOT[(kind || 'gray').toLowerCase()] || STATUS_DOT.gray;
  return /*#__PURE__*/React.createElement("span", {
    className: "w-status"
  }, /*#__PURE__*/React.createElement("span", {
    className: "dot",
    style: {
      background: color
    }
  }), children);
}

/* ---- page header ---- */
function PageHead({
  crumb,
  title,
  sub,
  actions
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, crumb && /*#__PURE__*/React.createElement("div", {
    className: "w-crumb"
  }, crumb.map((c, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    className: "sep"
  }, "/"), i < crumb.length - 1 ? /*#__PURE__*/React.createElement("a", {
    href: "#",
    onClick: e => e.preventDefault()
  }, c) : /*#__PURE__*/React.createElement("span", null, c)))), /*#__PURE__*/React.createElement("div", {
    className: "w-head"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, title), sub && /*#__PURE__*/React.createElement("p", null, sub)), actions && /*#__PURE__*/React.createElement("div", {
    className: "acts"
  }, actions)));
}

/* ---- sub-page content switcher ---- */
function SubSwitch({
  items,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-switch",
    role: "tablist"
  }, items.map(it => /*#__PURE__*/React.createElement("button", {
    key: it.id,
    role: "tab",
    className: value === it.id ? 'active' : '',
    onClick: () => onChange(it.id)
  }, it.label)));
}

/* ---- generic data table ---- */
function WireTable({
  columns,
  rows,
  renderCell,
  onRowClick,
  sortKey,
  footer = true,
  total
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-tblwrap"
  }, /*#__PURE__*/React.createElement("table", {
    className: "w-tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, columns.map(c => /*#__PURE__*/React.createElement("th", {
    key: c.key,
    style: c.width ? {
      width: c.width
    } : null
  }, c.sortable === false ? c.label : /*#__PURE__*/React.createElement("span", {
    className: "sort"
  }, c.label, /*#__PURE__*/React.createElement(Icon, {
    name: sortKey === c.key ? 'chevron--down' : 'chevron--sort',
    size: 16
  })))))), /*#__PURE__*/React.createElement("tbody", null, rows.map((r, ri) => /*#__PURE__*/React.createElement("tr", {
    key: r.id || ri,
    className: onRowClick ? 'click' : '',
    onClick: onRowClick ? () => onRowClick(r) : null
  }, columns.map(c => /*#__PURE__*/React.createElement("td", {
    key: c.key,
    className: c.cellClass || ''
  }, renderCell(r, c.key))))))), footer && /*#__PURE__*/React.createElement("div", {
    className: "w-tblfoot"
  }, /*#__PURE__*/React.createElement("span", null, total != null ? total : rows.length, " items"), /*#__PURE__*/React.createElement("div", {
    className: "pg"
  }, /*#__PURE__*/React.createElement("button", {
    className: "w-pgbtn on"
  }, "1"), /*#__PURE__*/React.createElement("button", {
    className: "w-pgbtn"
  }, "2"), /*#__PURE__*/React.createElement("button", {
    className: "w-pgbtn"
  }, "3"), /*#__PURE__*/React.createElement("button", {
    className: "w-pgbtn",
    "aria-label": "Next page"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--right",
    size: 16
  })))));
}

/* ---- table toolbar ---- */
function TableToolbar({
  search,
  onSearch,
  placeholder,
  chips,
  actions
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-toolbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "grow"
  }, /*#__PURE__*/React.createElement(Search, {
    value: search,
    onChange: onSearch,
    size: "lg",
    placeholder: placeholder || 'Search'
  })), chips && /*#__PURE__*/React.createElement("div", {
    className: "chips"
  }, chips), actions);
}

/* ---- overflow menu (visual) ---- */
function Overflow() {
  return /*#__PURE__*/React.createElement("button", {
    className: "w-ofw-btn",
    "aria-label": "Row actions",
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "overflow-menu--vertical",
    size: 16
  }));
}

/* ---- modal ---- */
function Modal({
  title,
  sup,
  size,
  onClose,
  children,
  footer
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-scrim",
    onClick: onClose
  }, /*#__PURE__*/React.createElement("div", {
    className: `w-modal ${size === 'sm' ? 'w-modal--sm' : size === 'lg' ? 'w-modal--lg' : ''}`,
    onClick: e => e.stopPropagation()
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-modal__wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-modal__head"
  }, sup && /*#__PURE__*/React.createElement("div", {
    className: "sup"
  }, sup), /*#__PURE__*/React.createElement("h2", null, title), /*#__PURE__*/React.createElement("button", {
    className: "x",
    "aria-label": "Close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 20
  })))), /*#__PURE__*/React.createElement("div", {
    className: "w-modal__body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "w-modal__foot"
  }, footer)));
}

/* ---- right slide-over ---- */
function SidePanel({
  title,
  sup,
  width = 420,
  onClose,
  children,
  footer
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "w-scrim",
    style: {
      display: 'block',
      padding: 0
    },
    onClick: onClose
  }), /*#__PURE__*/React.createElement("aside", {
    className: "w-panel",
    style: {
      width
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-panel__head"
  }, sup && /*#__PURE__*/React.createElement("div", {
    className: "sup"
  }, sup), /*#__PURE__*/React.createElement("h2", null, title), /*#__PURE__*/React.createElement("button", {
    className: "x",
    "aria-label": "Close",
    onClick: onClose
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "close",
    size: 20
  }))), /*#__PURE__*/React.createElement("div", {
    className: "w-panel__body"
  }, children), footer && /*#__PURE__*/React.createElement("div", {
    className: "w-panel__foot"
  }, footer)));
}

/* ---- chart / image placeholder ---- */
function Placeholder({
  label,
  height = 160,
  icon = 'chart--bar',
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-ph",
    style: {
      height,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "lbl"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 14
  }), label));
}

/* ---- lightweight real bar chart ---- */
function BarChart({
  data,
  height = 140
}) {
  const max = Math.max(...data);
  return /*#__PURE__*/React.createElement("div", {
    className: "w-bars",
    style: {
      height
    }
  }, data.map((d, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "b",
    style: {
      height: d / max * 100 + '%'
    }
  })));
}

/* ---- skeleton block ---- */
function Skeleton({
  rows = 3,
  width = '100%'
}) {
  return /*#__PURE__*/React.createElement("div", null, Array.from({
    length: rows
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "w-sk w-sk-line",
    style: {
      width: i === rows - 1 ? '60%' : width
    }
  })));
}

/* ---- empty state ---- */
function EmptyState({
  icon = 'document',
  title,
  sub,
  action
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-empty"
  }, /*#__PURE__*/React.createElement("div", {
    className: "ic"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 32
  })), /*#__PURE__*/React.createElement("h3", null, title), sub && /*#__PURE__*/React.createElement("p", null, sub), action);
}

/* ---- draggable field chip ---- */
function FieldChip({
  children,
  kind
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-chip",
    draggable: true
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-grip"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)), children, kind && /*#__PURE__*/React.createElement("span", {
    className: "t"
  }, kind));
}

/* ---- editor toolbar button ---- */
function ToolBtn({
  icon,
  label,
  onClick,
  title
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "w-iconbtn",
    onClick: onClick,
    title: title || label,
    "aria-label": title || label
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 16
  }), label);
}

/* ---- multi-step wizard stepper ---- */
function Stepper({
  steps,
  current,
  onStep
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "w-stepper"
  }, steps.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: `w-step ${i === current ? 'active' : ''} ${i < current ? 'done' : ''}`,
    onClick: () => onStep && onStep(i)
  }, /*#__PURE__*/React.createElement("span", {
    className: "n"
  }, i < current ? /*#__PURE__*/React.createElement(Icon, {
    name: "checkmark",
    size: 14
  }) : i + 1), /*#__PURE__*/React.createElement("span", {
    className: "tx"
  }, /*#__PURE__*/React.createElement("span", {
    className: "t"
  }, s.t), s.s && /*#__PURE__*/React.createElement("span", {
    className: "s"
  }, s.s)))));
}

/* ---- visual condition builder (field / op / value, AND-OR) ---- */
function ConditionBuilder({
  fields = ['process_id', 'region', 'plant', 'shift'],
  ops = ['=', '≠', 'IN', 'NOT IN', '>', '<', 'LIKE'],
  initial,
  sql
}) {
  const [rows, setRows] = React.useState(initial || [{
    field: 'process_id',
    op: 'IN',
    value: "'P1','P2'"
  }]);
  const [join, setJoin] = React.useState('AND');
  const update = (i, key, v) => setRows(rs => rs.map((r, j) => j === i ? {
    ...r,
    [key]: v
  } : r));
  const generated = sql || 'WHERE ' + rows.map(r => `${r.field} ${r.op} (${r.value})`).join(`\n  ${join} `);
  return /*#__PURE__*/React.createElement("div", {
    className: "w-cond"
  }, /*#__PURE__*/React.createElement("div", {
    className: "w-cond__grp"
  }, rows.map((r, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: i
  }, i > 0 && /*#__PURE__*/React.createElement("span", {
    className: "w-cond__join"
  }, /*#__PURE__*/React.createElement("span", {
    className: "w-cond__pill",
    onClick: () => setJoin(join === 'AND' ? 'OR' : 'AND'),
    style: {
      cursor: 'pointer'
    }
  }, join)), /*#__PURE__*/React.createElement("div", {
    className: "w-cond__row"
  }, /*#__PURE__*/React.createElement(Dropdown, {
    items: fields,
    value: r.field,
    onChange: v => update(i, 'field', v),
    size: "sm",
    style: {
      width: 160
    }
  }), /*#__PURE__*/React.createElement(Dropdown, {
    items: ops,
    value: r.op,
    onChange: v => update(i, 'op', v),
    size: "sm",
    style: {
      width: 110
    }
  }), /*#__PURE__*/React.createElement(TextInput, {
    size: "sm",
    value: r.value,
    onChange: e => update(i, 'value', e.target ? e.target.value : e),
    style: {
      width: 180
    }
  }), /*#__PURE__*/React.createElement("button", {
    className: "x",
    "aria-label": "Remove condition",
    onClick: () => setRows(rs => rs.filter((_, j) => j !== i))
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "subtract",
    size: 16
  })))))), /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "sm",
    icon: "add",
    onClick: () => setRows(rs => [...rs, {
      field: fields[0],
      op: '=',
      value: ''
    }])
  }, "Add condition"), /*#__PURE__*/React.createElement("div", {
    className: "w-cond__sql"
  }, generated));
}

/* ---- floating anchored menu / popover ---- */
function Menu({
  anchorRect,
  onClose,
  width = 256,
  side = 'right',
  children
}) {
  const ref = React.useRef(null);
  const [pos, setPos] = React.useState({
    left: -9999,
    top: -9999
  });
  React.useLayoutEffect(() => {
    const el = ref.current;
    if (!el || !anchorRect) return;
    const h = el.offsetHeight,
      w = el.offsetWidth;
    let top = anchorRect.top - h;
    if (top < 8) top = Math.min(anchorRect.bottom + 4, window.innerHeight - h - 8);
    let left = side === 'right' ? anchorRect.right + 8 : anchorRect.left;
    if (left + w > window.innerWidth - 8) left = window.innerWidth - w - 8;
    if (left < 8) left = 8;
    setPos({
      left,
      top
    });
  }, [anchorRect]);
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "w-menu__scrim",
    onClick: onClose
  }), /*#__PURE__*/React.createElement("div", {
    className: "w-menu",
    ref: ref,
    style: {
      left: pos.left,
      top: pos.top,
      width
    }
  }, children));
}
function MenuItem({
  icon,
  children,
  meta,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    className: "w-menu__item",
    onClick: onClick
  }, icon && /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 16
  }), children, meta && /*#__PURE__*/React.createElement("span", {
    className: "mr"
  }, meta));
}

/* ---- i18n: English → 简体中文 dictionary (chrome, welcome, section headers) ---- */
const IPAS_ZH = {
  // nav + chrome
  'Home / Overview': '首页 / 概览',
  'Self-Service Analytics': '自助分析',
  'Data Modeling & Semantics': '数据建模与语义',
  'Data Development / Config': '数据开发 / 配置',
  'Data Assets & Governance': '数据资产与治理',
  'Monitoring & Ops': '监控与运维',
  'Platform Admin': '平台管理',
  'Search platform': '搜索平台',
  'Data Engineer': '数据工程师',
  'Notifications': '通知',
  'Help': '帮助',
  'Help & resources': '帮助与资源',
  'Documentation': '文档',
  'Keyboard shortcuts': '键盘快捷键',
  "What's new": '更新日志',
  'Support': '技术支持',
  'My profile': '我的资料',
  'Preferences': '偏好设置',
  'My permissions': '我的权限',
  'API keys': 'API 密钥',
  'Switch organization': '切换组织',
  'Appearance': '外观',
  'Light': '浅色',
  'Language': '语言',
  'Sign out': '退出登录',
  'Mark all as read': '全部标为已读',
  'Settings': '设置',
  'Nothing here.': '暂无内容。',
  'Approve': '批准',
  'Deny': '拒绝',
  'All': '全部',
  'Unread': '未读',
  'Mentions': '提及我的',
  // overview
  'Healthy pipelines': '健康管道',
  'Failed (24h)': '失败（24h）',
  'Catalog assets': '目录资产',
  'Open alerts': '未处理告警',
  'New pipeline': '新建管道',
  'Ingest a source to a layer': '将数据源接入分层',
  'New dashboard': '新建仪表板',
  'Build on the canvas': '在画布上构建',
  'Run a query': '运行查询',
  'Visual builder or SQL': '可视化构建或 SQL',
  'Recent pipelines': '近期管道',
  'View all': '查看全部',
  'Pending access requests': '待处理访问申请',
  'My dashboards': '我的仪表板',
  'Pipeline': '管道',
  'Status': '状态',
  'Duration': '时长',
  'Started': '开始时间',
  // profile
  'Personal center': '个人中心',
  'Your profile, preferences, permissions, and security.': '你的资料、偏好、权限与安全。',
  'Notification settings': '通知设置',
  'Security & sessions': '安全与会话',
  'Identity fields are managed in corporate IAM (read-only).': '身份字段由企业 IAM 统一管理（只读）。',
  'Full name': '姓名',
  'Department': '部门',
  'Identity source': '身份来源',
  'Member since': '加入时间',
  'Roles': '角色',
  'Choose how the platform looks.': '选择平台的外观主题。',
  'Dark': '深色',
  'High contrast': '高对比',
  'Localization & defaults': '本地化与默认值',
  'Timezone': '时区',
  'Default landing page': '默认首页',
  'Default query engine': '默认查询引擎',
  'Table page size': '表格分页大小',
  'Date format': '日期格式',
  'Save preferences': '保存偏好',
  'Preferences saved.': '偏好已保存。',
  'Notification channels': '通知渠道',
  'Pick how you are notified for each event type.': '为每类事件选择通知方式。',
  'Event': '事件',
  'In-app': '应用内',
  'Pipeline success': '管道成功',
  'Pipeline failure': '管道失败',
  'Quality alert': '质量告警',
  'SLA breach': 'SLA 违约',
  'Access request': '访问申请',
  'Announcements': '公告',
  'Daily digest instead of per-event email': '每日汇总替代逐条邮件',
  'Mute 22:00–07:00': '静默 22:00–07:00',
  'Save settings': '保存设置',
  'Notification settings saved.': '通知设置已保存。',
  'Effective access — computed from your roles & policies': '有效访问权限 —— 由角色与策略计算得出',
  'My roles': '我的角色',
  'Search assets I can access': '搜索我可访问的资产',
  'Request access': '申请访问',
  'Asset': '资产',
  'Access': '访问',
  'Masking applied': '已应用脱敏',
  'Create API key': '创建 API 密钥',
  'Search keys': '搜索密钥',
  'Name': '名称',
  'Token': '令牌',
  'Scopes': '范围',
  'Last used': '最近使用',
  'Personal access token': '个人访问令牌',
  'Copy this token now — it will not be shown again.': '请立即复制令牌 —— 之后将不再显示。',
  'Copy': '复制',
  'Token copied.': '令牌已复制。',
  'Key name': '密钥名称',
  'Scope': '范围',
  'Expiry': '有效期',
  'Generate token': '生成令牌',
  'Cancel': '取消',
  'Done': '完成',
  'Active sessions': '活动会话',
  'Your password is managed in corporate SSO (Keycloak).': '密码由企业 SSO（Keycloak）统一管理。',
  'This device': '当前设备',
  'Session signed out.': '会话已退出。',
  'Sign out all other sessions': '退出所有其他会话',
  'Signed out of all other sessions.': '已退出所有其他会话。',
  // welcome
  'What do you want to do today?': '今天想做些什么？',
  'Welcome to SiPTORY InSight': '欢迎使用 SiPTORY InSight',
  'Build a dashboard': '创建仪表板',
  'Compose charts on a drag-and-drop canvas.': '在拖拽画布上组合图表。',
  'Define a metric': '定义指标',
  'Add a governed metric to the metrics store.': '向指标中心添加受治理的指标。',
  'Browse the catalog': '浏览数据目录',
  'Search every table and field across layers.': '检索各分层的表与字段。',
  'Check operations': '查看运维',
  'Monitor pipeline runs and data SLAs.': '监控管道运行与数据 SLA。',
  // analytics
  'Dashboard gallery': '仪表板库',
  'Dashboard editor': '仪表板编辑器',
  'Ad-hoc query': '即席查询',
  'Report subscriptions': '报表订阅',
  'Datasets': '数据集',
  'Saved, governed query results reused across dashboards and reports.': '可在仪表板与报表间复用的受治理查询结果。',
  'Browse, open, and create self-service dashboards.': '浏览、打开并创建自助仪表板。',
  'Explore data with a visual builder or SQL — results auto-route across engines.': '用可视化构建器或 SQL 探索数据 —— 结果在引擎间自动路由。',
  'Report subscription & distribution': '报表订阅与分发',
  'Schedule and deliver reports to people and channels.': '按计划将报表分发给人员与渠道。',
  // modeling
  'Metrics store': '指标中心',
  'Semantic model editor': '语义模型编辑器',
  'A governed catalog of business metrics — definitions, formulas, and ownership.': '受治理的业务指标目录 —— 定义、公式与归属。',
  'Model star schemas, map physical tables to business names, and link field lineage.': '建模星型架构，将物理表映射为业务字段，并关联字段血缘。',
  // devconfig
  'Pipelines': '数据管道',
  'Unified ingest-to-serve data pipelines across all layers.': '贯穿各分层的端到端数据管道。',
  'Data sources': '数据源',
  'ETL / DAG': 'ETL / DAG',
  'CDC / sync': 'CDC / 同步',
  'Data quality': '数据质量',
  'Data source management': '数据源管理',
  'Registered database, lakehouse, and streaming connections.': '已注册的数据库、湖仓与流式连接。',
  'ETL pipeline orchestration': 'ETL 管道编排',
  'Layered RAW → Bronze → Silver → Gold → ClickHouse DAG.': '分层 RAW → Bronze → Silver → Gold → ClickHouse 的 DAG。',
  'CDC / sync configuration': 'CDC / 同步配置',
  'Debezium change-data-capture connectors and watermarks.': 'Debezium 变更数据捕获连接器与水位。',
  'Data quality rules': '数据质量规则',
  'Assertions on tables and fields with severity and alerting.': '针对表与字段的断言，含严重级别与告警。',
  // governance
  'Data catalog': '数据目录',
  'Lineage graph': '血缘图谱',
  'Access control': '访问控制',
  'Search and explore every table and field across the platform.': '检索并浏览平台中的每一张表与字段。',
  'Trace data flow RAW → Bronze → Silver → Gold → ClickHouse, down to field level.': '追踪数据流转 RAW → Bronze → Silver → Gold → ClickHouse，细化到字段级。',
  'Manage users, roles, and row/column-level policies (RBAC / ABAC).': '管理用户、角色与行/列级策略（RBAC / ABAC）。',
  'Data classification': '数据分级',
  'Sensitivity levels, compliance tags, and auto-classification rules.': '敏感级别、合规标签与自动分级规则。',
  // monitoring
  'Task monitoring': '任务监控',
  'Resource & SLA': '资源与 SLA',
  'Live ETL run status with logs and failure recovery.': '实时 ETL 运行状态，含日志与失败恢复。',
  'Resource & SLA monitoring': '资源与 SLA 监控',
  'Cluster, Spark, and ClickHouse health plus per-pipeline data SLAs.': '集群、Spark 与 ClickHouse 健康度及各管道数据 SLA。',
  'Alerts': '告警',
  'Logs': '日志',
  'Log explorer': '日志浏览器',
  'Threshold and condition-based alert rules with severity and routing.': '基于阈值与条件的告警规则，含严重级别与路由。',
  'Search platform logs across services, levels, and time ranges.': '跨服务、级别与时间范围检索平台日志。',
  // admin
  'Users & roles': '用户与角色',
  'Organizations': '组织',
  'System config': '系统配置',
  'Audit log': '审计日志',
  'API gateway': 'API 网关',
  'Multi-tenancy': '多租户',
  'Platform administration': '平台管理',
  'Manage people, organizations, configuration, and platform-wide controls.': '管理人员、组织、配置及平台级控制。'
};
function tr(lang, s) {
  return lang === 'zh' ? IPAS_ZH[s] || s : s;
}
function trList(lang, items) {
  return items.map(it => ({
    ...it,
    label: tr(lang, it.label)
  }));
}
Object.assign(window, {
  PageHead,
  SubSwitch,
  WireTable,
  TableToolbar,
  Overflow,
  Modal,
  SidePanel,
  Placeholder,
  BarChart,
  Skeleton,
  EmptyState,
  FieldChip,
  StatusDot,
  ToolBtn,
  Stepper,
  ConditionBuilder,
  Menu,
  MenuItem,
  tr,
  trList
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "IPAS-DataPlatform/wire.jsx", error: String((e && e.message) || e) }); }

// components/core/Icon.jsx
try { (() => {
/**
 * Resolve the base path to the icon SVGs. Each consuming page can set
 * window.CDS_ICON_BASE to the correct relative path (e.g. "../../assets/icons").
 */
const DEFAULT_BASE = typeof window !== 'undefined' && window.CDS_ICON_BASE || 'assets/icons';

// Module-level cache of fetched SVG markup, keyed by full url.
const _cache = typeof window !== 'undefined' && (window.__cdsIconCache = window.__cdsIconCache || {}) || {};

/**
 * Icon — renders a Carbon SVG glyph inline so it inherits `currentColor`
 * and scales cleanly. The SVG markup is fetched once per name and cached.
 */
function Icon({
  name,
  size = 16,
  base,
  title,
  className = '',
  style = {}
}) {
  const b = base || typeof window !== 'undefined' && window.CDS_ICON_BASE || DEFAULT_BASE;
  const url = `${b}/${name}.svg`;
  const [markup, setMarkup] = React.useState(_cache[url] || null);
  React.useEffect(() => {
    let alive = true;
    if (_cache[url]) {
      if (markup !== _cache[url]) setMarkup(_cache[url]);
      return;
    }
    fetch(url).then(r => r.ok ? r.text() : Promise.reject(r.status)).then(txt => {
      // Normalize: ensure it scales to the span and inherits color.
      let svg = txt.replace(/<\?xml[^>]*\?>/g, '').replace(/\s(width|height)="[^"]*"/g, '').replace(/<svg /, '<svg width="100%" height="100%" fill="currentColor" ');
      _cache[url] = svg;
      if (alive) setMarkup(svg);
    }).catch(() => {});
    return () => {
      alive = false;
    };
  }, [url]);
  const px = typeof size === 'number' ? `${size}px` : size;
  return /*#__PURE__*/React.createElement("span", {
    role: "img",
    "aria-label": title || name,
    className: className,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: px,
      height: px,
      flex: '0 0 auto',
      lineHeight: 0,
      ...style
    },
    dangerouslySetInnerHTML: markup ? {
      __html: markup
    } : undefined
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Icon.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STYLE_ID = 'cds-button-styles';
const CSS = `
.cds--btn {
  display: inline-flex;
  align-items: center;
  box-sizing: border-box;
  position: relative;
  margin: 0;
  font-family: var(--cds-font-sans);
  font-size: .875rem;
  font-weight: 400;
  letter-spacing: .16px;
  line-height: 1.28572;
  text-align: left;
  text-decoration: none;
  vertical-align: top;
  cursor: pointer;
  border: 1px solid transparent;
  border-radius: 0;
  outline: none;
  min-height: 48px;
  padding: 14px 63px 14px 15px;
  transition: background var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              box-shadow var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              border-color var(--cds-duration-fast-01) var(--cds-ease-standard-productive),
              color var(--cds-duration-fast-01) var(--cds-ease-standard-productive);
}
.cds--btn--sm { min-height: 32px; padding-top: 6px; padding-bottom: 6px; }
.cds--btn--md { min-height: 40px; padding-top: 10px; padding-bottom: 10px; }
.cds--btn--lg { min-height: 48px; }
.cds--btn--xl { min-height: 64px; padding-top: 14px; padding-bottom: 14px; align-items: flex-start; }
.cds--btn--has-icon { padding-right: 15px; }
.cds--btn__icon { margin-left: 32px; }
.cds--btn--icon-only { padding: 0; justify-content: center; width: 48px; }
.cds--btn--icon-only.cds--btn--sm { width: 32px; }
.cds--btn--icon-only.cds--btn--md { width: 40px; }
.cds--btn--icon-only .cds--btn__icon { margin-left: 0; }
.cds--btn:focus-visible { box-shadow: inset 0 0 0 1px var(--cds-focus), inset 0 0 0 2px var(--cds-focus-inset); }

/* Primary */
.cds--btn--primary { background: var(--cds-button-primary); color: var(--cds-text-on-color); }
.cds--btn--primary:hover { background: var(--cds-button-primary-hover); }
.cds--btn--primary:active { background: var(--cds-button-primary-active); }

/* Secondary */
.cds--btn--secondary { background: var(--cds-button-secondary); color: var(--cds-text-on-color); }
.cds--btn--secondary:hover { background: var(--cds-button-secondary-hover); }
.cds--btn--secondary:active { background: var(--cds-button-secondary-active); }

/* Tertiary */
.cds--btn--tertiary { background: transparent; color: var(--cds-button-tertiary); border-color: var(--cds-button-tertiary); }
.cds--btn--tertiary:hover { background: var(--cds-button-primary-hover); color: var(--cds-text-on-color); border-color: var(--cds-button-primary-hover); }
.cds--btn--tertiary:active { background: var(--cds-button-primary-active); border-color: var(--cds-button-primary-active); }

/* Ghost */
.cds--btn--ghost { background: transparent; color: var(--cds-link-primary); padding-right: 15px; }
.cds--btn--ghost:hover { background: var(--cds-background-hover); color: var(--cds-link-primary-hover); }
.cds--btn--ghost:active { background: var(--cds-background-active); }

/* Danger */
.cds--btn--danger { background: var(--cds-button-danger); color: var(--cds-text-on-color); }
.cds--btn--danger:hover { background: var(--cds-button-danger-hover); }
.cds--btn--danger:active { background: var(--cds-button-danger-active); }

/* Disabled */
.cds--btn:disabled, .cds--btn--disabled {
  background: var(--cds-button-disabled);
  color: var(--cds-text-on-color-disabled);
  border-color: transparent;
  cursor: not-allowed;
}
.cds--btn--ghost:disabled, .cds--btn--tertiary:disabled {
  background: transparent;
  color: var(--cds-text-disabled);
  border-color: var(--cds-border-disabled);
}
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/**
 * Button — Carbon's primary action element. Rectangular (zero radius),
 * label left-aligned, optional icon pinned to the right.
 */
function Button({
  children,
  kind = 'primary',
  size = 'lg',
  icon,
  iconOnly = false,
  disabled = false,
  href,
  onClick,
  type = 'button',
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const hasIcon = !!icon && !iconOnly;
  const classes = ['cds--btn', `cds--btn--${kind}`, `cds--btn--${size}`, hasIcon ? 'cds--btn--has-icon' : '', iconOnly ? 'cds--btn--icon-only' : '', disabled ? 'cds--btn--disabled' : '', className].filter(Boolean).join(' ');
  const content = /*#__PURE__*/React.createElement(React.Fragment, null, !iconOnly && /*#__PURE__*/React.createElement("span", null, children), icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: iconOnly ? 16 : 16,
    className: "cds--btn__icon"
  }));
  if (href && !disabled) {
    return /*#__PURE__*/React.createElement("a", _extends({
      className: classes,
      href: href,
      style: style,
      onClick: onClick
    }, rest), content);
  }
  return /*#__PURE__*/React.createElement("button", _extends({
    className: classes,
    type: type,
    disabled: disabled,
    onClick: onClick,
    style: style
  }, rest), content);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/data/Tabs.jsx
try { (() => {
const STYLE_ID = 'cds-tabs-styles';
const CSS = `
.cds--tabs { font-family: var(--cds-font-sans); }
.cds--tabs__list { display: flex; list-style: none; margin: 0; padding: 0; box-shadow: inset 0 -1px 0 var(--cds-border-subtle-01); }
.cds--tab {
  appearance: none; background: transparent; border: none; cursor: pointer;
  padding: 0 16px; height: 48px;
  font-size: .875rem; line-height: 1.28572; letter-spacing: .16px;
  color: var(--cds-text-secondary);
  box-shadow: inset 0 -1px 0 var(--cds-border-subtle-01);
  border-bottom: 2px solid transparent;
  margin-bottom: -1px;
  transition: color var(--cds-duration-fast-01), border-color var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--tab:hover { color: var(--cds-text-primary); box-shadow: inset 0 -1px 0 var(--cds-border-strong-01); }
.cds--tab--selected { color: var(--cds-text-primary); font-weight: 600; border-bottom: 2px solid var(--cds-border-interactive); box-shadow: none; }
.cds--tab:disabled { color: var(--cds-text-disabled); cursor: not-allowed; }
.cds--tab:focus-visible { outline: 2px solid var(--cds-focus); outline-offset: -2px; }
.cds--tabs__panel { padding: 16px 0; font-size: .875rem; color: var(--cds-text-primary); }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tabs — line-style tab navigation with optional panel content. */
function Tabs({
  tabs = [],
  selectedIndex,
  defaultIndex = 0,
  onChange,
  className = '',
  style = {}
}) {
  useStyles();
  const isControlled = selectedIndex !== undefined;
  const [internal, setInternal] = React.useState(defaultIndex);
  const active = isControlled ? selectedIndex : internal;
  function select(i, disabled) {
    if (disabled) return;
    if (!isControlled) setInternal(i);
    onChange && onChange(i);
  }
  const normalized = tabs.map(t => typeof t === 'string' ? {
    label: t
  } : t);
  return /*#__PURE__*/React.createElement("div", {
    className: `cds--tabs ${className}`,
    style: style
  }, /*#__PURE__*/React.createElement("ul", {
    className: "cds--tabs__list",
    role: "tablist"
  }, normalized.map((t, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    role: "presentation"
  }, /*#__PURE__*/React.createElement("button", {
    role: "tab",
    "aria-selected": i === active,
    disabled: t.disabled,
    className: `cds--tab ${i === active ? 'cds--tab--selected' : ''}`,
    onClick: () => select(i, t.disabled)
  }, t.label)))), normalized[active] && normalized[active].content !== undefined && /*#__PURE__*/React.createElement("div", {
    className: "cds--tabs__panel",
    role: "tabpanel"
  }, normalized[active].content));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Tabs.jsx", error: String((e && e.message) || e) }); }

// components/data/Tag.jsx
try { (() => {
const STYLE_ID = 'cds-tag-styles';
const CSS = `
.cds--tag {
  display: inline-flex; align-items: center; gap: 6px;
  box-sizing: border-box;
  height: 24px; padding: 0 8px;
  font-family: var(--cds-font-sans);
  font-size: .75rem; line-height: 1; letter-spacing: .32px;
  border-radius: 999px;
  border: none; white-space: nowrap; max-width: 100%;
}
.cds--tag--sm { height: 18px; }
.cds--tag__label { overflow: hidden; text-overflow: ellipsis; }
.cds--tag__close {
  display: inline-flex; align-items: center; justify-content: center;
  width: 16px; height: 16px; margin-right: -4px;
  background: transparent; border: none; cursor: pointer; color: inherit;
  border-radius: 50%;
}
.cds--tag__close:hover { background: rgba(0,0,0,.16); }

.cds--tag--gray      { background: var(--cds-gray-20);    color: var(--cds-gray-100); }
.cds--tag--cool-gray { background: var(--cds-cool-gray-30);color: var(--cds-cool-gray-90); }
.cds--tag--blue      { background: var(--cds-blue-20);    color: var(--cds-blue-70); }
.cds--tag--green     { background: var(--cds-green-20);   color: var(--cds-green-70); }
.cds--tag--red       { background: var(--cds-red-20);     color: var(--cds-red-70); }
.cds--tag--magenta   { background: var(--cds-magenta-20); color: var(--cds-magenta-70); }
.cds--tag--purple    { background: var(--cds-purple-20);  color: var(--cds-purple-70); }
.cds--tag--cyan      { background: var(--cds-cyan-20);    color: var(--cds-cyan-70); }
.cds--tag--teal      { background: var(--cds-teal-10);    color: var(--cds-teal-70); }
.cds--tag--high-contrast { background: var(--cds-background-inverse); color: var(--cds-text-inverse); }
.cds--tag--outline   { background: transparent; color: var(--cds-text-primary); box-shadow: inset 0 0 0 1px var(--cds-border-strong-01); }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tag — pill-shaped label for categorization, optionally with an icon or a dismiss button. */
function Tag({
  children,
  type = 'gray',
  size = 'md',
  icon,
  filter = false,
  onClose,
  className = '',
  style = {}
}) {
  useStyles();
  return /*#__PURE__*/React.createElement("span", {
    className: ['cds--tag', `cds--tag--${type}`, `cds--tag--${size}`, className].filter(Boolean).join(' '),
    style: style
  }, icon && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: size === 'sm' ? 12 : 16
  }), /*#__PURE__*/React.createElement("span", {
    className: "cds--tag__label"
  }, children), filter && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "cds--tag__close",
    onClick: onClose,
    "aria-label": "Dismiss"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "close",
    size: 12
  })));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Tag.jsx", error: String((e && e.message) || e) }); }

// components/data/Tile.jsx
try { (() => {
const STYLE_ID = 'cds-tile-styles';
const CSS = `
.cds--tile {
  position: relative;
  box-sizing: border-box;
  background: var(--cds-layer-01);
  padding: 16px;
  border: 1px solid transparent;
  border-radius: 0;
  font-family: var(--cds-font-sans);
  color: var(--cds-text-primary);
}
.cds--tile--clickable { cursor: pointer; transition: background var(--cds-duration-fast-01); display: block; text-decoration: none; }
.cds--tile--clickable:hover { background: var(--cds-layer-hover-01); }
.cds--tile--selectable { cursor: pointer; transition: background var(--cds-duration-fast-01); }
.cds--tile--selectable:hover { background: var(--cds-layer-hover-01); }
.cds--tile--selected { border-color: var(--cds-border-interactive); }
.cds--tile__check {
  position: absolute; top: 16px; right: 16px;
  width: 16px; height: 16px; border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  border: 1px solid var(--cds-icon-primary);
}
.cds--tile--selected .cds--tile__check { background: var(--cds-border-interactive); border-color: var(--cds-border-interactive); }
.cds--tile--selected .cds--tile__check::after {
  content: ""; width: 7px; height: 4px;
  border-left: 1.5px solid var(--cds-white); border-bottom: 1.5px solid var(--cds-white);
  transform: rotate(-45deg) translateY(-1px);
}
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Tile — Carbon's container/card. Variants: base, clickable, selectable. */
function Tile({
  children,
  variant = 'base',
  selected = false,
  href,
  onClick,
  className = '',
  style = {}
}) {
  useStyles();
  const classes = ['cds--tile', variant === 'clickable' ? 'cds--tile--clickable' : '', variant === 'selectable' ? 'cds--tile--selectable' : '', selected ? 'cds--tile--selected' : '', className].filter(Boolean).join(' ');
  if (variant === 'clickable' && href) {
    return /*#__PURE__*/React.createElement("a", {
      className: classes,
      href: href,
      onClick: onClick,
      style: style
    }, children);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: classes,
    onClick: onClick,
    style: style
  }, variant === 'selectable' && /*#__PURE__*/React.createElement("span", {
    className: "cds--tile__check"
  }), children);
}
Object.assign(__ds_scope, { Tile });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/Tile.jsx", error: String((e && e.message) || e) }); }

// components/feedback/InlineNotification.jsx
try { (() => {
const STYLE_ID = 'cds-notification-styles';
const CSS = `
.cds--notif {
  display: flex; align-items: flex-start; gap: 12px;
  box-sizing: border-box; min-height: 48px;
  padding: 14px 16px;
  font-family: var(--cds-font-sans);
  border-left: 3px solid transparent;
  background: var(--cds-layer-01);
  color: var(--cds-text-primary);
  box-shadow: inset 0 0 0 1px rgba(0,0,0,0.04);
}
.cds--notif__icon { flex: 0 0 auto; margin-top: 1px; }
.cds--notif__body { flex: 1; font-size: .875rem; line-height: 1.42857; letter-spacing: .16px; }
.cds--notif__title { font-weight: 600; margin-right: 4px; }
.cds--notif__close {
  flex: 0 0 auto; width: 20px; height: 20px; margin: -2px -4px 0 0;
  background: transparent; border: none; cursor: pointer; color: var(--cds-icon-primary);
  display: flex; align-items: center; justify-content: center;
}
.cds--notif__close:hover { background: var(--cds-background-hover); }

.cds--notif--error   { border-left-color: var(--cds-support-error); }
.cds--notif--error   .cds--notif__icon { color: var(--cds-support-error); }
.cds--notif--success { border-left-color: var(--cds-support-success); }
.cds--notif--success .cds--notif__icon { color: var(--cds-support-success); }
.cds--notif--warning { border-left-color: var(--cds-support-warning); }
.cds--notif--warning .cds--notif__icon { color: var(--cds-support-warning); }
.cds--notif--info    { border-left-color: var(--cds-support-info); }
.cds--notif--info    .cds--notif__icon { color: var(--cds-support-info); }
`;
const ICONS = {
  error: 'error--filled',
  success: 'checkmark--filled',
  warning: 'warning--filled',
  info: 'information--filled'
};
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** InlineNotification — status message with a colored left accent and status icon. */
function InlineNotification({
  kind = 'info',
  title,
  subtitle,
  onClose,
  hideCloseButton = false,
  className = '',
  style = {}
}) {
  useStyles();
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    className: `cds--notif cds--notif--${kind} ${className}`,
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: ICONS[kind],
    className: "cds--notif__icon"
  }), /*#__PURE__*/React.createElement("div", {
    className: "cds--notif__body"
  }, title && /*#__PURE__*/React.createElement("span", {
    className: "cds--notif__title"
  }, title), subtitle && /*#__PURE__*/React.createElement("span", null, subtitle)), !hideCloseButton && /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "cds--notif__close",
    onClick: onClose,
    "aria-label": "Close notification"
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "close"
  })));
}
Object.assign(__ds_scope, { InlineNotification });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/InlineNotification.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Loading.jsx
try { (() => {
const STYLE_ID = 'cds-loading-styles';
const CSS = `
@keyframes cds-spin { to { transform: rotate(360deg); } }
.cds--loading {
  display: inline-block;
  width: 88px; height: 88px;
  border-radius: 50%;
  border: 10px solid var(--cds-border-subtle-01);
  border-top-color: var(--cds-interactive);
  animation: cds-spin 690ms linear infinite;
}
.cds--loading--sm { width: 16px; height: 16px; border-width: 2px; }
.cds--loading--md { width: 44px; height: 44px; border-width: 5px; }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Loading — circular activity spinner. */
function Loading({
  size = 'lg',
  className = '',
  style = {}
}) {
  useStyles();
  const sz = size === 'sm' ? 'cds--loading--sm' : size === 'md' ? 'cds--loading--md' : '';
  return /*#__PURE__*/React.createElement("div", {
    role: "status",
    "aria-label": "Loading",
    className: `cds--loading ${sz} ${className}`,
    style: style
  });
}
Object.assign(__ds_scope, { Loading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Loading.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STYLE_ID = 'cds-checkbox-styles';
const CSS = `
.cds--checkbox { display: inline-flex; align-items: center; gap: 8px; font-family: var(--cds-font-sans); cursor: pointer; user-select: none; }
.cds--checkbox--disabled { cursor: not-allowed; }
.cds--checkbox__box {
  position: relative;
  width: 16px; height: 16px;
  box-sizing: border-box;
  flex: 0 0 auto;
  border: 1px solid var(--cds-icon-primary);
  border-radius: 0;
  background: transparent;
  display: inline-flex; align-items: center; justify-content: center;
  transition: background var(--cds-duration-fast-01), border-color var(--cds-duration-fast-01);
}
.cds--checkbox--checked .cds--checkbox__box { background: var(--cds-icon-primary); border-color: var(--cds-icon-primary); }
.cds--checkbox__check { color: var(--cds-icon-inverse); width: 12px; height: 12px; }
.cds--checkbox__label { font-size: .875rem; line-height: 1.28572; letter-spacing: .16px; color: var(--cds-text-primary); }
.cds--checkbox--disabled .cds--checkbox__box { border-color: var(--cds-text-disabled); }
.cds--checkbox--disabled.cds--checkbox--checked .cds--checkbox__box { background: var(--cds-text-disabled); }
.cds--checkbox--disabled .cds--checkbox__label { color: var(--cds-text-disabled); }
.cds--checkbox:focus-within .cds--checkbox__box { outline: 2px solid var(--cds-focus); outline-offset: 1px; }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Checkbox — square selection control with a label. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled = false,
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isChecked = isControlled ? checked : internal;
  function handle(e) {
    if (disabled) return;
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e.target.checked, e);
  }
  return /*#__PURE__*/React.createElement("label", {
    className: ['cds--checkbox', isChecked ? 'cds--checkbox--checked' : '', disabled ? 'cds--checkbox--disabled' : '', className].filter(Boolean).join(' '),
    style: style
  }, /*#__PURE__*/React.createElement("input", _extends({
    type: "checkbox",
    checked: isChecked,
    onChange: handle,
    disabled: disabled,
    style: {
      position: 'absolute',
      opacity: 0,
      width: 0,
      height: 0
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    className: "cds--checkbox__box"
  }, isChecked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "checkmark",
    className: "cds--checkbox__check",
    size: 12
  })), label && /*#__PURE__*/React.createElement("span", {
    className: "cds--checkbox__label"
  }, label));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/Dropdown.jsx
try { (() => {
const STYLE_ID = 'cds-dropdown-styles';
const CSS = `
.cds--dropdown { display: flex; flex-direction: column; font-family: var(--cds-font-sans); position: relative; }
.cds--dropdown__label { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 6px; }
.cds--dropdown__trigger {
  display: flex; align-items: center; justify-content: space-between;
  width: 100%; height: 40px; box-sizing: border-box;
  padding: 0 16px;
  background: var(--cds-field-01);
  border: none; border-bottom: 1px solid var(--cds-border-strong-01);
  border-radius: 0; cursor: pointer; text-align: left;
  font-size: .875rem; letter-spacing: .16px; color: var(--cds-text-primary);
  outline: 2px solid transparent; outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01);
}
.cds--dropdown__trigger:focus-visible { outline: 2px solid var(--cds-focus); }
.cds--dropdown__trigger--placeholder { color: var(--cds-text-placeholder); }
.cds--dropdown__chevron { transition: transform var(--cds-duration-fast-02) var(--cds-ease-standard-productive); color: var(--cds-icon-primary); }
.cds--dropdown--open .cds--dropdown__chevron { transform: rotate(180deg); }
.cds--dropdown__menu {
  position: absolute; top: 100%; left: 0; right: 0; z-index: 20;
  background: var(--cds-layer-02);
  box-shadow: var(--cds-shadow-menu);
  max-height: 240px; overflow-y: auto; list-style: none; margin: 0; padding: 0;
}
.cds--dropdown__item {
  display: flex; align-items: center; height: 40px; padding: 0 16px;
  font-size: .875rem; color: var(--cds-text-secondary); cursor: pointer;
  border-bottom: 1px solid var(--cds-border-subtle-01);
}
.cds--dropdown__item:hover { background: var(--cds-layer-hover-01); color: var(--cds-text-primary); }
.cds--dropdown__item--selected { color: var(--cds-text-primary); font-weight: 600; }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Dropdown — single-select listbox styled as a Carbon field. */
function Dropdown({
  label,
  items = [],
  value,
  placeholder = 'Choose an option',
  onChange,
  className = '',
  style = {}
}) {
  useStyles();
  const [open, setOpen] = React.useState(false);
  const [internal, setInternal] = React.useState(value);
  const ref = React.useRef(null);
  const selected = value !== undefined ? value : internal;
  React.useEffect(() => {
    function onDoc(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);
  const normalized = items.map(it => typeof it === 'string' ? {
    label: it,
    value: it
  } : it);
  const current = normalized.find(it => it.value === selected);
  function pick(it) {
    if (value === undefined) setInternal(it.value);
    onChange && onChange(it.value);
    setOpen(false);
  }
  return /*#__PURE__*/React.createElement("div", {
    ref: ref,
    className: `cds--dropdown ${open ? 'cds--dropdown--open' : ''} ${className}`,
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "cds--dropdown__label"
  }, label), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: `cds--dropdown__trigger ${current ? '' : 'cds--dropdown__trigger--placeholder'}`,
    onClick: () => setOpen(o => !o),
    "aria-haspopup": "listbox",
    "aria-expanded": open
  }, /*#__PURE__*/React.createElement("span", null, current ? current.label : placeholder), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "chevron--down",
    className: "cds--dropdown__chevron"
  })), open && /*#__PURE__*/React.createElement("ul", {
    className: "cds--dropdown__menu",
    role: "listbox"
  }, normalized.map(it => /*#__PURE__*/React.createElement("li", {
    key: it.value,
    role: "option",
    "aria-selected": it.value === selected,
    className: `cds--dropdown__item ${it.value === selected ? 'cds--dropdown__item--selected' : ''}`,
    onClick: () => pick(it)
  }, it.label))));
}
Object.assign(__ds_scope, { Dropdown });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Dropdown.jsx", error: String((e && e.message) || e) }); }

// components/forms/Search.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STYLE_ID = 'cds-search-styles';
const CSS = `
.cds--search { position: relative; display: flex; align-items: center; width: 100%; font-family: var(--cds-font-sans); }
.cds--search__magnifier { position: absolute; left: 12px; color: var(--cds-icon-secondary); pointer-events: none; }
.cds--search__input {
  width: 100%; height: 40px; box-sizing: border-box;
  padding: 0 40px 0 40px;
  background: var(--cds-field-01);
  border: none; border-bottom: 1px solid transparent;
  border-radius: 0;
  font-size: .875rem; letter-spacing: .16px; color: var(--cds-text-primary);
  outline: 2px solid transparent; outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--search__input::placeholder { color: var(--cds-text-placeholder); }
.cds--search__input:focus { outline: 2px solid var(--cds-focus); }
.cds--search--sm .cds--search__input { height: 32px; }
.cds--search--lg .cds--search__input { height: 48px; }
.cds--search__clear {
  position: absolute; right: 0; height: 100%; width: 40px;
  display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; cursor: pointer; color: var(--cds-icon-primary);
  opacity: 0; pointer-events: none; transition: opacity var(--cds-duration-fast-01);
}
.cds--search__clear--visible { opacity: 1; pointer-events: auto; }
.cds--search__clear:hover { background: var(--cds-background-hover); }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Search — input with a leading magnifier and a clear button. */
function Search({
  placeholder = 'Search',
  value,
  defaultValue = '',
  onChange,
  onClear,
  size = 'md',
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const isControlled = value !== undefined;
  const [internal, setInternal] = React.useState(defaultValue);
  const val = isControlled ? value : internal;
  function handle(e) {
    if (!isControlled) setInternal(e.target.value);
    onChange && onChange(e.target.value, e);
  }
  function clear() {
    if (!isControlled) setInternal('');
    onChange && onChange('');
    onClear && onClear();
  }
  return /*#__PURE__*/React.createElement("div", {
    className: `cds--search cds--search--${size} ${className}`,
    style: style
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "search",
    className: "cds--search__magnifier"
  }), /*#__PURE__*/React.createElement("input", _extends({
    type: "text",
    className: "cds--search__input",
    placeholder: placeholder,
    value: val,
    onChange: handle
  }, rest)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: `cds--search__clear ${val ? 'cds--search__clear--visible' : ''}`,
    onClick: clear,
    "aria-label": "Clear search",
    tabIndex: val ? 0 : -1
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "close"
  })));
}
Object.assign(__ds_scope, { Search });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Search.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextInput.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const STYLE_ID = 'cds-textinput-styles';
const CSS = `
.cds--form-item { display: flex; flex-direction: column; font-family: var(--cds-font-sans); }
.cds--label { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 6px; }
.cds--label--disabled { color: var(--cds-text-disabled); }
.cds--text-input__wrap { position: relative; display: flex; align-items: center; }
.cds--text-input {
  width: 100%;
  height: 40px;
  box-sizing: border-box;
  padding: 0 16px;
  font-family: var(--cds-font-sans);
  font-size: .875rem;
  letter-spacing: .16px;
  color: var(--cds-text-primary);
  background: var(--cds-field-01);
  border: none;
  border-bottom: 1px solid var(--cds-border-strong-01);
  border-radius: 0;
  outline: 2px solid transparent;
  outline-offset: -2px;
  transition: outline var(--cds-duration-fast-01), background var(--cds-duration-fast-01);
}
.cds--text-input--sm { height: 32px; }
.cds--text-input--lg { height: 48px; }
.cds--text-input::placeholder { color: var(--cds-text-placeholder); }
.cds--text-input:focus { outline: 2px solid var(--cds-focus); }
.cds--text-input:disabled { color: var(--cds-text-disabled); background: var(--cds-field-01); border-bottom-color: transparent; cursor: not-allowed; }
.cds--text-input--invalid { outline: 2px solid var(--cds-support-error); border-bottom-color: transparent; }
.cds--text-input__icon { position: absolute; right: 16px; pointer-events: none; }
.cds--text-input__icon--error { color: var(--cds-support-error); }
.cds--form__helper { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-helper); margin-top: 6px; }
.cds--form__error { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-error); margin-top: 6px; }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/**
 * TextInput — single-line field with label, helper and error states.
 */
function TextInput({
  label,
  placeholder,
  value,
  defaultValue,
  onChange,
  type = 'text',
  size = 'md',
  helperText,
  invalid = false,
  invalidText,
  disabled = false,
  id,
  className = '',
  style = {},
  ...rest
}) {
  useStyles();
  const inputId = id || `cds-input-${Math.random().toString(36).slice(2, 8)}`;
  return /*#__PURE__*/React.createElement("div", {
    className: `cds--form-item ${className}`,
    style: style
  }, label && /*#__PURE__*/React.createElement("label", {
    className: `cds--label ${disabled ? 'cds--label--disabled' : ''}`,
    htmlFor: inputId
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "cds--text-input__wrap"
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: type,
    className: ['cds--text-input', `cds--text-input--${size}`, invalid ? 'cds--text-input--invalid' : ''].filter(Boolean).join(' '),
    placeholder: placeholder,
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    disabled: disabled
  }, rest)), invalid && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "warning--filled",
    className: "cds--text-input__icon cds--text-input__icon--error"
  })), invalid && invalidText ? /*#__PURE__*/React.createElement("div", {
    className: "cds--form__error"
  }, invalidText) : helperText ? /*#__PURE__*/React.createElement("div", {
    className: "cds--form__helper"
  }, helperText) : null);
}
Object.assign(__ds_scope, { TextInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextInput.jsx", error: String((e && e.message) || e) }); }

// components/forms/Toggle.jsx
try { (() => {
const STYLE_ID = 'cds-toggle-styles';
const CSS = `
.cds--toggle { display: inline-flex; flex-direction: column; font-family: var(--cds-font-sans); }
.cds--toggle__label-text { font-size: .75rem; line-height: 1.33333; letter-spacing: .32px; color: var(--cds-text-secondary); margin-bottom: 8px; }
.cds--toggle__row { display: inline-flex; align-items: center; gap: 12px; cursor: pointer; }
.cds--toggle--disabled .cds--toggle__row { cursor: not-allowed; }
.cds--toggle__track {
  position: relative;
  width: 48px; height: 24px;
  flex: 0 0 auto;
  background: var(--cds-toggle-off);
  border-radius: 999px;
  transition: background var(--cds-duration-fast-02) var(--cds-ease-standard-productive);
}
.cds--toggle__track--sm { width: 32px; height: 16px; }
.cds--toggle__knob {
  position: absolute; top: 3px; left: 3px;
  width: 18px; height: 18px;
  background: var(--cds-white);
  border-radius: 50%;
  display: flex; align-items: center; justify-content: center;
  transition: transform var(--cds-duration-fast-02) var(--cds-ease-standard-productive);
}
.cds--toggle__track--sm .cds--toggle__knob { width: 10px; height: 10px; top: 3px; left: 3px; }
.cds--toggle--checked .cds--toggle__track { background: var(--cds-support-success); }
.cds--toggle--checked .cds--toggle__knob { transform: translateX(24px); }
.cds--toggle--checked .cds--toggle__track--sm .cds--toggle__knob { transform: translateX(16px); }
.cds--toggle__knob::after {
  content: ""; display: none;
  width: 8px; height: 4px;
  border-left: 1.5px solid var(--cds-support-success);
  border-bottom: 1.5px solid var(--cds-support-success);
  transform: rotate(-45deg) translateY(-1px);
}
.cds--toggle--checked .cds--toggle__track:not(.cds--toggle__track--sm) .cds--toggle__knob::after { display: block; }
.cds--toggle--disabled .cds--toggle__track { background: var(--cds-border-disabled); }
.cds--toggle__state { font-size: .875rem; color: var(--cds-text-primary); }
.cds--toggle__row:focus-within .cds--toggle__track { outline: 2px solid var(--cds-focus); outline-offset: 1px; }
`;
function useStyles() {
  if (typeof document === 'undefined') return;
  if (!document.getElementById(STYLE_ID)) {
    const el = document.createElement('style');
    el.id = STYLE_ID;
    el.textContent = CSS;
    document.head.appendChild(el);
  }
}

/** Toggle — on/off switch that turns green when on, with optional state label. */
function Toggle({
  label,
  checked,
  defaultChecked,
  onChange,
  size = 'md',
  labelOn = 'On',
  labelOff = 'Off',
  hideStateLabel = false,
  disabled = false,
  className = '',
  style = {}
}) {
  useStyles();
  const isControlled = checked !== undefined;
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isChecked = isControlled ? checked : internal;
  function toggle() {
    if (disabled) return;
    const next = !isChecked;
    if (!isControlled) setInternal(next);
    onChange && onChange(next);
  }
  return /*#__PURE__*/React.createElement("div", {
    className: ['cds--toggle', isChecked ? 'cds--toggle--checked' : '', disabled ? 'cds--toggle--disabled' : '', className].filter(Boolean).join(' '),
    style: style
  }, label && /*#__PURE__*/React.createElement("span", {
    className: "cds--toggle__label-text"
  }, label), /*#__PURE__*/React.createElement("div", {
    className: "cds--toggle__row",
    role: "switch",
    "aria-checked": isChecked,
    tabIndex: disabled ? -1 : 0,
    onClick: toggle,
    onKeyDown: e => {
      if (e.key === ' ' || e.key === 'Enter') {
        e.preventDefault();
        toggle();
      }
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: `cds--toggle__track ${size === 'sm' ? 'cds--toggle__track--sm' : ''}`
  }, /*#__PURE__*/React.createElement("span", {
    className: "cds--toggle__knob"
  })), !hideStateLabel && size !== 'sm' && /*#__PURE__*/React.createElement("span", {
    className: "cds--toggle__state"
  }, isChecked ? labelOn : labelOff)));
}
Object.assign(__ds_scope, { Toggle });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Toggle.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cloud-console/App.jsx
try { (() => {
/* global React, AppHeader, SideNav, ResourcesTable, Overview */
const {
  Button,
  Tabs,
  TextInput,
  Dropdown,
  InlineNotification,
  Tag,
  Tile,
  Icon
} = window.CarbonDesignSystem_280d33;
const APP_CSS = `
.page { padding: 32px 32px 64px; max-width: 1200px; }
.crumb { font-size: .75rem; color: var(--cds-text-secondary); margin-bottom: 16px; letter-spacing:.32px; }
.crumb a { color: var(--cds-link-primary); text-decoration: none; }
.crumb a:hover { text-decoration: underline; }
.page__head { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 24px; gap: 24px; }
.page__head h1 { font-size: 1.75rem; font-weight: 400; line-height: 1.28; margin: 0; color: var(--cds-text-primary); }
.page__head p { margin: 8px 0 0; font-size: .875rem; color: var(--cds-text-secondary); }
.toast-stack { position: fixed; top: 60px; right: 16px; z-index: 50; width: 360px; display: flex; flex-direction: column; gap: 8px; }
/* Side panel */
.scrim { position: fixed; inset: 0; background: var(--cds-overlay); z-index: 40; }
.panel-create { position: fixed; top: 0; right: 0; bottom: 0; width: 420px; background: var(--cds-layer-02);
  z-index: 45; box-shadow: var(--cds-shadow-modal); display: flex; flex-direction: column; }
.panel-create__head { padding: 24px; border-bottom: 1px solid var(--cds-border-subtle-01); }
.panel-create__head .sup { font-size: .75rem; color: var(--cds-text-secondary); letter-spacing:.32px; }
.panel-create__head h2 { font-size: 1.25rem; font-weight: 400; margin: 6px 0 0; color: var(--cds-text-primary); }
.panel-create__body { padding: 24px; display: flex; flex-direction: column; gap: 24px; flex: 1; overflow: auto; }
.panel-create__foot { display: flex; }
.panel-create__foot > * { flex: 1; }
.kit-frame { border: 1px solid var(--cds-border-subtle-01); }
`;
function inject() {
  if (typeof document === 'undefined' || document.getElementById('cds-app-styles')) return;
  const el = document.createElement('style');
  el.id = 'cds-app-styles';
  el.textContent = APP_CSS;
  document.head.appendChild(el);
}
const SEED = [{
  name: 'api-gateway-prod',
  status: 'Running',
  service: 'Code Engine',
  region: 'US South',
  created: 'Apr 2, 2026'
}, {
  name: 'postgres-cluster-02',
  status: 'Provisioning',
  service: 'Databases',
  region: 'EU Frankfurt',
  created: 'Apr 1, 2026'
}, {
  name: 'object-store-assets',
  status: 'Running',
  service: 'Object Storage',
  region: 'US East',
  created: 'Mar 28, 2026'
}, {
  name: 'ml-inference-gpu',
  status: 'Stopped',
  service: 'Watson ML',
  region: 'AP Sydney',
  created: 'Mar 21, 2026'
}, {
  name: 'edge-cache-eu',
  status: 'Failed',
  service: 'CDN',
  region: 'EU London',
  created: 'Mar 19, 2026'
}];
const TITLES = {
  overview: ['Overview', 'Account health and recent activity across your resources.'],
  resources: ['Resource list', 'All provisioned services in this resource group.'],
  catalog: ['Catalog', 'Browse and provision new services.'],
  activity: ['Activity', 'Audit log of account events.'],
  billing: ['Billing & usage', 'Track spend against your monthly budget.']
};
function App() {
  inject();
  const [nav, setNav] = React.useState('overview');
  const [collapsed, setCollapsed] = React.useState(false);
  const [rows, setRows] = React.useState(SEED);
  const [creating, setCreating] = React.useState(false);
  const [toasts, setToasts] = React.useState([]);
  const [form, setForm] = React.useState({
    name: '',
    service: 'Code Engine',
    region: 'US South'
  });
  function addToast(t) {
    const id = Math.random().toString(36).slice(2);
    setToasts(ts => [...ts, {
      ...t,
      id
    }]);
    setTimeout(() => setToasts(ts => ts.filter(x => x.id !== id)), 4500);
  }
  function create() {
    const name = form.name.trim() || 'new-resource';
    setRows(r => [{
      name,
      status: 'Provisioning',
      service: form.service,
      region: form.region,
      created: 'Just now'
    }, ...r]);
    setCreating(false);
    setForm({
      name: '',
      service: 'Code Engine',
      region: 'US South'
    });
    addToast({
      kind: 'success',
      title: 'Resource created.',
      subtitle: `${name} is provisioning.`
    });
    setNav('resources');
  }
  const [title, sub] = TITLES[nav];
  return /*#__PURE__*/React.createElement("div", {
    className: "shell"
  }, /*#__PURE__*/React.createElement(AppHeader, {
    onToggleNav: () => setCollapsed(c => !c)
  }), /*#__PURE__*/React.createElement("div", {
    className: "shell__body"
  }, /*#__PURE__*/React.createElement(SideNav, {
    current: nav,
    onSelect: setNav,
    collapsed: collapsed
  }), /*#__PURE__*/React.createElement("main", {
    className: "shell__main"
  }, /*#__PURE__*/React.createElement("div", {
    className: "page"
  }, /*#__PURE__*/React.createElement("div", {
    className: "crumb"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Resource list"), " / ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "my-project"), " / ", title), /*#__PURE__*/React.createElement("div", {
    className: "page__head"
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", null, title), /*#__PURE__*/React.createElement("p", null, sub)), nav === 'overview' && /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    icon: "add",
    onClick: () => setCreating(true)
  }, "Create resource")), nav === 'overview' && /*#__PURE__*/React.createElement(Overview, null), nav === 'resources' && /*#__PURE__*/React.createElement(Tabs, {
    tabs: [{
      label: `All (${rows.length})`,
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(ResourcesTable, {
        rows: rows,
        onCreate: () => setCreating(true)
      }))
    }, {
      label: 'Running',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(ResourcesTable, {
        rows: rows.filter(r => r.status === 'Running'),
        onCreate: () => setCreating(true)
      }))
    }, {
      label: 'Stopped',
      content: /*#__PURE__*/React.createElement("div", {
        style: {
          marginTop: 8
        }
      }, /*#__PURE__*/React.createElement(ResourcesTable, {
        rows: rows.filter(r => r.status === 'Stopped'),
        onCreate: () => setCreating(true)
      }))
    }]
  }), (nav === 'catalog' || nav === 'activity' || nav === 'billing') && /*#__PURE__*/React.createElement(Tile, {
    style: {
      padding: 48,
      textAlign: 'center',
      color: 'var(--cds-text-secondary)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: nav === 'catalog' ? 'grid' : nav === 'activity' ? 'analytics' : 'chart--bar',
    size: 32
  }), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 12
    }
  }, title, " \u2014 sample surface. Use the Overview and Resource list tabs for the full interactive demo."))))), toasts.length > 0 && /*#__PURE__*/React.createElement("div", {
    className: "toast-stack"
  }, toasts.map(t => /*#__PURE__*/React.createElement(InlineNotification, {
    key: t.id,
    kind: t.kind,
    title: t.title,
    subtitle: t.subtitle,
    onClose: () => setToasts(ts => ts.filter(x => x.id !== t.id))
  }))), creating && /*#__PURE__*/React.createElement("div", {
    className: "scrim",
    onClick: () => setCreating(false)
  }), creating && /*#__PURE__*/React.createElement("aside", {
    className: "panel-create"
  }, /*#__PURE__*/React.createElement("div", {
    className: "panel-create__head"
  }, /*#__PURE__*/React.createElement("div", {
    className: "sup"
  }, "Provision"), /*#__PURE__*/React.createElement("h2", null, "Create resource")), /*#__PURE__*/React.createElement("div", {
    className: "panel-create__body"
  }, /*#__PURE__*/React.createElement(TextInput, {
    label: "Resource name",
    placeholder: "my-service",
    value: form.name,
    onChange: e => setForm(f => ({
      ...f,
      name: e.target.value
    })),
    helperText: "Lowercase, hyphen-separated."
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Service",
    value: form.service,
    items: ['Code Engine', 'Databases', 'Object Storage', 'Watson ML', 'CDN'],
    onChange: v => setForm(f => ({
      ...f,
      service: v
    }))
  }), /*#__PURE__*/React.createElement(Dropdown, {
    label: "Region",
    value: form.region,
    items: ['US South', 'US East', 'EU Frankfurt', 'EU London', 'AP Sydney'],
    onChange: v => setForm(f => ({
      ...f,
      region: v
    }))
  })), /*#__PURE__*/React.createElement("div", {
    className: "panel-create__foot"
  }, /*#__PURE__*/React.createElement(Button, {
    kind: "secondary",
    onClick: () => setCreating(false)
  }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    icon: "add",
    onClick: create
  }, "Create"))));
}
Object.assign(window, {
  App
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cloud-console/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cloud-console/Overview.jsx
try { (() => {
/* global React */
const {
  Icon,
  Tile,
  Button
} = window.CarbonDesignSystem_280d33;
const OV_CSS = `
.ov { display: grid; grid-template-columns: repeat(12, 1fr); gap: 1px; background: var(--cds-border-subtle-01); }
.ov > * { background: var(--cds-layer-02); }
.ov .stat { grid-column: span 3; padding: 24px; }
.ov .stat .k { font-size: .75rem; letter-spacing: .32px; color: var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.ov .stat .v { font-size: 2.625rem; font-weight: 300; line-height: 1.1; color: var(--cds-text-primary); margin-top: 12px; }
.ov .stat .d { font-size: .75rem; color: var(--cds-text-secondary); margin-top: 8px; }
.ov .stat .d.up { color: var(--cds-support-success); }
.ov .panel { grid-column: span 6; padding: 24px; }
.ov .panel.full { grid-column: span 12; }
.ov h3 { font-size: 1rem; font-weight: 600; margin: 0 0 16px; color: var(--cds-text-primary); }
.bars { display: flex; align-items: flex-end; gap: 10px; height: 120px; }
.bars .bar { flex: 1; background: var(--cds-blue-60); }
.bars .bar:nth-child(even){ background: var(--cds-blue-40); }
.legend { display:flex; gap:16px; margin-top:14px; font-size:.75rem; color:var(--cds-text-secondary); }
.legend i { display:inline-block; width:10px; height:10px; margin-right:6px; vertical-align:middle; }
.activity { list-style:none; margin:0; padding:0; }
.activity li { display:flex; gap:12px; align-items:flex-start; padding:12px 0; border-bottom:1px solid var(--cds-border-subtle-01); font-size:.875rem; }
.activity li:last-child{ border-bottom:none; }
.activity .ic { color: var(--cds-icon-secondary); margin-top:2px; }
.activity .t { color: var(--cds-text-primary); }
.activity .m { color: var(--cds-text-secondary); font-size:.75rem; margin-top:2px; }
`;
function injectOv() {
  if (typeof document === 'undefined' || document.getElementById('cds-ov-styles')) return;
  const el = document.createElement('style');
  el.id = 'cds-ov-styles';
  el.textContent = OV_CSS;
  document.head.appendChild(el);
}
function Stat({
  label,
  icon,
  value,
  delta,
  up
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "stat"
  }, /*#__PURE__*/React.createElement("div", {
    className: "k"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: icon,
    size: 16
  }), label), /*#__PURE__*/React.createElement("div", {
    className: "v"
  }, value), /*#__PURE__*/React.createElement("div", {
    className: `d ${up ? 'up' : ''}`
  }, delta));
}
function Overview() {
  injectOv();
  const heights = [40, 62, 55, 78, 70, 92, 84, 60];
  return /*#__PURE__*/React.createElement("div", {
    className: "ov"
  }, /*#__PURE__*/React.createElement(Stat, {
    label: "Active resources",
    icon: "data--base",
    value: "24",
    delta: "+3 this week",
    up: true
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Monthly spend",
    icon: "chart--bar",
    value: "$1,284",
    delta: "62% of budget"
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Avg. CPU",
    icon: "analytics",
    value: "38%",
    delta: "Healthy",
    up: true
  }), /*#__PURE__*/React.createElement(Stat, {
    label: "Open alerts",
    icon: "warning--alt",
    value: "2",
    delta: "1 critical"
  }), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("h3", null, "Compute usage"), /*#__PURE__*/React.createElement("div", {
    className: "bars"
  }, heights.map((h, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "bar",
    style: {
      height: h + '%'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    className: "legend"
  }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    style: {
      background: 'var(--cds-blue-60)'
    }
  }), "Provisioned"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("i", {
    style: {
      background: 'var(--cds-blue-40)'
    }
  }), "Reserved"))), /*#__PURE__*/React.createElement("div", {
    className: "panel"
  }, /*#__PURE__*/React.createElement("h3", null, "Recent activity"), /*#__PURE__*/React.createElement("ul", {
    className: "activity"
  }, /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Icon, {
    name: "checkmark--filled",
    size: 16,
    className: "ic",
    style: {
      color: 'var(--cds-support-success)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "api-gateway-prod deployed"), /*#__PURE__*/React.createElement("div", {
    className: "m"
  }, "2 minutes ago \xB7 US South"))), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Icon, {
    name: "renew",
    size: 16,
    className: "ic"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "postgres-cluster-02 scaling up"), /*#__PURE__*/React.createElement("div", {
    className: "m"
  }, "18 minutes ago \xB7 EU Frankfurt"))), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Icon, {
    name: "user--avatar",
    size: 16,
    className: "ic"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "A. Kapoor invited to project"), /*#__PURE__*/React.createElement("div", {
    className: "m"
  }, "1 hour ago"))), /*#__PURE__*/React.createElement("li", null, /*#__PURE__*/React.createElement(Icon, {
    name: "warning--filled",
    size: 16,
    className: "ic",
    style: {
      color: 'var(--cds-support-warning)'
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "t"
  }, "object-store nearing quota"), /*#__PURE__*/React.createElement("div", {
    className: "m"
  }, "3 hours ago"))))));
}
Object.assign(window, {
  Overview
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cloud-console/Overview.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cloud-console/ResourcesTable.jsx
try { (() => {
/* global React */
const {
  Icon,
  Tag,
  Search,
  Button
} = window.CarbonDesignSystem_280d33;
const TABLE_CSS = `
.cds-tbl-wrap { background: var(--cds-layer-02); }
.cds-tbl-toolbar { display: flex; align-items: stretch; height: 48px; border-bottom: 1px solid var(--cds-border-subtle-01); }
.cds-tbl-toolbar .grow { flex: 1; display: flex; align-items: center; }
.cds-tbl-toolbar .cds--search__input { background: var(--cds-layer-02); height: 48px; }
.cds-tbl { width: 100%; border-collapse: collapse; font-family: var(--cds-font-sans); }
.cds-tbl th { text-align: left; font-size: .875rem; font-weight: 600; color: var(--cds-text-primary);
  background: var(--cds-layer-accent-01); height: 48px; padding: 0 16px; white-space: nowrap; }
.cds-tbl td { font-size: .875rem; color: var(--cds-text-secondary); height: 48px; padding: 0 16px;
  border-bottom: 1px solid var(--cds-border-subtle-01); background: var(--cds-layer-02); }
.cds-tbl tr:hover td { background: var(--cds-layer-hover-02); }
.cds-tbl td.name { color: var(--cds-text-primary); font-weight: 500; }
.cds-tbl td.name a { color: var(--cds-link-primary); text-decoration: none; }
.cds-tbl td.name a:hover { text-decoration: underline; }
.cds-tbl .overflow { width: 48px; text-align: center; color: var(--cds-icon-primary); cursor: pointer; }
.cds-tbl__sort { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
`;
function injectTable() {
  if (typeof document === 'undefined' || document.getElementById('cds-table-styles')) return;
  const el = document.createElement('style');
  el.id = 'cds-table-styles';
  el.textContent = TABLE_CSS;
  document.head.appendChild(el);
}
const STATUS = {
  Running: {
    type: 'green',
    icon: 'checkmark'
  },
  Provisioning: {
    type: 'blue',
    icon: 'renew'
  },
  Stopped: {
    type: 'gray'
  },
  Failed: {
    type: 'red'
  }
};
function ResourcesTable({
  rows,
  onCreate
}) {
  injectTable();
  const [q, setQ] = React.useState('');
  const filtered = rows.filter(r => r.name.toLowerCase().includes(q.toLowerCase()));
  return /*#__PURE__*/React.createElement("div", {
    className: "cds-tbl-wrap"
  }, /*#__PURE__*/React.createElement("div", {
    className: "cds-tbl-toolbar"
  }, /*#__PURE__*/React.createElement("div", {
    className: "grow"
  }, /*#__PURE__*/React.createElement(Search, {
    value: q,
    onChange: setQ,
    size: "lg",
    placeholder: "Search resources"
  })), /*#__PURE__*/React.createElement(Button, {
    kind: "ghost",
    size: "lg",
    icon: "filter",
    iconOnly: true
  }), /*#__PURE__*/React.createElement(Button, {
    kind: "primary",
    size: "lg",
    icon: "add",
    onClick: onCreate
  }, "Create resource")), /*#__PURE__*/React.createElement("table", {
    className: "cds-tbl"
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", null, /*#__PURE__*/React.createElement("span", {
    className: "cds-tbl__sort"
  }, "Name ", /*#__PURE__*/React.createElement(Icon, {
    name: "chevron--down",
    size: 16
  }))), /*#__PURE__*/React.createElement("th", null, "Status"), /*#__PURE__*/React.createElement("th", null, "Service"), /*#__PURE__*/React.createElement("th", null, "Region"), /*#__PURE__*/React.createElement("th", null, "Created"), /*#__PURE__*/React.createElement("th", null))), /*#__PURE__*/React.createElement("tbody", null, filtered.map(r => {
    const s = STATUS[r.status] || {
      type: 'gray'
    };
    return /*#__PURE__*/React.createElement("tr", {
      key: r.name
    }, /*#__PURE__*/React.createElement("td", {
      className: "name"
    }, /*#__PURE__*/React.createElement("a", {
      href: "#"
    }, r.name)), /*#__PURE__*/React.createElement("td", null, /*#__PURE__*/React.createElement(Tag, {
      type: s.type,
      size: "sm",
      icon: s.icon
    }, r.status)), /*#__PURE__*/React.createElement("td", null, r.service), /*#__PURE__*/React.createElement("td", null, r.region), /*#__PURE__*/React.createElement("td", null, r.created), /*#__PURE__*/React.createElement("td", {
      className: "overflow"
    }, /*#__PURE__*/React.createElement(Icon, {
      name: "overflow-menu--vertical",
      size: 16
    })));
  }))));
}
Object.assign(window, {
  ResourcesTable
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cloud-console/ResourcesTable.jsx", error: String((e && e.message) || e) }); }

// ui_kits/cloud-console/UIShell.jsx
try { (() => {
/* global React */
const {
  Icon
} = window.CarbonDesignSystem_280d33;
const SHELL_CSS = `
.shell { min-height: 100vh; background: var(--cds-background); font-family: var(--cds-font-sans); }
/* Header */
.cds-header { position: sticky; top: 0; z-index: 30; display: flex; align-items: center; height: 48px;
  background: var(--cds-gray-100); color: #fff; border-bottom: 1px solid var(--cds-gray-80); }
.cds-header__menu { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; color: #fff; cursor: pointer; }
.cds-header__menu:hover { background: var(--cds-gray-80); }
.cds-header__name { display: flex; align-items: center; gap: 4px; padding: 0 16px 0 8px; height: 100%;
  font-size: .875rem; color: #fff; text-decoration: none; letter-spacing: .1px; }
.cds-header__name b { font-weight: 600; }
.cds-header__name .mark { display: grid; grid-template-columns: repeat(2,5px); grid-template-rows: repeat(2,5px); gap: 1px; margin-right: 10px; }
.cds-header__name .mark i { background: var(--cds-blue-40); }
.cds-header__name .mark i:nth-child(4){ background:#fff; }
.cds-header__nav { display: flex; height: 100%; }
.cds-header__nav a { display: flex; align-items: center; padding: 0 16px; height: 100%; color: var(--cds-gray-30);
  text-decoration: none; font-size: .875rem; border-bottom: 2px solid transparent; }
.cds-header__nav a:hover { background: var(--cds-gray-80); color: #fff; }
.cds-header__nav a.active { color: #fff; border-bottom-color: var(--cds-blue-40); }
.cds-header__actions { margin-left: auto; display: flex; height: 100%; }
.cds-header__icon { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; color: #fff; cursor: pointer; position: relative; }
.cds-header__icon:hover { background: var(--cds-gray-80); }
.cds-header__icon .dot { position: absolute; top: 14px; right: 14px; width: 6px; height: 6px; border-radius: 50%; background: var(--cds-blue-40); }
.cds-header__avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--cds-blue-60); color:#fff;
  display:flex; align-items:center; justify-content:center; font-size:.75rem; font-weight:600; }
/* Body layout */
.shell__body { display: flex; }
/* Side nav */
.cds-sidenav { width: 256px; flex: 0 0 256px; background: var(--cds-gray-10); min-height: calc(100vh - 48px);
  border-right: 1px solid var(--cds-border-subtle-01); padding: 16px 0; box-sizing: border-box; }
.cds-sidenav.collapsed { width: 0; flex-basis: 0; overflow: hidden; padding: 0; border: none; }
.cds-navitem { display: flex; align-items: center; gap: 12px; height: 40px; padding: 0 16px;
  font-size: .875rem; color: var(--cds-text-secondary); cursor: pointer; border: none; background: transparent;
  width: 100%; text-align: left; box-sizing: border-box; border-left: 3px solid transparent; }
.cds-navitem:hover { background: var(--cds-layer-hover-01); color: var(--cds-text-primary); }
.cds-navitem.active { background: var(--cds-layer-selected-01); color: var(--cds-text-primary); font-weight: 600; border-left-color: var(--cds-border-interactive); }
.cds-sidenav__divider { height: 1px; background: var(--cds-border-subtle-01); margin: 16px 0; }
.shell__main { flex: 1; min-width: 0; }
`;
function injectShell() {
  if (typeof document === 'undefined' || document.getElementById('cds-shell-styles')) return;
  const el = document.createElement('style');
  el.id = 'cds-shell-styles';
  el.textContent = SHELL_CSS;
  document.head.appendChild(el);
}
function AppHeader({
  onToggleNav
}) {
  injectShell();
  return /*#__PURE__*/React.createElement("header", {
    className: "cds-header"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cds-header__menu",
    onClick: onToggleNav,
    "aria-label": "Toggle navigation"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "menu",
    size: 20
  })), /*#__PURE__*/React.createElement("a", {
    className: "cds-header__name",
    href: "#"
  }, /*#__PURE__*/React.createElement("span", {
    className: "mark"
  }, /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null), /*#__PURE__*/React.createElement("i", null)), /*#__PURE__*/React.createElement("b", null, "Carbon"), "\xA0Cloud"), /*#__PURE__*/React.createElement("nav", {
    className: "cds-header__nav"
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    className: "active"
  }, "Catalog"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Docs"), /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "Support")), /*#__PURE__*/React.createElement("div", {
    className: "cds-header__actions"
  }, /*#__PURE__*/React.createElement("button", {
    className: "cds-header__icon",
    "aria-label": "Notifications"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "notification",
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    className: "dot"
  })), /*#__PURE__*/React.createElement("button", {
    className: "cds-header__icon",
    "aria-label": "App switcher"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "grid",
    size: 20
  })), /*#__PURE__*/React.createElement("button", {
    className: "cds-header__icon",
    "aria-label": "Account"
  }, /*#__PURE__*/React.createElement("span", {
    className: "cds-header__avatar"
  }, "AK"))));
}
const NAV = [{
  id: 'overview',
  label: 'Overview',
  icon: 'dashboard'
}, {
  id: 'resources',
  label: 'Resources',
  icon: 'data--base'
}, {
  id: 'catalog',
  label: 'Catalog',
  icon: 'grid'
}, {
  id: 'activity',
  label: 'Activity',
  icon: 'analytics'
}, {
  id: 'billing',
  label: 'Billing & usage',
  icon: 'chart--bar'
}];
function SideNav({
  current,
  onSelect,
  collapsed
}) {
  injectShell();
  return /*#__PURE__*/React.createElement("nav", {
    className: `cds-sidenav ${collapsed ? 'collapsed' : ''}`
  }, NAV.map(n => /*#__PURE__*/React.createElement("button", {
    key: n.id,
    className: `cds-navitem ${current === n.id ? 'active' : ''}`,
    onClick: () => onSelect(n.id)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: n.icon,
    size: 16
  }), n.label)), /*#__PURE__*/React.createElement("div", {
    className: "cds-sidenav__divider"
  }), /*#__PURE__*/React.createElement("button", {
    className: "cds-navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "document",
    size: 16
  }), "Documentation"), /*#__PURE__*/React.createElement("button", {
    className: "cds-navitem"
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "settings",
    size: 16
  }), "Settings"));
}
Object.assign(window, {
  AppHeader,
  SideNav
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/cloud-console/UIShell.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.Tabs = __ds_scope.Tabs;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Tile = __ds_scope.Tile;

__ds_ns.InlineNotification = __ds_scope.InlineNotification;

__ds_ns.Loading = __ds_scope.Loading;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Dropdown = __ds_scope.Dropdown;

__ds_ns.Search = __ds_scope.Search;

__ds_ns.TextInput = __ds_scope.TextInput;

__ds_ns.Toggle = __ds_scope.Toggle;

})();
