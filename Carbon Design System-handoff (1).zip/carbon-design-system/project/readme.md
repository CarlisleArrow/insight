# Carbon Design System

A working design system modeled on **IBM Carbon** — IBM's open-source design system for products and digital experiences. This project packages Carbon's foundations (color, type, spacing, motion), a set of reusable React UI primitives, foundation specimen cards, and a full product UI kit, so design agents can generate on-brand IBM/Carbon-style interfaces and assets.

> **Sources.** Built by reading the official Carbon source of truth:
> - GitHub: **[carbon-design-system/carbon](https://github.com/carbon-design-system/carbon)** — tokens lifted directly from `packages/colors`, `packages/themes` (White & G100), `packages/type`, `packages/layout`, `packages/motion`, and 111 glyphs from `packages/icons`.
> - Reference docs: [carbondesignsystem.com](https://carbondesignsystem.com).
>
> Explore the repo further to deepen any recreation — the token files, component SCSS, and icon set are all open source (Apache-2.0).

---

## What Carbon is

Carbon is IBM's design system: an open, systematic language for building **productive enterprise software** — IBM Cloud, watsonx, IBM products, and partner apps. Its character is **rational, structured, and confident**: a strict 2× grid, square corners, a single signature blue, the IBM Plex type family, and restrained motion. It scales from dense data tables to expressive marketing.

Two expressions live in one system:
- **Productive** — focused, efficient, information-dense (consoles, dashboards, forms). Fast motion, compact type.
- **Expressive** — emotive, larger type, serif quotations, slower motion (marketing, hero moments).

---

## CONTENT FUNDAMENTALS

How Carbon products are written. (Carbon's voice follows the IBM editorial style.)

- **Voice:** clear, direct, human, and confident — never hype. Favor plain words over jargon. "Create resource," not "Spin up a brand-new resource instantly!"
- **Person:** address the user as **you**; refer to the product/company as **we** sparingly. Imperatives for actions ("Select a region", "Add members").
- **Tone:** professional and calm. Help text is reassuring, not chatty. Errors are specific and blame-free ("Enter a valid email address," not "You did that wrong").
- **Casing:** **Sentence case** everywhere — buttons, headers, titles, menu items, table headers ("Billing & usage", "Create resource"). Title Case is avoided. ALL-CAPS only for tiny labels/eyebrows with letter-spacing.
- **Punctuation:** no terminal periods on labels, buttons, headings, or single-sentence tooltips. Use periods in helper text and multi-sentence body. The serial (Oxford) comma is used.
- **Numbers & data:** numerals for counts and measures ("3 alerts", "62% of budget"). Abbreviate units consistently (ms, GB, vCPU).
- **Buttons:** start with a strong verb — "Create", "Deploy", "Cancel", "Save changes". Pair a primary verb with a neutral "Cancel".
- **Emoji:** **not used** in product UI. Status is communicated with icons + color + text, never emoji.
- **Examples of the vibe:** "Provisioning…", "All systems operational", "Approaching quota — 80% of compute used this month", "api-gateway-prod deployed · 2 minutes ago".

---

## VISUAL FOUNDATIONS

**Color.** One signature: **Blue 60 `#0f62fe`** — every interactive element, link, focus ring, and selection. Neutrals do the heavy lifting (Gray 10 surfaces, Gray 100 `#161616` text). Status is a fixed semantic set: error `#da1e28`, success `#24a148`, warning `#f1c21b`, info `#0043ce`. The extended hue set (red→magenta, plus cool/warm grays) is reserved for tags and data visualization. Two themes ship: **White** (default) and **G100** (dark, `data-carbon-theme="g100"`).

**Type.** **IBM Plex** — Sans for UI, Mono for code/data, Serif for expressive quotations. Weights: Light 300, Regular 400, SemiBold 600. The type scale is a fixed 23-step ramp (12, 14, 16, 18, 20, 24, 28, 32, 36, 42…). Productive headings are regular/semibold and tight; expressive display styles are fluid (clamp) and light. Letter-spacing is positive on small text (`.16–.32px`), negative on large display.

**Spacing & grid.** A **2px mini-unit** scale: `spacing-01`=2 → `spacing-13`=160px (2, 4, 8, 12, 16, 24, 32, 40, 48, 64, 80, 96, 160). Layout sits on a **16-column grid**, 32px gutters, 16px margins, max 1584px. Everything aligns to the grid — this is Carbon's most recognizable trait.

**Corners.** **Square.** Base border-radius is `0`. The only rounded things are pills (tags) and circular avatars/spinners. No soft cards.

**Borders & elevation.** Depth comes from **layer tokens + 1px borders**, not shadows. Inputs use a single bottom border (`border-strong-01`) that becomes a 2px focus outline. Shadows are reserved for things that float: dropdown menus, popovers, modals, toasts. Tiles are flat surfaces with a transparent 1px border that turns interactive-blue when selected.

**Backgrounds.** Flat fills — no gradients, no photographic hero washes, no textures in product UI. Surfaces are Gray 10 / White (light) or Gray 100/90/80 (dark). Expressive/marketing may use full-bleed imagery, but the product is clean and neutral.

**Motion.** Purposeful and quick. Durations: `fast-01` 70ms (hovers) → `slow-02` 700ms (page-level). Two easing families: **productive** `cubic-bezier(.2,0,.38,.9)` (efficient) and **expressive** `cubic-bezier(.4,.14,.3,1)` (characterful), each with entrance/exit variants. No bounce, no decorative looping. Respect `prefers-reduced-motion`.

**States.**
- *Hover:* a darker shade of the same color (Blue 60 → `#0050e6`), or a subtle gray overlay (`background-hover`, ~12% gray) on neutral controls.
- *Active/press:* a still-darker shade (no scale/shrink transform).
- *Focus:* a 2px `focus` (Blue 60) outline, often inset, plus a 1px white inset on solid fills — highly visible, never removed.
- *Selected:* interactive-blue left border or border; light blue `highlight` background.
- *Disabled:* low-contrast gray fill + `text-on-color-disabled`; `cursor: not-allowed`.

**Transparency & blur.** Used sparingly — overlays are a flat 50% black scrim; no glassmorphism/backdrop-blur in product UI.

---

## ICONOGRAPHY

- **System:** the **Carbon icon library** (`@carbon/icons`, Apache-2.0). 111 curated glyphs are bundled in [`assets/icons/`](assets/icons) as cleaned SVGs (the transparent hit-area rect removed, `fill="currentColor"`, scalable).
- **Style:** monochrome line icons on a 2px stroke at a 32×32 (or optimized 16×16) grid, square geometry, no color, no duotone. They inherit text color via `currentColor`.
- **Sizes:** 16px (default, inline with text/controls) and 20px (header/standalone). Always size in even multiples.
- **Usage:** via the **`Icon`** component (`<Icon name="search" size={16} />`) which masks the SVG with `currentColor`, or a raw CSS `mask` for static HTML. Each page sets `window.CDS_ICON_BASE` to the relative path of `assets/icons`.
- **Names** follow Carbon's kebab convention with `--` modifiers: `chevron--down`, `user--avatar`, `overflow-menu--vertical`, `warning--filled`, `data--base`, `checkmark--filled`.
- **No emoji, no unicode-glyph icons.** Status = icon + color + label.
- Need a glyph that isn't bundled? Pull it from `carbon-design-system/carbon` `packages/icons/src/svg/32/<name>.svg` and clean it the same way.

---

## Index / manifest

**Foundations**
- `styles.css` — the single entry point consumers link; `@import`s everything below.
- `tokens/colors.css` — palette + White/G100 semantic tokens.
- `tokens/typography.css` — IBM Plex families, scale, and `.cds-type-*` style classes.
- `tokens/spacing.css` — spacing/layout/container/icon-size tokens + grid.
- `tokens/motion.css` — durations + easing curves.
- `tokens/elevation.css` — overlay/menu/modal shadows.
- `tokens/fonts.css` — IBM Plex `@import` (Google Fonts).
- `guidelines/*.card.html` — 16 foundation specimen cards (Colors, Type, Spacing, Brand).

**Components** (`window.CarbonDesignSystem_280d33`)
- `components/core/` — **Button**, **Icon**
- `components/forms/` — **TextInput**, **Checkbox**, **Toggle**, **Dropdown**, **Search**
- `components/data/` — **Tag**, **Tile**, **Tabs**
- `components/feedback/` — **InlineNotification**, **Loading**

Each has a `.jsx` implementation, a `.d.ts` props contract, a `.prompt.md` usage note, and its group shares one `@dsCard` card HTML.

**UI kits**
- `ui_kits/cloud-console/` — an IBM Cloud–style management console (UI shell, side nav, data table, overview dashboard, create panel, toasts). See its `README.md`.

**Other**
- `SKILL.md` — Agent-Skill manifest for using this system in Claude Code.

---

## Caveats
- **Fonts** load IBM Plex from Google Fonts (the authentic family — not a substitute). For fully offline use, self-host from [github.com/IBM/plex](https://github.com/IBM/plex) and swap `tokens/fonts.css`.
- Components are **cosmetic recreations** for prototyping, not the production `@carbon/react` package. Behavior is simplified; accessibility is approximated, not audited.
- The IBM 8-bar logo is a trademark and is **not** reproduced; the Brand card uses an original "Carbon" wordmark + grid motif.
