# Cloud Console — UI kit

An IBM Cloud–style management console, the canonical Carbon application surface. It composes the design-system primitives (`Button`, `Tag`, `Search`, `Tabs`, `TextInput`, `Dropdown`, `Tile`, `InlineNotification`, `Icon`) into a full, click-through product view.

## What it demonstrates
- **UI Shell** — dark global header (menu, product wordmark, top nav, notification/app-switcher/avatar actions) over a light side navigation.
- **Side nav routing** — Overview, Resources, Catalog, Activity, Billing. The hamburger collapses the rail.
- **Overview dashboard** — stat tiles, a usage bar chart, and a recent-activity feed.
- **Data table** — sortable-looking header, status `Tag`s, hover rows, a toolbar with `Search` + Create.
- **Create flow** — a right-side slide-over panel with form fields; submitting adds a row and fires a success `InlineNotification` toast.

## Files
| File | Role |
|------|------|
| `index.html` | Entry — loads React, the DS bundle, and the JSX, mounts `<App/>`. |
| `UIShell.jsx` | `AppHeader` + `SideNav` chrome. |
| `Overview.jsx` | `Overview` dashboard (stats, chart, activity). |
| `ResourcesTable.jsx` | `ResourcesTable` data table + toolbar. |
| `App.jsx` | State, routing, create panel and toasts. |

## Notes
- Each page sets `window.CDS_ICON_BASE` so the `Icon` component resolves SVGs from `assets/icons/`.
- Components are read off `window.CarbonDesignSystem_280d33` (the compiled bundle). Helper components export themselves onto `window` so the separate Babel scripts can share scope.
- This is a cosmetic recreation for prototyping — not production Carbon React code.
