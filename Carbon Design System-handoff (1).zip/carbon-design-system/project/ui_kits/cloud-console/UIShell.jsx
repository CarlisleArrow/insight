/* global React */
const { Icon } = window.CarbonDesignSystem_280d33;

const SHELL_CSS = `
.shell { min-height: 100vh; background: var(--cds-background); font-family: var(--cds-font-sans); }
/* Header */
.cds-header { position: sticky; top: 0; z-index: 30; display: flex; align-items: center; height: 48px;
  background: var(--cds-gray-100); color: #fff; border-bottom: 1px solid var(--cds-gray-80); }
.cds-header__menu { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; color: #fff; cursor: pointer; }
.cds-header__menu:hover { background: var(--cds-gray-80); }
.cds-header__name { display: flex; align-items: center; gap: 4px; padding: 0 16px 0 8px; height: 100%;
  font-size: .875rem; color: #fff; text-decoration: none; letter-spacing: .1px; }
.cds-header__name b { font-weight: 600; }
.cds-header__name .mark { display: grid; grid-template-columns: repeat(2,5px); grid-template-rows: repeat(2,5px); gap: 1px; margin-right: 10px; }
.cds-header__name .mark i { background: var(--cds-blue-40); }
.cds-header__name .mark i:nth-child(4){ background:#fff; }
.cds-header__nav { display: flex; height: 100%; }
.cds-header__nav a { display: flex; align-items: center; padding: 0 16px; height: 100%; color: var(--cds-gray-30);
  text-decoration: none; font-size: .875rem; border-bottom: 2px solid transparent; }
.cds-header__nav a:hover { background: var(--cds-gray-80); color: #fff; }
.cds-header__nav a.active { color: #fff; border-bottom-color: var(--cds-blue-40); }
.cds-header__actions { margin-left: auto; display: flex; height: 100%; }
.cds-header__icon { width: 48px; height: 48px; display: flex; align-items: center; justify-content: center;
  background: transparent; border: none; color: #fff; cursor: pointer; position: relative; }
.cds-header__icon:hover { background: var(--cds-gray-80); }
.cds-header__icon .dot { position: absolute; top: 14px; right: 14px; width: 6px; height: 6px; border-radius: 50%; background: var(--cds-blue-40); }
.cds-header__avatar { width: 32px; height: 32px; border-radius: 50%; background: var(--cds-blue-60); color:#fff;
  display:flex; align-items:center; justify-content:center; font-size:.75rem; font-weight:600; }
/* Body layout */
.shell__body { display: flex; }
/* Side nav */
.cds-sidenav { width: 256px; flex: 0 0 256px; background: var(--cds-gray-10); min-height: calc(100vh - 48px);
  border-right: 1px solid var(--cds-border-subtle-01); padding: 16px 0; box-sizing: border-box; }
.cds-sidenav.collapsed { width: 0; flex-basis: 0; overflow: hidden; padding: 0; border: none; }
.cds-navitem { display: flex; align-items: center; gap: 12px; height: 40px; padding: 0 16px;
  font-size: .875rem; color: var(--cds-text-secondary); cursor: pointer; border: none; background: transparent;
  width: 100%; text-align: left; box-sizing: border-box; border-left: 3px solid transparent; }
.cds-navitem:hover { background: var(--cds-layer-hover-01); color: var(--cds-text-primary); }
.cds-navitem.active { background: var(--cds-layer-selected-01); color: var(--cds-text-primary); font-weight: 600; border-left-color: var(--cds-border-interactive); }
.cds-sidenav__divider { height: 1px; background: var(--cds-border-subtle-01); margin: 16px 0; }
.shell__main { flex: 1; min-width: 0; }
`;

function injectShell() {
  if (typeof document === 'undefined' || document.getElementById('cds-shell-styles')) return;
  const el = document.createElement('style'); el.id = 'cds-shell-styles'; el.textContent = SHELL_CSS;
  document.head.appendChild(el);
}

function AppHeader({ onToggleNav }) {
  injectShell();
  return (
    <header className="cds-header">
      <button className="cds-header__menu" onClick={onToggleNav} aria-label="Toggle navigation"><Icon name="menu" size={20} /></button>
      <a className="cds-header__name" href="#"><span className="mark"><i></i><i></i><i></i><i></i></span><b>Carbon</b>&nbsp;Cloud</a>
      <nav className="cds-header__nav">
        <a href="#" className="active">Catalog</a>
        <a href="#">Docs</a>
        <a href="#">Support</a>
      </nav>
      <div className="cds-header__actions">
        <button className="cds-header__icon" aria-label="Notifications"><Icon name="notification" size={20} /><span className="dot"></span></button>
        <button className="cds-header__icon" aria-label="App switcher"><Icon name="grid" size={20} /></button>
        <button className="cds-header__icon" aria-label="Account"><span className="cds-header__avatar">AK</span></button>
      </div>
    </header>
  );
}

const NAV = [
  { id: 'overview', label: 'Overview', icon: 'dashboard' },
  { id: 'resources', label: 'Resources', icon: 'data--base' },
  { id: 'catalog', label: 'Catalog', icon: 'grid' },
  { id: 'activity', label: 'Activity', icon: 'analytics' },
  { id: 'billing', label: 'Billing & usage', icon: 'chart--bar' },
];

function SideNav({ current, onSelect, collapsed }) {
  injectShell();
  return (
    <nav className={`cds-sidenav ${collapsed ? 'collapsed' : ''}`}>
      {NAV.map((n) => (
        <button key={n.id} className={`cds-navitem ${current === n.id ? 'active' : ''}`} onClick={() => onSelect(n.id)}>
          <Icon name={n.icon} size={16} />{n.label}
        </button>
      ))}
      <div className="cds-sidenav__divider"></div>
      <button className="cds-navitem"><Icon name="document" size={16} />Documentation</button>
      <button className="cds-navitem"><Icon name="settings" size={16} />Settings</button>
    </nav>
  );
}

Object.assign(window, { AppHeader, SideNav });
