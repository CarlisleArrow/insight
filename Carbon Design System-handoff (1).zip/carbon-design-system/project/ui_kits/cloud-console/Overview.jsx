/* global React */
const { Icon, Tile, Button } = window.CarbonDesignSystem_280d33;

const OV_CSS = `
.ov { display: grid; grid-template-columns: repeat(12, 1fr); gap: 1px; background: var(--cds-border-subtle-01); }
.ov > * { background: var(--cds-layer-02); }
.ov .stat { grid-column: span 3; padding: 24px; }
.ov .stat .k { font-size: .75rem; letter-spacing: .32px; color: var(--cds-text-secondary); display:flex; align-items:center; gap:8px; }
.ov .stat .v { font-size: 2.625rem; font-weight: 300; line-height: 1.1; color: var(--cds-text-primary); margin-top: 12px; }
.ov .stat .d { font-size: .75rem; color: var(--cds-text-secondary); margin-top: 8px; }
.ov .stat .d.up { color: var(--cds-support-success); }
.ov .panel { grid-column: span 6; padding: 24px; }
.ov .panel.full { grid-column: span 12; }
.ov h3 { font-size: 1rem; font-weight: 600; margin: 0 0 16px; color: var(--cds-text-primary); }
.bars { display: flex; align-items: flex-end; gap: 10px; height: 120px; }
.bars .bar { flex: 1; background: var(--cds-blue-60); }
.bars .bar:nth-child(even){ background: var(--cds-blue-40); }
.legend { display:flex; gap:16px; margin-top:14px; font-size:.75rem; color:var(--cds-text-secondary); }
.legend i { display:inline-block; width:10px; height:10px; margin-right:6px; vertical-align:middle; }
.activity { list-style:none; margin:0; padding:0; }
.activity li { display:flex; gap:12px; align-items:flex-start; padding:12px 0; border-bottom:1px solid var(--cds-border-subtle-01); font-size:.875rem; }
.activity li:last-child{ border-bottom:none; }
.activity .ic { color: var(--cds-icon-secondary); margin-top:2px; }
.activity .t { color: var(--cds-text-primary); }
.activity .m { color: var(--cds-text-secondary); font-size:.75rem; margin-top:2px; }
`;

function injectOv() {
  if (typeof document === 'undefined' || document.getElementById('cds-ov-styles')) return;
  const el = document.createElement('style'); el.id = 'cds-ov-styles'; el.textContent = OV_CSS;
  document.head.appendChild(el);
}

function Stat({ label, icon, value, delta, up }) {
  return (
    <div className="stat">
      <div className="k"><Icon name={icon} size={16} />{label}</div>
      <div className="v">{value}</div>
      <div className={`d ${up ? 'up' : ''}`}>{delta}</div>
    </div>
  );
}

function Overview() {
  injectOv();
  const heights = [40, 62, 55, 78, 70, 92, 84, 60];
  return (
    <div className="ov">
      <Stat label="Active resources" icon="data--base" value="24" delta="+3 this week" up />
      <Stat label="Monthly spend" icon="chart--bar" value="$1,284" delta="62% of budget" />
      <Stat label="Avg. CPU" icon="analytics" value="38%" delta="Healthy" up />
      <Stat label="Open alerts" icon="warning--alt" value="2" delta="1 critical" />
      <div className="panel">
        <h3>Compute usage</h3>
        <div className="bars">{heights.map((h, i) => <div key={i} className="bar" style={{ height: h + '%' }} />)}</div>
        <div className="legend"><span><i style={{ background: 'var(--cds-blue-60)' }}></i>Provisioned</span><span><i style={{ background: 'var(--cds-blue-40)' }}></i>Reserved</span></div>
      </div>
      <div className="panel">
        <h3>Recent activity</h3>
        <ul className="activity">
          <li><Icon name="checkmark--filled" size={16} className="ic" style={{ color: 'var(--cds-support-success)' }} /><div><div className="t">api-gateway-prod deployed</div><div className="m">2 minutes ago · US South</div></div></li>
          <li><Icon name="renew" size={16} className="ic" /><div><div className="t">postgres-cluster-02 scaling up</div><div className="m">18 minutes ago · EU Frankfurt</div></div></li>
          <li><Icon name="user--avatar" size={16} className="ic" /><div><div className="t">A. Kapoor invited to project</div><div className="m">1 hour ago</div></div></li>
          <li><Icon name="warning--filled" size={16} className="ic" style={{ color: 'var(--cds-support-warning)' }} /><div><div className="t">object-store nearing quota</div><div className="m">3 hours ago</div></div></li>
        </ul>
      </div>
    </div>
  );
}

Object.assign(window, { Overview });
