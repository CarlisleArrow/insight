/* global React */
const { Icon, Tag, Search, Button } = window.CarbonDesignSystem_280d33;

const TABLE_CSS = `
.cds-tbl-wrap { background: var(--cds-layer-02); }
.cds-tbl-toolbar { display: flex; align-items: stretch; height: 48px; border-bottom: 1px solid var(--cds-border-subtle-01); }
.cds-tbl-toolbar .grow { flex: 1; display: flex; align-items: center; }
.cds-tbl-toolbar .cds--search__input { background: var(--cds-layer-02); height: 48px; }
.cds-tbl { width: 100%; border-collapse: collapse; font-family: var(--cds-font-sans); }
.cds-tbl th { text-align: left; font-size: .875rem; font-weight: 600; color: var(--cds-text-primary);
  background: var(--cds-layer-accent-01); height: 48px; padding: 0 16px; white-space: nowrap; }
.cds-tbl td { font-size: .875rem; color: var(--cds-text-secondary); height: 48px; padding: 0 16px;
  border-bottom: 1px solid var(--cds-border-subtle-01); background: var(--cds-layer-02); }
.cds-tbl tr:hover td { background: var(--cds-layer-hover-02); }
.cds-tbl td.name { color: var(--cds-text-primary); font-weight: 500; }
.cds-tbl td.name a { color: var(--cds-link-primary); text-decoration: none; }
.cds-tbl td.name a:hover { text-decoration: underline; }
.cds-tbl .overflow { width: 48px; text-align: center; color: var(--cds-icon-primary); cursor: pointer; }
.cds-tbl__sort { display: inline-flex; align-items: center; gap: 6px; cursor: pointer; }
`;

function injectTable() {
  if (typeof document === 'undefined' || document.getElementById('cds-table-styles')) return;
  const el = document.createElement('style'); el.id = 'cds-table-styles'; el.textContent = TABLE_CSS;
  document.head.appendChild(el);
}

const STATUS = {
  Running: { type: 'green', icon: 'checkmark' },
  Provisioning: { type: 'blue', icon: 'renew' },
  Stopped: { type: 'gray' },
  Failed: { type: 'red' },
};

function ResourcesTable({ rows, onCreate }) {
  injectTable();
  const [q, setQ] = React.useState('');
  const filtered = rows.filter((r) => r.name.toLowerCase().includes(q.toLowerCase()));
  return (
    <div className="cds-tbl-wrap">
      <div className="cds-tbl-toolbar">
        <div className="grow"><Search value={q} onChange={setQ} size="lg" placeholder="Search resources" /></div>
        <Button kind="ghost" size="lg" icon="filter" iconOnly />
        <Button kind="primary" size="lg" icon="add" onClick={onCreate}>Create resource</Button>
      </div>
      <table className="cds-tbl">
        <thead>
          <tr>
            <th><span className="cds-tbl__sort">Name <Icon name="chevron--down" size={16} /></span></th>
            <th>Status</th>
            <th>Service</th>
            <th>Region</th>
            <th>Created</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {filtered.map((r) => {
            const s = STATUS[r.status] || { type: 'gray' };
            return (
              <tr key={r.name}>
                <td className="name"><a href="#">{r.name}</a></td>
                <td><Tag type={s.type} size="sm" icon={s.icon}>{r.status}</Tag></td>
                <td>{r.service}</td>
                <td>{r.region}</td>
                <td>{r.created}</td>
                <td className="overflow"><Icon name="overflow-menu--vertical" size={16} /></td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

Object.assign(window, { ResourcesTable });
