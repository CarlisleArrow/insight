/* global React, AppHeader, SideNav, ResourcesTable, Overview */
const { Button, Tabs, TextInput, Dropdown, InlineNotification, Tag, Tile, Icon } = window.CarbonDesignSystem_280d33;

const APP_CSS = `
.page { padding: 32px 32px 64px; max-width: 1200px; }
.crumb { font-size: .75rem; color: var(--cds-text-secondary); margin-bottom: 16px; letter-spacing:.32px; }
.crumb a { color: var(--cds-link-primary); text-decoration: none; }
.crumb a:hover { text-decoration: underline; }
.page__head { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 24px; gap: 24px; }
.page__head h1 { font-size: 1.75rem; font-weight: 400; line-height: 1.28; margin: 0; color: var(--cds-text-primary); }
.page__head p { margin: 8px 0 0; font-size: .875rem; color: var(--cds-text-secondary); }
.toast-stack { position: fixed; top: 60px; right: 16px; z-index: 50; width: 360px; display: flex; flex-direction: column; gap: 8px; }
/* Side panel */
.scrim { position: fixed; inset: 0; background: var(--cds-overlay); z-index: 40; }
.panel-create { position: fixed; top: 0; right: 0; bottom: 0; width: 420px; background: var(--cds-layer-02);
  z-index: 45; box-shadow: var(--cds-shadow-modal); display: flex; flex-direction: column; }
.panel-create__head { padding: 24px; border-bottom: 1px solid var(--cds-border-subtle-01); }
.panel-create__head .sup { font-size: .75rem; color: var(--cds-text-secondary); letter-spacing:.32px; }
.panel-create__head h2 { font-size: 1.25rem; font-weight: 400; margin: 6px 0 0; color: var(--cds-text-primary); }
.panel-create__body { padding: 24px; display: flex; flex-direction: column; gap: 24px; flex: 1; overflow: auto; }
.panel-create__foot { display: flex; }
.panel-create__foot > * { flex: 1; }
.kit-frame { border: 1px solid var(--cds-border-subtle-01); }
`;

function inject() {
  if (typeof document === 'undefined' || document.getElementById('cds-app-styles')) return;
  const el = document.createElement('style'); el.id = 'cds-app-styles'; el.textContent = APP_CSS;
  document.head.appendChild(el);
}

const SEED = [
  { name: 'api-gateway-prod', status: 'Running', service: 'Code Engine', region: 'US South', created: 'Apr 2, 2026' },
  { name: 'postgres-cluster-02', status: 'Provisioning', service: 'Databases', region: 'EU Frankfurt', created: 'Apr 1, 2026' },
  { name: 'object-store-assets', status: 'Running', service: 'Object Storage', region: 'US East', created: 'Mar 28, 2026' },
  { name: 'ml-inference-gpu', status: 'Stopped', service: 'Watson ML', region: 'AP Sydney', created: 'Mar 21, 2026' },
  { name: 'edge-cache-eu', status: 'Failed', service: 'CDN', region: 'EU London', created: 'Mar 19, 2026' },
];

const TITLES = {
  overview: ['Overview', 'Account health and recent activity across your resources.'],
  resources: ['Resource list', 'All provisioned services in this resource group.'],
  catalog: ['Catalog', 'Browse and provision new services.'],
  activity: ['Activity', 'Audit log of account events.'],
  billing: ['Billing & usage', 'Track spend against your monthly budget.'],
};

function App() {
  inject();
  const [nav, setNav] = React.useState('overview');
  const [collapsed, setCollapsed] = React.useState(false);
  const [rows, setRows] = React.useState(SEED);
  const [creating, setCreating] = React.useState(false);
  const [toasts, setToasts] = React.useState([]);
  const [form, setForm] = React.useState({ name: '', service: 'Code Engine', region: 'US South' });

  function addToast(t) {
    const id = Math.random().toString(36).slice(2);
    setToasts((ts) => [...ts, { ...t, id }]);
    setTimeout(() => setToasts((ts) => ts.filter((x) => x.id !== id)), 4500);
  }
  function create() {
    const name = form.name.trim() || 'new-resource';
    setRows((r) => [{ name, status: 'Provisioning', service: form.service, region: form.region, created: 'Just now' }, ...r]);
    setCreating(false);
    setForm({ name: '', service: 'Code Engine', region: 'US South' });
    addToast({ kind: 'success', title: 'Resource created.', subtitle: `${name} is provisioning.` });
    setNav('resources');
  }

  const [title, sub] = TITLES[nav];

  return (
    <div className="shell">
      <AppHeader onToggleNav={() => setCollapsed((c) => !c)} />
      <div className="shell__body">
        <SideNav current={nav} onSelect={setNav} collapsed={collapsed} />
        <main className="shell__main">
          <div className="page">
            <div className="crumb"><a href="#">Resource list</a> / <a href="#">my-project</a> / {title}</div>
            <div className="page__head">
              <div><h1>{title}</h1><p>{sub}</p></div>
              {nav === 'overview' && <Button kind="primary" icon="add" onClick={() => setCreating(true)}>Create resource</Button>}
            </div>

            {nav === 'overview' && <Overview />}

            {nav === 'resources' && (
              <Tabs tabs={[
                { label: `All (${rows.length})`, content: <div style={{ marginTop: 8 }}><ResourcesTable rows={rows} onCreate={() => setCreating(true)} /></div> },
                { label: 'Running', content: <div style={{ marginTop: 8 }}><ResourcesTable rows={rows.filter(r => r.status === 'Running')} onCreate={() => setCreating(true)} /></div> },
                { label: 'Stopped', content: <div style={{ marginTop: 8 }}><ResourcesTable rows={rows.filter(r => r.status === 'Stopped')} onCreate={() => setCreating(true)} /></div> },
              ]} />
            )}

            {(nav === 'catalog' || nav === 'activity' || nav === 'billing') && (
              <Tile style={{ padding: 48, textAlign: 'center', color: 'var(--cds-text-secondary)' }}>
                <Icon name={nav === 'catalog' ? 'grid' : nav === 'activity' ? 'analytics' : 'chart--bar'} size={32} />
                <p style={{ marginTop: 12 }}>{title} — sample surface. Use the Overview and Resource list tabs for the full interactive demo.</p>
              </Tile>
            )}
          </div>
        </main>
      </div>

      {toasts.length > 0 && (
        <div className="toast-stack">
          {toasts.map((t) => (
            <InlineNotification key={t.id} kind={t.kind} title={t.title} subtitle={t.subtitle}
              onClose={() => setToasts((ts) => ts.filter((x) => x.id !== t.id))} />
          ))}
        </div>
      )}

      {creating && <div className="scrim" onClick={() => setCreating(false)} />}
      {creating && (
        <aside className="panel-create">
          <div className="panel-create__head"><div className="sup">Provision</div><h2>Create resource</h2></div>
          <div className="panel-create__body">
            <TextInput label="Resource name" placeholder="my-service" value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} helperText="Lowercase, hyphen-separated." />
            <Dropdown label="Service" value={form.service} items={['Code Engine', 'Databases', 'Object Storage', 'Watson ML', 'CDN']}
              onChange={(v) => setForm((f) => ({ ...f, service: v }))} />
            <Dropdown label="Region" value={form.region} items={['US South', 'US East', 'EU Frankfurt', 'EU London', 'AP Sydney']}
              onChange={(v) => setForm((f) => ({ ...f, region: v }))} />
          </div>
          <div className="panel-create__foot">
            <Button kind="secondary" onClick={() => setCreating(false)}>Cancel</Button>
            <Button kind="primary" icon="add" onClick={create}>Create</Button>
          </div>
        </aside>
      )}
    </div>
  );
}

Object.assign(window, { App });
